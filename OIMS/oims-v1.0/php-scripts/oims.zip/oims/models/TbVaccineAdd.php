<?php

namespace PHPMaker2023\OIMS;

use Doctrine\DBAL\ParameterType;
use Doctrine\DBAL\FetchMode;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;

/**
 * Page class
 */
class TbVaccineAdd extends TbVaccine
{
    use MessagesTrait;

    // Page ID
    public $PageID = "add";

    // Project ID
    public $ProjectID = PROJECT_ID;

    // Page object name
    public $PageObjName = "TbVaccineAdd";

    // View file path
    public $View = null;

    // Title
    public $Title = null; // Title for <title> tag

    // Rendering View
    public $RenderingView = false;

    // CSS class/style
    public $CurrentPageName = "tbvaccineadd";

    // Page headings
    public $Heading = "";
    public $Subheading = "";
    public $PageHeader;
    public $PageFooter;

    // Page layout
    public $UseLayout = true;

    // Page terminated
    private $terminated = false;

    // Page heading
    public function pageHeading()
    {
        global $Language;
        if ($this->Heading != "") {
            return $this->Heading;
        }
        if (method_exists($this, "tableCaption")) {
            return $this->tableCaption();
        }
        return "";
    }

    // Page subheading
    public function pageSubheading()
    {
        global $Language;
        if ($this->Subheading != "") {
            return $this->Subheading;
        }
        if ($this->TableName) {
            return $Language->phrase($this->PageID);
        }
        return "";
    }

    // Page name
    public function pageName()
    {
        return CurrentPageName();
    }

    // Page URL
    public function pageUrl($withArgs = true)
    {
        $route = GetRoute();
        $args = RemoveXss($route->getArguments());
        if (!$withArgs) {
            foreach ($args as $key => &$val) {
                $val = "";
            }
            unset($val);
        }
        return rtrim(UrlFor($route->getName(), $args), "/") . "?";
    }

    // Show Page Header
    public function showPageHeader()
    {
        $header = $this->PageHeader;
        $this->pageDataRendering($header);
        if ($header != "") { // Header exists, display
            echo '<p id="ew-page-header">' . $header . '</p>';
        }
    }

    // Show Page Footer
    public function showPageFooter()
    {
        $footer = $this->PageFooter;
        $this->pageDataRendered($footer);
        if ($footer != "") { // Footer exists, display
            echo '<p id="ew-page-footer">' . $footer . '</p>';
        }
    }

    // Set field visibility
    public function setVisibility()
    {
        $this->id->Visible = false;
        $this->vaccine_name->setVisibility();
        $this->vaccine_code->setVisibility();
        $this->dose_required->setVisibility();
        $this->dose_required_uom->setVisibility();
        $this->admin_mode_id->setVisibility();
        $this->admin_site_id->setVisibility();
        $this->vaccine_form_id->setVisibility();
        $this->expiry_date->setVisibility();
        $this->target_group->setVisibility();
        $this->storage_condition->setVisibility();
        $this->description->setVisibility();
        $this->entry_date->setVisibility();
        $this->last_modified->setVisibility();
        $this->entered_by->setVisibility();
        $this->modified_by->setVisibility();
    }

    // Constructor
    public function __construct()
    {
        parent::__construct();
        global $Language, $DashboardReport, $DebugTimer, $UserTable;
        $this->TableVar = 'tb_vaccine';
        $this->TableName = 'tb_vaccine';

        // Table CSS class
        $this->TableClass = "table table-striped table-bordered table-hover table-sm ew-desktop-table ew-add-table";

        // Initialize
        $GLOBALS["Page"] = &$this;

        // Language object
        $Language = Container("language");

        // Table object (tb_vaccine)
        if (!isset($GLOBALS["tb_vaccine"]) || get_class($GLOBALS["tb_vaccine"]) == PROJECT_NAMESPACE . "tb_vaccine") {
            $GLOBALS["tb_vaccine"] = &$this;
        }

        // Table name (for backward compatibility only)
        if (!defined(PROJECT_NAMESPACE . "TABLE_NAME")) {
            define(PROJECT_NAMESPACE . "TABLE_NAME", 'tb_vaccine');
        }

        // Start timer
        $DebugTimer = Container("timer");

        // Debug message
        LoadDebugMessage();

        // Open connection
        $GLOBALS["Conn"] ??= $this->getConnection();

        // User table object
        $UserTable = Container("usertable");
    }

    // Get content from stream
    public function getContents(): string
    {
        global $Response;
        return is_object($Response) ? $Response->getBody() : ob_get_clean();
    }

    // Is lookup
    public function isLookup()
    {
        return SameText(Route(0), Config("API_LOOKUP_ACTION"));
    }

    // Is AutoFill
    public function isAutoFill()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autofill");
    }

    // Is AutoSuggest
    public function isAutoSuggest()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autosuggest");
    }

    // Is modal lookup
    public function isModalLookup()
    {
        return $this->isLookup() && SameText(Post("ajax"), "modal");
    }

    // Is terminated
    public function isTerminated()
    {
        return $this->terminated;
    }

    /**
     * Terminate page
     *
     * @param string $url URL for direction
     * @return void
     */
    public function terminate($url = "")
    {
        if ($this->terminated) {
            return;
        }
        global $TempImages, $DashboardReport, $Response;

        // Page is terminated
        $this->terminated = true;

        // Page Unload event
        if (method_exists($this, "pageUnload")) {
            $this->pageUnload();
        }

        // Global Page Unloaded event (in userfn*.php)
        Page_Unloaded();
        if (!IsApi() && method_exists($this, "pageRedirecting")) {
            $this->pageRedirecting($url);
        }

        // Close connection
        CloseConnections();

        // Return for API
        if (IsApi()) {
            $res = $url === true;
            if (!$res) { // Show response for API
                $ar = array_merge($this->getMessages(), $url ? ["url" => GetUrl($url)] : []);
                WriteJson($ar);
            }
            $this->clearMessages(); // Clear messages for API request
            return;
        } else { // Check if response is JSON
            if (StartsString("application/json", $Response->getHeaderLine("Content-type")) && $Response->getBody()->getSize()) { // With JSON response
                $this->clearMessages();
                return;
            }
        }

        // Go to URL if specified
        if ($url != "") {
            if (!Config("DEBUG") && ob_get_length()) {
                ob_end_clean();
            }

            // Handle modal response (Assume return to modal for simplicity)
            if ($this->IsModal) { // Show as modal
                $result = ["url" => GetUrl($url), "modal" => "1"];
                $pageName = GetPageName($url);
                if ($pageName != $this->getListUrl()) { // Not List page => View page
                    $result["caption"] = $this->getModalCaption($pageName);
                    $result["view"] = $pageName == "tbvaccineview"; // If View page, no primary button
                } else { // List page
                    // $result["list"] = $this->PageID == "search"; // Refresh List page if current page is Search page
                    $result["error"] = $this->getFailureMessage(); // List page should not be shown as modal => error
                    $this->clearFailureMessage();
                }
                WriteJson($result);
            } else {
                SaveDebugMessage();
                Redirect(GetUrl($url));
            }
        }
        return; // Return to controller
    }

    // Get records from recordset
    protected function getRecordsFromRecordset($rs, $current = false)
    {
        $rows = [];
        if (is_object($rs)) { // Recordset
            while ($rs && !$rs->EOF) {
                $this->loadRowValues($rs); // Set up DbValue/CurrentValue
                $row = $this->getRecordFromArray($rs->fields);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
                $rs->moveNext();
            }
        } elseif (is_array($rs)) {
            foreach ($rs as $ar) {
                $row = $this->getRecordFromArray($ar);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
            }
        }
        return $rows;
    }

    // Get record from array
    protected function getRecordFromArray($ar)
    {
        $row = [];
        if (is_array($ar)) {
            foreach ($ar as $fldname => $val) {
                if (array_key_exists($fldname, $this->Fields) && ($this->Fields[$fldname]->Visible || $this->Fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
                    $fld = &$this->Fields[$fldname];
                    if ($fld->HtmlTag == "FILE") { // Upload field
                        if (EmptyValue($val)) {
                            $row[$fldname] = null;
                        } else {
                            if ($fld->DataType == DATATYPE_BLOB) {
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . $fld->Param . "/" . rawurlencode($this->getRecordKeyValue($ar))));
                                $row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
                            } elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $val)));
                                $row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
                            } else { // Multiple files
                                $files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
                                $ar = [];
                                foreach ($files as $file) {
                                    $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                        "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $file)));
                                    if (!EmptyValue($file)) {
                                        $ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
                                    }
                                }
                                $row[$fldname] = $ar;
                            }
                        }
                    } else {
                        $row[$fldname] = $val;
                    }
                }
            }
        }
        return $row;
    }

    // Get record key value from array
    protected function getRecordKeyValue($ar)
    {
        $key = "";
        if (is_array($ar)) {
            $key .= @$ar['id'];
        }
        return $key;
    }

    /**
     * Hide fields for add/edit
     *
     * @return void
     */
    protected function hideFieldsForAddEdit()
    {
        if ($this->isAdd() || $this->isCopy() || $this->isGridAdd()) {
            $this->id->Visible = false;
        }
    }

    // Lookup data
    public function lookup($ar = null)
    {
        global $Language, $Security;

        // Get lookup object
        $fieldName = $ar["field"] ?? Post("field");
        $lookup = $this->Fields[$fieldName]->Lookup;
        $name = $ar["name"] ?? Post("name");
        $isQuery = ContainsString($name, "query_builder_rule");
        if ($isQuery) {
            $lookup->FilterFields = []; // Skip parent fields if any
        }

        // Get lookup parameters
        $lookupType = $ar["ajax"] ?? Post("ajax", "unknown");
        $pageSize = -1;
        $offset = -1;
        $searchValue = "";
        if (SameText($lookupType, "modal") || SameText($lookupType, "filter")) {
            $searchValue = $ar["q"] ?? Param("q") ?? $ar["sv"] ?? Post("sv", "");
            $pageSize = $ar["n"] ?? Param("n") ?? $ar["recperpage"] ?? Post("recperpage", 10);
        } elseif (SameText($lookupType, "autosuggest")) {
            $searchValue = $ar["q"] ?? Param("q", "");
            $pageSize = $ar["n"] ?? Param("n", -1);
            $pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
            if ($pageSize <= 0) {
                $pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
            }
        }
        $start = $ar["start"] ?? Param("start", -1);
        $start = is_numeric($start) ? (int)$start : -1;
        $page = $ar["page"] ?? Param("page", -1);
        $page = is_numeric($page) ? (int)$page : -1;
        $offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
        $userSelect = Decrypt($ar["s"] ?? Post("s", ""));
        $userFilter = Decrypt($ar["f"] ?? Post("f", ""));
        $userOrderBy = Decrypt($ar["o"] ?? Post("o", ""));
        $keys = $ar["keys"] ?? Post("keys");
        $lookup->LookupType = $lookupType; // Lookup type
        $lookup->FilterValues = []; // Clear filter values first
        if ($keys !== null) { // Selected records from modal
            if (is_array($keys)) {
                $keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
            }
            $lookup->FilterFields = []; // Skip parent fields if any
            $lookup->FilterValues[] = $keys; // Lookup values
            $pageSize = -1; // Show all records
        } else { // Lookup values
            $lookup->FilterValues[] = $ar["v0"] ?? $ar["lookupValue"] ?? Post("v0", Post("lookupValue", ""));
        }
        $cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
        for ($i = 1; $i <= $cnt; $i++) {
            $lookup->FilterValues[] = $ar["v" . $i] ?? Post("v" . $i, "");
        }
        $lookup->SearchValue = $searchValue;
        $lookup->PageSize = $pageSize;
        $lookup->Offset = $offset;
        if ($userSelect != "") {
            $lookup->UserSelect = $userSelect;
        }
        if ($userFilter != "") {
            $lookup->UserFilter = $userFilter;
        }
        if ($userOrderBy != "") {
            $lookup->UserOrderBy = $userOrderBy;
        }
        return $lookup->toJson($this, !is_array($ar)); // Use settings from current page
    }
    public $FormClassName = "ew-form ew-add-form";
    public $IsModal = false;
    public $IsMobileOrModal = false;
    public $DbMasterFilter = "";
    public $DbDetailFilter = "";
    public $StartRecord;
    public $Priv = 0;
    public $CopyRecord;

    /**
     * Page run
     *
     * @return void
     */
    public function run()
    {
        global $ExportType, $UserProfile, $Language, $Security, $CurrentForm, $SkipHeaderFooter;

        // Is modal
        $this->IsModal = ConvertToBool(Param("modal"));
        $this->UseLayout = $this->UseLayout && !$this->IsModal;

        // Use layout
        $this->UseLayout = $this->UseLayout && ConvertToBool(Param(Config("PAGE_LAYOUT"), true));

        // View
        $this->View = Get(Config("VIEW"));

        // Create form object
        $CurrentForm = new HttpForm();
        $this->CurrentAction = Param("action"); // Set up current action
        $this->setVisibility();

        // Set lookup cache
        if (!in_array($this->PageID, Config("LOOKUP_CACHE_PAGE_IDS"))) {
            $this->setUseLookupCache(false);
        }

        // Global Page Loading event (in userfn*.php)
        Page_Loading();

        // Page Load event
        if (method_exists($this, "pageLoad")) {
            $this->pageLoad();
        }

        // Hide fields for add/edit
        if (!$this->UseAjaxActions) {
            $this->hideFieldsForAddEdit();
        }
        // Use inline delete
        if ($this->UseAjaxActions) {
            $this->InlineDelete = true;
        }

        // Set up lookup cache
        $this->setupLookupOptions($this->dose_required_uom);
        $this->setupLookupOptions($this->admin_mode_id);
        $this->setupLookupOptions($this->admin_site_id);
        $this->setupLookupOptions($this->vaccine_form_id);
        $this->setupLookupOptions($this->target_group);
        $this->setupLookupOptions($this->entered_by);
        $this->setupLookupOptions($this->modified_by);

        // Load default values for add
        $this->loadDefaultValues();

        // Check modal
        if ($this->IsModal) {
            $SkipHeaderFooter = true;
        }
        $this->IsMobileOrModal = IsMobile() || $this->IsModal;
        $postBack = false;

        // Set up current action
        if (IsApi()) {
            $this->CurrentAction = "insert"; // Add record directly
            $postBack = true;
        } elseif (Post("action", "") !== "") {
            $this->CurrentAction = Post("action"); // Get form action
            $this->setKey(Post($this->OldKeyName));
            $postBack = true;
        } else {
            // Load key values from QueryString
            if (($keyValue = Get("id") ?? Route("id")) !== null) {
                $this->id->setQueryStringValue($keyValue);
            }
            $this->OldKey = $this->getKey(true); // Get from CurrentValue
            $this->CopyRecord = !EmptyValue($this->OldKey);
            if ($this->CopyRecord) {
                $this->CurrentAction = "copy"; // Copy record
                $this->setKey($this->OldKey); // Set up record key
            } else {
                $this->CurrentAction = "show"; // Display blank record
            }
        }

        // Load old record or default values
        $rsold = $this->loadOldRecord();

        // Load form values
        if ($postBack) {
            $this->loadFormValues(); // Load form values
        }

        // Validate form if post back
        if ($postBack) {
            if (!$this->validateForm()) {
                $this->EventCancelled = true; // Event cancelled
                $this->restoreFormValues(); // Restore form values
                if (IsApi()) {
                    $this->terminate();
                    return;
                } else {
                    $this->CurrentAction = "show"; // Form error, reset action
                }
            }
        }

        // Perform current action
        switch ($this->CurrentAction) {
            case "copy": // Copy an existing record
                if (!$rsold) { // Record not loaded
                    if ($this->getFailureMessage() == "") {
                        $this->setFailureMessage($Language->phrase("NoRecord")); // No record found
                    }
                    $this->terminate("tbvaccinelist"); // No matching record, return to list
                    return;
                }
                break;
            case "insert": // Add new record
                $this->SendEmail = true; // Send email on add success
                if ($this->addRow($rsold)) { // Add successful
                    if ($this->getSuccessMessage() == "" && Post("addopt") != "1") { // Skip success message for addopt (done in JavaScript)
                        $this->setSuccessMessage($Language->phrase("AddSuccess")); // Set up success message
                    }
                    $returnUrl = $this->getReturnUrl();
                    if (GetPageName($returnUrl) == "tbvaccinelist") {
                        $returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
                    } elseif (GetPageName($returnUrl) == "tbvaccineview") {
                        $returnUrl = $this->getViewUrl(); // View page, return to View page with keyurl directly
                    }

                    // Handle UseAjaxActions
                    if ($this->IsModal && $this->UseAjaxActions) {
                        $this->IsModal = false;
                        if (GetPageName($returnUrl) != "tbvaccinelist") {
                            Container("flash")->addMessage("Return-Url", $returnUrl); // Save return URL
                            $returnUrl = "tbvaccinelist"; // Return list page content
                        }
                    }
                    if (IsJsonResponse()) { // Return to caller
                        $this->terminate(true);
                        return;
                    } else {
                        $this->terminate($returnUrl);
                        return;
                    }
                } elseif (IsApi()) { // API request, return
                    $this->terminate();
                    return;
                } elseif ($this->IsModal && $this->UseAjaxActions) { // Return JSON error message
                    WriteJson([ "success" => false, "validation" => $this->getValidationErrors(), "error" => $this->getFailureMessage() ]);
                    $this->clearFailureMessage();
                    $this->terminate();
                    return;
                } else {
                    $this->EventCancelled = true; // Event cancelled
                    $this->restoreFormValues(); // Add failed, restore form values
                }
        }

        // Set up Breadcrumb
        $this->setupBreadcrumb();

        // Render row based on row type
        $this->RowType = ROWTYPE_ADD; // Render add type

        // Render row
        $this->resetAttributes();
        $this->renderRow();

        // Set LoginStatus / Page_Rendering / Page_Render
        if (!IsApi() && !$this->isTerminated()) {
            // Setup login status
            SetupLoginStatus();

            // Pass login status to client side
            SetClientVar("login", LoginStatus());

            // Global Page Rendering event (in userfn*.php)
            Page_Rendering();

            // Page Render event
            if (method_exists($this, "pageRender")) {
                $this->pageRender();
            }

            // Render search option
            if (method_exists($this, "renderSearchOptions")) {
                $this->renderSearchOptions();
            }
        }
    }

    // Get upload files
    protected function getUploadFiles()
    {
        global $CurrentForm, $Language;
    }

    // Load default values
    protected function loadDefaultValues()
    {
    }

    // Load form values
    protected function loadFormValues()
    {
        // Load from form
        global $CurrentForm;
        $validate = !Config("SERVER_VALIDATE");

        // Check field name 'vaccine_name' first before field var 'x_vaccine_name'
        $val = $CurrentForm->hasValue("vaccine_name") ? $CurrentForm->getValue("vaccine_name") : $CurrentForm->getValue("x_vaccine_name");
        if (!$this->vaccine_name->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->vaccine_name->Visible = false; // Disable update for API request
            } else {
                $this->vaccine_name->setFormValue($val);
            }
        }

        // Check field name 'vaccine_code' first before field var 'x_vaccine_code'
        $val = $CurrentForm->hasValue("vaccine_code") ? $CurrentForm->getValue("vaccine_code") : $CurrentForm->getValue("x_vaccine_code");
        if (!$this->vaccine_code->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->vaccine_code->Visible = false; // Disable update for API request
            } else {
                $this->vaccine_code->setFormValue($val);
            }
        }

        // Check field name 'dose_required' first before field var 'x_dose_required'
        $val = $CurrentForm->hasValue("dose_required") ? $CurrentForm->getValue("dose_required") : $CurrentForm->getValue("x_dose_required");
        if (!$this->dose_required->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->dose_required->Visible = false; // Disable update for API request
            } else {
                $this->dose_required->setFormValue($val, true, $validate);
            }
        }

        // Check field name 'dose_required_uom' first before field var 'x_dose_required_uom'
        $val = $CurrentForm->hasValue("dose_required_uom") ? $CurrentForm->getValue("dose_required_uom") : $CurrentForm->getValue("x_dose_required_uom");
        if (!$this->dose_required_uom->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->dose_required_uom->Visible = false; // Disable update for API request
            } else {
                $this->dose_required_uom->setFormValue($val);
            }
        }

        // Check field name 'admin_mode_id' first before field var 'x_admin_mode_id'
        $val = $CurrentForm->hasValue("admin_mode_id") ? $CurrentForm->getValue("admin_mode_id") : $CurrentForm->getValue("x_admin_mode_id");
        if (!$this->admin_mode_id->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->admin_mode_id->Visible = false; // Disable update for API request
            } else {
                $this->admin_mode_id->setFormValue($val);
            }
        }

        // Check field name 'admin_site_id' first before field var 'x_admin_site_id'
        $val = $CurrentForm->hasValue("admin_site_id") ? $CurrentForm->getValue("admin_site_id") : $CurrentForm->getValue("x_admin_site_id");
        if (!$this->admin_site_id->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->admin_site_id->Visible = false; // Disable update for API request
            } else {
                $this->admin_site_id->setFormValue($val);
            }
        }

        // Check field name 'vaccine_form_id' first before field var 'x_vaccine_form_id'
        $val = $CurrentForm->hasValue("vaccine_form_id") ? $CurrentForm->getValue("vaccine_form_id") : $CurrentForm->getValue("x_vaccine_form_id");
        if (!$this->vaccine_form_id->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->vaccine_form_id->Visible = false; // Disable update for API request
            } else {
                $this->vaccine_form_id->setFormValue($val);
            }
        }

        // Check field name 'expiry_date' first before field var 'x_expiry_date'
        $val = $CurrentForm->hasValue("expiry_date") ? $CurrentForm->getValue("expiry_date") : $CurrentForm->getValue("x_expiry_date");
        if (!$this->expiry_date->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->expiry_date->Visible = false; // Disable update for API request
            } else {
                $this->expiry_date->setFormValue($val, true, $validate);
            }
            $this->expiry_date->CurrentValue = UnFormatDateTime($this->expiry_date->CurrentValue, $this->expiry_date->formatPattern());
        }

        // Check field name 'target_group' first before field var 'x_target_group'
        $val = $CurrentForm->hasValue("target_group") ? $CurrentForm->getValue("target_group") : $CurrentForm->getValue("x_target_group");
        if (!$this->target_group->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->target_group->Visible = false; // Disable update for API request
            } else {
                $this->target_group->setFormValue($val);
            }
        }

        // Check field name 'storage_condition' first before field var 'x_storage_condition'
        $val = $CurrentForm->hasValue("storage_condition") ? $CurrentForm->getValue("storage_condition") : $CurrentForm->getValue("x_storage_condition");
        if (!$this->storage_condition->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->storage_condition->Visible = false; // Disable update for API request
            } else {
                $this->storage_condition->setFormValue($val);
            }
        }

        // Check field name 'description' first before field var 'x_description'
        $val = $CurrentForm->hasValue("description") ? $CurrentForm->getValue("description") : $CurrentForm->getValue("x_description");
        if (!$this->description->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->description->Visible = false; // Disable update for API request
            } else {
                $this->description->setFormValue($val);
            }
        }

        // Check field name 'entry_date' first before field var 'x_entry_date'
        $val = $CurrentForm->hasValue("entry_date") ? $CurrentForm->getValue("entry_date") : $CurrentForm->getValue("x_entry_date");
        if (!$this->entry_date->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->entry_date->Visible = false; // Disable update for API request
            } else {
                $this->entry_date->setFormValue($val);
            }
            $this->entry_date->CurrentValue = UnFormatDateTime($this->entry_date->CurrentValue, $this->entry_date->formatPattern());
        }

        // Check field name 'last_modified' first before field var 'x_last_modified'
        $val = $CurrentForm->hasValue("last_modified") ? $CurrentForm->getValue("last_modified") : $CurrentForm->getValue("x_last_modified");
        if (!$this->last_modified->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->last_modified->Visible = false; // Disable update for API request
            } else {
                $this->last_modified->setFormValue($val);
            }
            $this->last_modified->CurrentValue = UnFormatDateTime($this->last_modified->CurrentValue, $this->last_modified->formatPattern());
        }

        // Check field name 'entered_by' first before field var 'x_entered_by'
        $val = $CurrentForm->hasValue("entered_by") ? $CurrentForm->getValue("entered_by") : $CurrentForm->getValue("x_entered_by");
        if (!$this->entered_by->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->entered_by->Visible = false; // Disable update for API request
            } else {
                $this->entered_by->setFormValue($val);
            }
        }

        // Check field name 'modified_by' first before field var 'x_modified_by'
        $val = $CurrentForm->hasValue("modified_by") ? $CurrentForm->getValue("modified_by") : $CurrentForm->getValue("x_modified_by");
        if (!$this->modified_by->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->modified_by->Visible = false; // Disable update for API request
            } else {
                $this->modified_by->setFormValue($val);
            }
        }

        // Check field name 'id' first before field var 'x_id'
        $val = $CurrentForm->hasValue("id") ? $CurrentForm->getValue("id") : $CurrentForm->getValue("x_id");
    }

    // Restore form values
    public function restoreFormValues()
    {
        global $CurrentForm;
        $this->vaccine_name->CurrentValue = $this->vaccine_name->FormValue;
        $this->vaccine_code->CurrentValue = $this->vaccine_code->FormValue;
        $this->dose_required->CurrentValue = $this->dose_required->FormValue;
        $this->dose_required_uom->CurrentValue = $this->dose_required_uom->FormValue;
        $this->admin_mode_id->CurrentValue = $this->admin_mode_id->FormValue;
        $this->admin_site_id->CurrentValue = $this->admin_site_id->FormValue;
        $this->vaccine_form_id->CurrentValue = $this->vaccine_form_id->FormValue;
        $this->expiry_date->CurrentValue = $this->expiry_date->FormValue;
        $this->expiry_date->CurrentValue = UnFormatDateTime($this->expiry_date->CurrentValue, $this->expiry_date->formatPattern());
        $this->target_group->CurrentValue = $this->target_group->FormValue;
        $this->storage_condition->CurrentValue = $this->storage_condition->FormValue;
        $this->description->CurrentValue = $this->description->FormValue;
        $this->entry_date->CurrentValue = $this->entry_date->FormValue;
        $this->entry_date->CurrentValue = UnFormatDateTime($this->entry_date->CurrentValue, $this->entry_date->formatPattern());
        $this->last_modified->CurrentValue = $this->last_modified->FormValue;
        $this->last_modified->CurrentValue = UnFormatDateTime($this->last_modified->CurrentValue, $this->last_modified->formatPattern());
        $this->entered_by->CurrentValue = $this->entered_by->FormValue;
        $this->modified_by->CurrentValue = $this->modified_by->FormValue;
    }

    /**
     * Load row based on key values
     *
     * @return void
     */
    public function loadRow()
    {
        global $Security, $Language;
        $filter = $this->getRecordFilter();

        // Call Row Selecting event
        $this->rowSelecting($filter);

        // Load SQL based on filter
        $this->CurrentFilter = $filter;
        $sql = $this->getCurrentSql();
        $conn = $this->getConnection();
        $res = false;
        $row = $conn->fetchAssociative($sql);
        if ($row) {
            $res = true;
            $this->loadRowValues($row); // Load row values
        }
        return $res;
    }

    /**
     * Load row values from recordset or record
     *
     * @param Recordset|array $rs Record
     * @return void
     */
    public function loadRowValues($rs = null)
    {
        if (is_array($rs)) {
            $row = $rs;
        } elseif ($rs && property_exists($rs, "fields")) { // Recordset
            $row = $rs->fields;
        } else {
            $row = $this->newRow();
        }
        if (!$row) {
            return;
        }

        // Call Row Selected event
        $this->rowSelected($row);
        $this->id->setDbValue($row['id']);
        $this->vaccine_name->setDbValue($row['vaccine_name']);
        $this->vaccine_code->setDbValue($row['vaccine_code']);
        $this->dose_required->setDbValue($row['dose_required']);
        $this->dose_required_uom->setDbValue($row['dose_required_uom']);
        if (array_key_exists('EV__dose_required_uom', $row)) {
            $this->dose_required_uom->VirtualValue = $row['EV__dose_required_uom']; // Set up virtual field value
        } else {
            $this->dose_required_uom->VirtualValue = ""; // Clear value
        }
        $this->admin_mode_id->setDbValue($row['admin_mode_id']);
        if (array_key_exists('EV__admin_mode_id', $row)) {
            $this->admin_mode_id->VirtualValue = $row['EV__admin_mode_id']; // Set up virtual field value
        } else {
            $this->admin_mode_id->VirtualValue = ""; // Clear value
        }
        $this->admin_site_id->setDbValue($row['admin_site_id']);
        if (array_key_exists('EV__admin_site_id', $row)) {
            $this->admin_site_id->VirtualValue = $row['EV__admin_site_id']; // Set up virtual field value
        } else {
            $this->admin_site_id->VirtualValue = ""; // Clear value
        }
        $this->vaccine_form_id->setDbValue($row['vaccine_form_id']);
        if (array_key_exists('EV__vaccine_form_id', $row)) {
            $this->vaccine_form_id->VirtualValue = $row['EV__vaccine_form_id']; // Set up virtual field value
        } else {
            $this->vaccine_form_id->VirtualValue = ""; // Clear value
        }
        $this->expiry_date->setDbValue($row['expiry_date']);
        $this->target_group->setDbValue($row['target_group']);
        $this->storage_condition->setDbValue($row['storage_condition']);
        $this->description->setDbValue($row['description']);
        $this->entry_date->setDbValue($row['entry_date']);
        $this->last_modified->setDbValue($row['last_modified']);
        $this->entered_by->setDbValue($row['entered_by']);
        if (array_key_exists('EV__entered_by', $row)) {
            $this->entered_by->VirtualValue = $row['EV__entered_by']; // Set up virtual field value
        } else {
            $this->entered_by->VirtualValue = ""; // Clear value
        }
        $this->modified_by->setDbValue($row['modified_by']);
        if (array_key_exists('EV__modified_by', $row)) {
            $this->modified_by->VirtualValue = $row['EV__modified_by']; // Set up virtual field value
        } else {
            $this->modified_by->VirtualValue = ""; // Clear value
        }
    }

    // Return a row with default values
    protected function newRow()
    {
        $row = [];
        $row['id'] = $this->id->DefaultValue;
        $row['vaccine_name'] = $this->vaccine_name->DefaultValue;
        $row['vaccine_code'] = $this->vaccine_code->DefaultValue;
        $row['dose_required'] = $this->dose_required->DefaultValue;
        $row['dose_required_uom'] = $this->dose_required_uom->DefaultValue;
        $row['admin_mode_id'] = $this->admin_mode_id->DefaultValue;
        $row['admin_site_id'] = $this->admin_site_id->DefaultValue;
        $row['vaccine_form_id'] = $this->vaccine_form_id->DefaultValue;
        $row['expiry_date'] = $this->expiry_date->DefaultValue;
        $row['target_group'] = $this->target_group->DefaultValue;
        $row['storage_condition'] = $this->storage_condition->DefaultValue;
        $row['description'] = $this->description->DefaultValue;
        $row['entry_date'] = $this->entry_date->DefaultValue;
        $row['last_modified'] = $this->last_modified->DefaultValue;
        $row['entered_by'] = $this->entered_by->DefaultValue;
        $row['modified_by'] = $this->modified_by->DefaultValue;
        return $row;
    }

    // Load old record
    protected function loadOldRecord()
    {
        // Load old record
        if ($this->OldKey != "") {
            $this->setKey($this->OldKey);
            $this->CurrentFilter = $this->getRecordFilter();
            $sql = $this->getCurrentSql();
            $conn = $this->getConnection();
            $rs = LoadRecordset($sql, $conn);
            if ($rs && ($row = $rs->fields)) {
                $this->loadRowValues($row); // Load row values
                return $row;
            }
        }
        $this->loadRowValues(); // Load default row values
        return null;
    }

    // Render row values based on field settings
    public function renderRow()
    {
        global $Security, $Language, $CurrentLanguage;

        // Initialize URLs

        // Call Row_Rendering event
        $this->rowRendering();

        // Common render codes for all row types

        // id
        $this->id->RowCssClass = "row";

        // vaccine_name
        $this->vaccine_name->RowCssClass = "row";

        // vaccine_code
        $this->vaccine_code->RowCssClass = "row";

        // dose_required
        $this->dose_required->RowCssClass = "row";

        // dose_required_uom
        $this->dose_required_uom->RowCssClass = "row";

        // admin_mode_id
        $this->admin_mode_id->RowCssClass = "row";

        // admin_site_id
        $this->admin_site_id->RowCssClass = "row";

        // vaccine_form_id
        $this->vaccine_form_id->RowCssClass = "row";

        // expiry_date
        $this->expiry_date->RowCssClass = "row";

        // target_group
        $this->target_group->RowCssClass = "row";

        // storage_condition
        $this->storage_condition->RowCssClass = "row";

        // description
        $this->description->RowCssClass = "row";

        // entry_date
        $this->entry_date->RowCssClass = "row";

        // last_modified
        $this->last_modified->RowCssClass = "row";

        // entered_by
        $this->entered_by->RowCssClass = "row";

        // modified_by
        $this->modified_by->RowCssClass = "row";

        // View row
        if ($this->RowType == ROWTYPE_VIEW) {
            // id
            $this->id->ViewValue = $this->id->CurrentValue;
            $this->id->ViewValue = FormatNumber($this->id->ViewValue, $this->id->formatPattern());

            // vaccine_name
            $this->vaccine_name->ViewValue = $this->vaccine_name->CurrentValue;

            // vaccine_code
            $this->vaccine_code->ViewValue = $this->vaccine_code->CurrentValue;

            // dose_required
            $this->dose_required->ViewValue = $this->dose_required->CurrentValue;
            $this->dose_required->ViewValue = FormatNumber($this->dose_required->ViewValue, $this->dose_required->formatPattern());

            // dose_required_uom
            if ($this->dose_required_uom->VirtualValue != "") {
                $this->dose_required_uom->ViewValue = $this->dose_required_uom->VirtualValue;
            } else {
                $curVal = strval($this->dose_required_uom->CurrentValue);
                if ($curVal != "") {
                    $this->dose_required_uom->ViewValue = $this->dose_required_uom->lookupCacheOption($curVal);
                    if ($this->dose_required_uom->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->dose_required_uom->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->dose_required_uom->Lookup->renderViewRow($rswrk[0]);
                            $this->dose_required_uom->ViewValue = $this->dose_required_uom->displayValue($arwrk);
                        } else {
                            $this->dose_required_uom->ViewValue = FormatNumber($this->dose_required_uom->CurrentValue, $this->dose_required_uom->formatPattern());
                        }
                    }
                } else {
                    $this->dose_required_uom->ViewValue = null;
                }
            }

            // admin_mode_id
            if ($this->admin_mode_id->VirtualValue != "") {
                $this->admin_mode_id->ViewValue = $this->admin_mode_id->VirtualValue;
            } else {
                $curVal = strval($this->admin_mode_id->CurrentValue);
                if ($curVal != "") {
                    $this->admin_mode_id->ViewValue = $this->admin_mode_id->lookupCacheOption($curVal);
                    if ($this->admin_mode_id->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->admin_mode_id->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->admin_mode_id->Lookup->renderViewRow($rswrk[0]);
                            $this->admin_mode_id->ViewValue = $this->admin_mode_id->displayValue($arwrk);
                        } else {
                            $this->admin_mode_id->ViewValue = FormatNumber($this->admin_mode_id->CurrentValue, $this->admin_mode_id->formatPattern());
                        }
                    }
                } else {
                    $this->admin_mode_id->ViewValue = null;
                }
            }

            // admin_site_id
            if ($this->admin_site_id->VirtualValue != "") {
                $this->admin_site_id->ViewValue = $this->admin_site_id->VirtualValue;
            } else {
                $curVal = strval($this->admin_site_id->CurrentValue);
                if ($curVal != "") {
                    $this->admin_site_id->ViewValue = $this->admin_site_id->lookupCacheOption($curVal);
                    if ($this->admin_site_id->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->admin_site_id->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->admin_site_id->Lookup->renderViewRow($rswrk[0]);
                            $this->admin_site_id->ViewValue = $this->admin_site_id->displayValue($arwrk);
                        } else {
                            $this->admin_site_id->ViewValue = FormatNumber($this->admin_site_id->CurrentValue, $this->admin_site_id->formatPattern());
                        }
                    }
                } else {
                    $this->admin_site_id->ViewValue = null;
                }
            }

            // vaccine_form_id
            if ($this->vaccine_form_id->VirtualValue != "") {
                $this->vaccine_form_id->ViewValue = $this->vaccine_form_id->VirtualValue;
            } else {
                $curVal = strval($this->vaccine_form_id->CurrentValue);
                if ($curVal != "") {
                    $this->vaccine_form_id->ViewValue = $this->vaccine_form_id->lookupCacheOption($curVal);
                    if ($this->vaccine_form_id->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->vaccine_form_id->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->vaccine_form_id->Lookup->renderViewRow($rswrk[0]);
                            $this->vaccine_form_id->ViewValue = $this->vaccine_form_id->displayValue($arwrk);
                        } else {
                            $this->vaccine_form_id->ViewValue = FormatNumber($this->vaccine_form_id->CurrentValue, $this->vaccine_form_id->formatPattern());
                        }
                    }
                } else {
                    $this->vaccine_form_id->ViewValue = null;
                }
            }

            // expiry_date
            $this->expiry_date->ViewValue = $this->expiry_date->CurrentValue;
            $this->expiry_date->ViewValue = FormatDateTime($this->expiry_date->ViewValue, $this->expiry_date->formatPattern());

            // target_group
            if (strval($this->target_group->CurrentValue) != "") {
                $this->target_group->ViewValue = $this->target_group->optionCaption($this->target_group->CurrentValue);
            } else {
                $this->target_group->ViewValue = null;
            }

            // storage_condition
            $this->storage_condition->ViewValue = $this->storage_condition->CurrentValue;

            // description
            $this->description->ViewValue = $this->description->CurrentValue;

            // entry_date
            $this->entry_date->ViewValue = $this->entry_date->CurrentValue;
            $this->entry_date->ViewValue = FormatDateTime($this->entry_date->ViewValue, $this->entry_date->formatPattern());

            // last_modified
            $this->last_modified->ViewValue = $this->last_modified->CurrentValue;
            $this->last_modified->ViewValue = FormatDateTime($this->last_modified->ViewValue, $this->last_modified->formatPattern());

            // entered_by
            if ($this->entered_by->VirtualValue != "") {
                $this->entered_by->ViewValue = $this->entered_by->VirtualValue;
            } else {
                $this->entered_by->ViewValue = $this->entered_by->CurrentValue;
                $curVal = strval($this->entered_by->CurrentValue);
                if ($curVal != "") {
                    $this->entered_by->ViewValue = $this->entered_by->lookupCacheOption($curVal);
                    if ($this->entered_by->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->entered_by->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->entered_by->Lookup->renderViewRow($rswrk[0]);
                            $this->entered_by->ViewValue = $this->entered_by->displayValue($arwrk);
                        } else {
                            $this->entered_by->ViewValue = FormatNumber($this->entered_by->CurrentValue, $this->entered_by->formatPattern());
                        }
                    }
                } else {
                    $this->entered_by->ViewValue = null;
                }
            }

            // modified_by
            if ($this->modified_by->VirtualValue != "") {
                $this->modified_by->ViewValue = $this->modified_by->VirtualValue;
            } else {
                $this->modified_by->ViewValue = $this->modified_by->CurrentValue;
                $curVal = strval($this->modified_by->CurrentValue);
                if ($curVal != "") {
                    $this->modified_by->ViewValue = $this->modified_by->lookupCacheOption($curVal);
                    if ($this->modified_by->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->modified_by->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->modified_by->Lookup->renderViewRow($rswrk[0]);
                            $this->modified_by->ViewValue = $this->modified_by->displayValue($arwrk);
                        } else {
                            $this->modified_by->ViewValue = FormatNumber($this->modified_by->CurrentValue, $this->modified_by->formatPattern());
                        }
                    }
                } else {
                    $this->modified_by->ViewValue = null;
                }
            }

            // vaccine_name
            $this->vaccine_name->HrefValue = "";

            // vaccine_code
            $this->vaccine_code->HrefValue = "";

            // dose_required
            $this->dose_required->HrefValue = "";

            // dose_required_uom
            $this->dose_required_uom->HrefValue = "";

            // admin_mode_id
            $this->admin_mode_id->HrefValue = "";

            // admin_site_id
            $this->admin_site_id->HrefValue = "";

            // vaccine_form_id
            $this->vaccine_form_id->HrefValue = "";

            // expiry_date
            $this->expiry_date->HrefValue = "";

            // target_group
            $this->target_group->HrefValue = "";

            // storage_condition
            $this->storage_condition->HrefValue = "";

            // description
            $this->description->HrefValue = "";

            // entry_date
            $this->entry_date->HrefValue = "";

            // last_modified
            $this->last_modified->HrefValue = "";

            // entered_by
            $this->entered_by->HrefValue = "";

            // modified_by
            $this->modified_by->HrefValue = "";
        } elseif ($this->RowType == ROWTYPE_ADD) {
            // vaccine_name
            $this->vaccine_name->setupEditAttributes();
            if (!$this->vaccine_name->Raw) {
                $this->vaccine_name->CurrentValue = HtmlDecode($this->vaccine_name->CurrentValue);
            }
            $this->vaccine_name->EditValue = HtmlEncode($this->vaccine_name->CurrentValue);
            $this->vaccine_name->PlaceHolder = RemoveHtml($this->vaccine_name->title());

            // vaccine_code
            $this->vaccine_code->setupEditAttributes();
            if (!$this->vaccine_code->Raw) {
                $this->vaccine_code->CurrentValue = HtmlDecode($this->vaccine_code->CurrentValue);
            }
            $this->vaccine_code->EditValue = HtmlEncode($this->vaccine_code->CurrentValue);
            $this->vaccine_code->PlaceHolder = RemoveHtml($this->vaccine_code->title());

            // dose_required
            $this->dose_required->setupEditAttributes();
            $this->dose_required->EditValue = $this->dose_required->CurrentValue;
            $this->dose_required->PlaceHolder = RemoveHtml($this->dose_required->title());
            if (strval($this->dose_required->EditValue) != "" && is_numeric($this->dose_required->EditValue)) {
                $this->dose_required->EditValue = FormatNumber($this->dose_required->EditValue, null);
            }

            // dose_required_uom
            $this->dose_required_uom->setupEditAttributes();
            $curVal = trim(strval($this->dose_required_uom->CurrentValue));
            if ($curVal != "") {
                $this->dose_required_uom->ViewValue = $this->dose_required_uom->lookupCacheOption($curVal);
            } else {
                $this->dose_required_uom->ViewValue = $this->dose_required_uom->Lookup !== null && is_array($this->dose_required_uom->lookupOptions()) && count($this->dose_required_uom->lookupOptions()) > 0 ? $curVal : null;
            }
            if ($this->dose_required_uom->ViewValue !== null) { // Load from cache
                $this->dose_required_uom->EditValue = array_values($this->dose_required_uom->lookupOptions());
            } else { // Lookup from database
                if ($curVal == "") {
                    $filterWrk = "0=1";
                } else {
                    $filterWrk = SearchFilter("`id`", "=", $this->dose_required_uom->CurrentValue, DATATYPE_NUMBER, "");
                }
                $sqlWrk = $this->dose_required_uom->Lookup->getSql(true, $filterWrk, '', $this, false, true);
                $conn = Conn();
                $config = $conn->getConfiguration();
                $config->setResultCacheImpl($this->Cache);
                $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                $ari = count($rswrk);
                $arwrk = $rswrk;
                $this->dose_required_uom->EditValue = $arwrk;
            }
            $this->dose_required_uom->PlaceHolder = RemoveHtml($this->dose_required_uom->title());

            // admin_mode_id
            $this->admin_mode_id->setupEditAttributes();
            $curVal = trim(strval($this->admin_mode_id->CurrentValue));
            if ($curVal != "") {
                $this->admin_mode_id->ViewValue = $this->admin_mode_id->lookupCacheOption($curVal);
            } else {
                $this->admin_mode_id->ViewValue = $this->admin_mode_id->Lookup !== null && is_array($this->admin_mode_id->lookupOptions()) && count($this->admin_mode_id->lookupOptions()) > 0 ? $curVal : null;
            }
            if ($this->admin_mode_id->ViewValue !== null) { // Load from cache
                $this->admin_mode_id->EditValue = array_values($this->admin_mode_id->lookupOptions());
            } else { // Lookup from database
                if ($curVal == "") {
                    $filterWrk = "0=1";
                } else {
                    $filterWrk = SearchFilter("`id`", "=", $this->admin_mode_id->CurrentValue, DATATYPE_NUMBER, "");
                }
                $sqlWrk = $this->admin_mode_id->Lookup->getSql(true, $filterWrk, '', $this, false, true);
                $conn = Conn();
                $config = $conn->getConfiguration();
                $config->setResultCacheImpl($this->Cache);
                $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                $ari = count($rswrk);
                $arwrk = $rswrk;
                $this->admin_mode_id->EditValue = $arwrk;
            }
            $this->admin_mode_id->PlaceHolder = RemoveHtml($this->admin_mode_id->title());

            // admin_site_id
            $this->admin_site_id->setupEditAttributes();
            $curVal = trim(strval($this->admin_site_id->CurrentValue));
            if ($curVal != "") {
                $this->admin_site_id->ViewValue = $this->admin_site_id->lookupCacheOption($curVal);
            } else {
                $this->admin_site_id->ViewValue = $this->admin_site_id->Lookup !== null && is_array($this->admin_site_id->lookupOptions()) && count($this->admin_site_id->lookupOptions()) > 0 ? $curVal : null;
            }
            if ($this->admin_site_id->ViewValue !== null) { // Load from cache
                $this->admin_site_id->EditValue = array_values($this->admin_site_id->lookupOptions());
            } else { // Lookup from database
                if ($curVal == "") {
                    $filterWrk = "0=1";
                } else {
                    $filterWrk = SearchFilter("`id`", "=", $this->admin_site_id->CurrentValue, DATATYPE_NUMBER, "");
                }
                $sqlWrk = $this->admin_site_id->Lookup->getSql(true, $filterWrk, '', $this, false, true);
                $conn = Conn();
                $config = $conn->getConfiguration();
                $config->setResultCacheImpl($this->Cache);
                $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                $ari = count($rswrk);
                $arwrk = $rswrk;
                $this->admin_site_id->EditValue = $arwrk;
            }
            $this->admin_site_id->PlaceHolder = RemoveHtml($this->admin_site_id->title());

            // vaccine_form_id
            $this->vaccine_form_id->setupEditAttributes();
            $curVal = trim(strval($this->vaccine_form_id->CurrentValue));
            if ($curVal != "") {
                $this->vaccine_form_id->ViewValue = $this->vaccine_form_id->lookupCacheOption($curVal);
            } else {
                $this->vaccine_form_id->ViewValue = $this->vaccine_form_id->Lookup !== null && is_array($this->vaccine_form_id->lookupOptions()) && count($this->vaccine_form_id->lookupOptions()) > 0 ? $curVal : null;
            }
            if ($this->vaccine_form_id->ViewValue !== null) { // Load from cache
                $this->vaccine_form_id->EditValue = array_values($this->vaccine_form_id->lookupOptions());
            } else { // Lookup from database
                if ($curVal == "") {
                    $filterWrk = "0=1";
                } else {
                    $filterWrk = SearchFilter("`id`", "=", $this->vaccine_form_id->CurrentValue, DATATYPE_NUMBER, "");
                }
                $sqlWrk = $this->vaccine_form_id->Lookup->getSql(true, $filterWrk, '', $this, false, true);
                $conn = Conn();
                $config = $conn->getConfiguration();
                $config->setResultCacheImpl($this->Cache);
                $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                $ari = count($rswrk);
                $arwrk = $rswrk;
                $this->vaccine_form_id->EditValue = $arwrk;
            }
            $this->vaccine_form_id->PlaceHolder = RemoveHtml($this->vaccine_form_id->title());

            // expiry_date
            $this->expiry_date->setupEditAttributes();
            $this->expiry_date->EditValue = HtmlEncode(FormatDateTime($this->expiry_date->CurrentValue, $this->expiry_date->formatPattern()));
            $this->expiry_date->PlaceHolder = RemoveHtml($this->expiry_date->title());

            // target_group
            $this->target_group->setupEditAttributes();
            $this->target_group->EditValue = $this->target_group->options(true);
            $this->target_group->PlaceHolder = RemoveHtml($this->target_group->title());

            // storage_condition
            $this->storage_condition->setupEditAttributes();
            if (!$this->storage_condition->Raw) {
                $this->storage_condition->CurrentValue = HtmlDecode($this->storage_condition->CurrentValue);
            }
            $this->storage_condition->EditValue = HtmlEncode($this->storage_condition->CurrentValue);
            $this->storage_condition->PlaceHolder = RemoveHtml($this->storage_condition->title());

            // description
            $this->description->setupEditAttributes();
            $this->description->EditValue = HtmlEncode($this->description->CurrentValue);
            $this->description->PlaceHolder = RemoveHtml($this->description->title());

            // entry_date

            // last_modified

            // entered_by

            // modified_by

            // Add refer script

            // vaccine_name
            $this->vaccine_name->HrefValue = "";

            // vaccine_code
            $this->vaccine_code->HrefValue = "";

            // dose_required
            $this->dose_required->HrefValue = "";

            // dose_required_uom
            $this->dose_required_uom->HrefValue = "";

            // admin_mode_id
            $this->admin_mode_id->HrefValue = "";

            // admin_site_id
            $this->admin_site_id->HrefValue = "";

            // vaccine_form_id
            $this->vaccine_form_id->HrefValue = "";

            // expiry_date
            $this->expiry_date->HrefValue = "";

            // target_group
            $this->target_group->HrefValue = "";

            // storage_condition
            $this->storage_condition->HrefValue = "";

            // description
            $this->description->HrefValue = "";

            // entry_date
            $this->entry_date->HrefValue = "";

            // last_modified
            $this->last_modified->HrefValue = "";

            // entered_by
            $this->entered_by->HrefValue = "";

            // modified_by
            $this->modified_by->HrefValue = "";
        }
        if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) { // Add/Edit/Search row
            $this->setupFieldTitles();
        }

        // Call Row Rendered event
        if ($this->RowType != ROWTYPE_AGGREGATEINIT) {
            $this->rowRendered();
        }
    }

    // Validate form
    protected function validateForm()
    {
        global $Language, $Security;

        // Check if validation required
        if (!Config("SERVER_VALIDATE")) {
            return true;
        }
        $validateForm = true;
        if ($this->vaccine_name->Visible && $this->vaccine_name->Required) {
            if (!$this->vaccine_name->IsDetailKey && EmptyValue($this->vaccine_name->FormValue)) {
                $this->vaccine_name->addErrorMessage(str_replace("%s", $this->vaccine_name->caption(), $this->vaccine_name->RequiredErrorMessage));
            }
        }
        if ($this->vaccine_code->Visible && $this->vaccine_code->Required) {
            if (!$this->vaccine_code->IsDetailKey && EmptyValue($this->vaccine_code->FormValue)) {
                $this->vaccine_code->addErrorMessage(str_replace("%s", $this->vaccine_code->caption(), $this->vaccine_code->RequiredErrorMessage));
            }
        }
        if ($this->dose_required->Visible && $this->dose_required->Required) {
            if (!$this->dose_required->IsDetailKey && EmptyValue($this->dose_required->FormValue)) {
                $this->dose_required->addErrorMessage(str_replace("%s", $this->dose_required->caption(), $this->dose_required->RequiredErrorMessage));
            }
        }
        if (!CheckNumber($this->dose_required->FormValue)) {
            $this->dose_required->addErrorMessage($this->dose_required->getErrorMessage(false));
        }
        if ($this->dose_required_uom->Visible && $this->dose_required_uom->Required) {
            if (!$this->dose_required_uom->IsDetailKey && EmptyValue($this->dose_required_uom->FormValue)) {
                $this->dose_required_uom->addErrorMessage(str_replace("%s", $this->dose_required_uom->caption(), $this->dose_required_uom->RequiredErrorMessage));
            }
        }
        if ($this->admin_mode_id->Visible && $this->admin_mode_id->Required) {
            if (!$this->admin_mode_id->IsDetailKey && EmptyValue($this->admin_mode_id->FormValue)) {
                $this->admin_mode_id->addErrorMessage(str_replace("%s", $this->admin_mode_id->caption(), $this->admin_mode_id->RequiredErrorMessage));
            }
        }
        if ($this->admin_site_id->Visible && $this->admin_site_id->Required) {
            if (!$this->admin_site_id->IsDetailKey && EmptyValue($this->admin_site_id->FormValue)) {
                $this->admin_site_id->addErrorMessage(str_replace("%s", $this->admin_site_id->caption(), $this->admin_site_id->RequiredErrorMessage));
            }
        }
        if ($this->vaccine_form_id->Visible && $this->vaccine_form_id->Required) {
            if (!$this->vaccine_form_id->IsDetailKey && EmptyValue($this->vaccine_form_id->FormValue)) {
                $this->vaccine_form_id->addErrorMessage(str_replace("%s", $this->vaccine_form_id->caption(), $this->vaccine_form_id->RequiredErrorMessage));
            }
        }
        if ($this->expiry_date->Visible && $this->expiry_date->Required) {
            if (!$this->expiry_date->IsDetailKey && EmptyValue($this->expiry_date->FormValue)) {
                $this->expiry_date->addErrorMessage(str_replace("%s", $this->expiry_date->caption(), $this->expiry_date->RequiredErrorMessage));
            }
        }
        if (!CheckDate($this->expiry_date->FormValue, $this->expiry_date->formatPattern())) {
            $this->expiry_date->addErrorMessage($this->expiry_date->getErrorMessage(false));
        }
        if ($this->target_group->Visible && $this->target_group->Required) {
            if (!$this->target_group->IsDetailKey && EmptyValue($this->target_group->FormValue)) {
                $this->target_group->addErrorMessage(str_replace("%s", $this->target_group->caption(), $this->target_group->RequiredErrorMessage));
            }
        }
        if ($this->storage_condition->Visible && $this->storage_condition->Required) {
            if (!$this->storage_condition->IsDetailKey && EmptyValue($this->storage_condition->FormValue)) {
                $this->storage_condition->addErrorMessage(str_replace("%s", $this->storage_condition->caption(), $this->storage_condition->RequiredErrorMessage));
            }
        }
        if ($this->description->Visible && $this->description->Required) {
            if (!$this->description->IsDetailKey && EmptyValue($this->description->FormValue)) {
                $this->description->addErrorMessage(str_replace("%s", $this->description->caption(), $this->description->RequiredErrorMessage));
            }
        }
        if ($this->entry_date->Visible && $this->entry_date->Required) {
            if (!$this->entry_date->IsDetailKey && EmptyValue($this->entry_date->FormValue)) {
                $this->entry_date->addErrorMessage(str_replace("%s", $this->entry_date->caption(), $this->entry_date->RequiredErrorMessage));
            }
        }
        if ($this->last_modified->Visible && $this->last_modified->Required) {
            if (!$this->last_modified->IsDetailKey && EmptyValue($this->last_modified->FormValue)) {
                $this->last_modified->addErrorMessage(str_replace("%s", $this->last_modified->caption(), $this->last_modified->RequiredErrorMessage));
            }
        }
        if ($this->entered_by->Visible && $this->entered_by->Required) {
            if (!$this->entered_by->IsDetailKey && EmptyValue($this->entered_by->FormValue)) {
                $this->entered_by->addErrorMessage(str_replace("%s", $this->entered_by->caption(), $this->entered_by->RequiredErrorMessage));
            }
        }
        if ($this->modified_by->Visible && $this->modified_by->Required) {
            if (!$this->modified_by->IsDetailKey && EmptyValue($this->modified_by->FormValue)) {
                $this->modified_by->addErrorMessage(str_replace("%s", $this->modified_by->caption(), $this->modified_by->RequiredErrorMessage));
            }
        }

        // Return validate result
        $validateForm = $validateForm && !$this->hasInvalidFields();

        // Call Form_CustomValidate event
        $formCustomError = "";
        $validateForm = $validateForm && $this->formCustomValidate($formCustomError);
        if ($formCustomError != "") {
            $this->setFailureMessage($formCustomError);
        }
        return $validateForm;
    }

    // Add record
    protected function addRow($rsold = null)
    {
        global $Language, $Security;

        // Set new row
        $rsnew = [];

        // vaccine_name
        $this->vaccine_name->setDbValueDef($rsnew, $this->vaccine_name->CurrentValue, false);

        // vaccine_code
        $this->vaccine_code->setDbValueDef($rsnew, $this->vaccine_code->CurrentValue, false);

        // dose_required
        $this->dose_required->setDbValueDef($rsnew, $this->dose_required->CurrentValue, false);

        // dose_required_uom
        $this->dose_required_uom->setDbValueDef($rsnew, $this->dose_required_uom->CurrentValue, false);

        // admin_mode_id
        $this->admin_mode_id->setDbValueDef($rsnew, $this->admin_mode_id->CurrentValue, false);

        // admin_site_id
        $this->admin_site_id->setDbValueDef($rsnew, $this->admin_site_id->CurrentValue, false);

        // vaccine_form_id
        $this->vaccine_form_id->setDbValueDef($rsnew, $this->vaccine_form_id->CurrentValue, false);

        // expiry_date
        $this->expiry_date->setDbValueDef($rsnew, UnFormatDateTime($this->expiry_date->CurrentValue, $this->expiry_date->formatPattern()), false);

        // target_group
        $this->target_group->setDbValueDef($rsnew, $this->target_group->CurrentValue, false);

        // storage_condition
        $this->storage_condition->setDbValueDef($rsnew, $this->storage_condition->CurrentValue, false);

        // description
        $this->description->setDbValueDef($rsnew, $this->description->CurrentValue, false);

        // entry_date
        $this->entry_date->CurrentValue = $this->entry_date->getAutoUpdateValue(); // PHP
        $this->entry_date->setDbValueDef($rsnew, $this->entry_date->CurrentValue);

        // last_modified
        $this->last_modified->CurrentValue = $this->last_modified->getAutoUpdateValue(); // PHP
        $this->last_modified->setDbValueDef($rsnew, $this->last_modified->CurrentValue);

        // entered_by
        $this->entered_by->CurrentValue = $this->entered_by->getAutoUpdateValue(); // PHP
        $this->entered_by->setDbValueDef($rsnew, $this->entered_by->CurrentValue);

        // modified_by
        $this->modified_by->CurrentValue = $this->modified_by->getAutoUpdateValue(); // PHP
        $this->modified_by->setDbValueDef($rsnew, $this->modified_by->CurrentValue);

        // Update current values
        $this->setCurrentValues($rsnew);
        if ($this->vaccine_name->CurrentValue != "") { // Check field with unique index
            $filter = "(`vaccine_name` = '" . AdjustSql($this->vaccine_name->CurrentValue, $this->Dbid) . "')";
            $rsChk = $this->loadRs($filter)->fetch();
            if ($rsChk !== false) {
                $idxErrMsg = str_replace("%f", $this->vaccine_name->caption(), $Language->phrase("DupIndex"));
                $idxErrMsg = str_replace("%v", $this->vaccine_name->CurrentValue, $idxErrMsg);
                $this->setFailureMessage($idxErrMsg);
                return false;
            }
        }
        $conn = $this->getConnection();

        // Load db values from old row
        $this->loadDbValues($rsold);

        // Call Row Inserting event
        $insertRow = $this->rowInserting($rsold, $rsnew);
        if ($insertRow) {
            $addRow = $this->insert($rsnew);
            if ($addRow) {
            } elseif (!EmptyValue($this->DbErrorMessage)) { // Show database error
                $this->setFailureMessage($this->DbErrorMessage);
            }
        } else {
            if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {
                // Use the message, do nothing
            } elseif ($this->CancelMessage != "") {
                $this->setFailureMessage($this->CancelMessage);
                $this->CancelMessage = "";
            } else {
                $this->setFailureMessage($Language->phrase("InsertCancelled"));
            }
            $addRow = false;
        }
        if ($addRow) {
            // Call Row Inserted event
            $this->rowInserted($rsold, $rsnew);
        }

        // Write JSON response
        if (IsJsonResponse() && $addRow) {
            $row = $this->getRecordsFromRecordset([$rsnew], true);
            $table = $this->TableVar;
            WriteJson(["success" => true, "action" => Config("API_ADD_ACTION"), $table => $row]);
        }
        return $addRow;
    }

    // Set up Breadcrumb
    protected function setupBreadcrumb()
    {
        global $Breadcrumb, $Language;
        $Breadcrumb = new Breadcrumb("index");
        $url = CurrentUrl();
        $Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("tbvaccinelist"), "", $this->TableVar, true);
        $pageId = ($this->isCopy()) ? "Copy" : "Add";
        $Breadcrumb->add("add", $pageId, $url);
    }

    // Setup lookup options
    public function setupLookupOptions($fld)
    {
        if ($fld->Lookup !== null && $fld->Lookup->Options === null) {
            // Get default connection and filter
            $conn = $this->getConnection();
            $lookupFilter = "";

            // No need to check any more
            $fld->Lookup->Options = [];

            // Set up lookup SQL and connection
            switch ($fld->FieldVar) {
                case "x_dose_required_uom":
                    break;
                case "x_admin_mode_id":
                    break;
                case "x_admin_site_id":
                    break;
                case "x_vaccine_form_id":
                    break;
                case "x_target_group":
                    break;
                case "x_entered_by":
                    break;
                case "x_modified_by":
                    break;
                default:
                    $lookupFilter = "";
                    break;
            }

            // Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
            $sql = $fld->Lookup->getSql(false, "", $lookupFilter, $this);

            // Set up lookup cache
            if (!$fld->hasLookupOptions() && $fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0 && count($fld->Lookup->FilterFields) == 0) {
                $totalCnt = $this->getRecordCount($sql, $conn);
                if ($totalCnt > $fld->LookupCacheCount) { // Total count > cache count, do not cache
                    return;
                }
                $rows = $conn->executeQuery($sql)->fetchAll();
                $ar = [];
                foreach ($rows as $row) {
                    $row = $fld->Lookup->renderViewRow($row, Container($fld->Lookup->LinkTable));
                    $key = $row["lf"];
                    if (IsFloatType($fld->Type)) { // Handle float field
                        $key = (float)$key;
                    }
                    $ar[strval($key)] = $row;
                }
                $fld->Lookup->Options = $ar;
            }
        }
    }

    // Page Load event
    public function pageLoad()
    {
        //Log("Page Load");
    	$GLOBALS["Language"]->setPhrase("add", "Create New Record");  
    	$GLOBALS["Language"]->setPhrase("addbtn", "<i class='fa fa-floppy-disk fa-1x'></i> Save Record"); 
    	$GLOBALS["Language"]->setPhrase("cancelbtn", "<i class='fa fa-close fa-1x'></i> Cancel Transaction");
    	$GLOBALS["Language"]->setPhrase("addsuccess", "Transaction Completed successfully");
    }

    // Page Unload event
    public function pageUnload()
    {
        //Log("Page Unload");
    }

    // Page Redirecting event
    public function pageRedirecting(&$url)
    {
        // Example:
        //$url = "your URL";
    }

    // Message Showing event
    // $type = ''|'success'|'failure'|'warning'
    public function messageShowing(&$msg, $type)
    {
        if ($type == 'success') {
            //$msg = "your success message";
        } elseif ($type == 'failure') {
            //$msg = "your failure message";
        } elseif ($type == 'warning') {
            //$msg = "your warning message";
        } else {
            //$msg = "your message";
        }
    }

    // Page Render event
    public function pageRender()
    {
        //Log("Page Render");
    }

    // Page Data Rendering event
    public function pageDataRendering(&$header)
    {
        // Example:
        //$header = "your header";

    	//Warning about mandatory fields
        $header .= '<div class="callout callout-warning rounded-0 py-1" style="font-size: 13px; color: #c23321 !important; border-color: #c23321;background-color: #fff3cd !important;">';
        $header .= 'All Form Fields Marked With an Asterisk (*) are Mandatory.';
    	$header .= '</div>';  
    }

    // Page Data Rendered event
    public function pageDataRendered(&$footer)
    {
        // Example:
        //$footer = "your footer";
    }

    // Page Breaking event
    public function pageBreaking(&$break, &$content)
    {
        // Example:
        //$break = false; // Skip page break, or
        //$content = "<div style=\"break-after:page;\"></div>"; // Modify page break content
    }

    // Form Custom Validate event
    public function formCustomValidate(&$customError)
    {
        // Return error message in $customError
        return true;
    }
}
