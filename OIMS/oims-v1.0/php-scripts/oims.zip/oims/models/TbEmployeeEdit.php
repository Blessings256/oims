<?php

namespace PHPMaker2023\OIMS;

use Doctrine\DBAL\ParameterType;
use Doctrine\DBAL\FetchMode;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;

/**
 * Page class
 */
class TbEmployeeEdit extends TbEmployee
{
    use MessagesTrait;

    // Page ID
    public $PageID = "edit";

    // Project ID
    public $ProjectID = PROJECT_ID;

    // Page object name
    public $PageObjName = "TbEmployeeEdit";

    // View file path
    public $View = null;

    // Title
    public $Title = null; // Title for <title> tag

    // Rendering View
    public $RenderingView = false;

    // CSS class/style
    public $CurrentPageName = "tbemployeeedit";

    // Page headings
    public $Heading = "";
    public $Subheading = "";
    public $PageHeader;
    public $PageFooter;

    // Page layout
    public $UseLayout = true;

    // Page terminated
    private $terminated = false;

    // Page heading
    public function pageHeading()
    {
        global $Language;
        if ($this->Heading != "") {
            return $this->Heading;
        }
        if (method_exists($this, "tableCaption")) {
            return $this->tableCaption();
        }
        return "";
    }

    // Page subheading
    public function pageSubheading()
    {
        global $Language;
        if ($this->Subheading != "") {
            return $this->Subheading;
        }
        if ($this->TableName) {
            return $Language->phrase($this->PageID);
        }
        return "";
    }

    // Page name
    public function pageName()
    {
        return CurrentPageName();
    }

    // Page URL
    public function pageUrl($withArgs = true)
    {
        $route = GetRoute();
        $args = RemoveXss($route->getArguments());
        if (!$withArgs) {
            foreach ($args as $key => &$val) {
                $val = "";
            }
            unset($val);
        }
        return rtrim(UrlFor($route->getName(), $args), "/") . "?";
    }

    // Show Page Header
    public function showPageHeader()
    {
        $header = $this->PageHeader;
        $this->pageDataRendering($header);
        if ($header != "") { // Header exists, display
            echo '<p id="ew-page-header">' . $header . '</p>';
        }
    }

    // Show Page Footer
    public function showPageFooter()
    {
        $footer = $this->PageFooter;
        $this->pageDataRendered($footer);
        if ($footer != "") { // Footer exists, display
            echo '<p id="ew-page-footer">' . $footer . '</p>';
        }
    }

    // Set field visibility
    public function setVisibility()
    {
        $this->id->setVisibility();
        $this->employee_number->setVisibility();
        $this->first_name->setVisibility();
        $this->last_name->setVisibility();
        $this->other_name->setVisibility();
        $this->job_tile->setVisibility();
        $this->pri_phone_no->setVisibility();
        $this->alt_phone_no->setVisibility();
        $this->personal_email->setVisibility();
        $this->official_email->setVisibility();
        $this->department->setVisibility();
        $this->hire_date->setVisibility();
        $this->current_status->setVisibility();
        $this->tin_number->setVisibility();
        $this->nssf_number->setVisibility();
        $this->salary_amount->setVisibility();
        $this->employement_type->setVisibility();
        $this->work_schedule->setVisibility();
        $this->sex->setVisibility();
        $this->entry_date->setVisibility();
        $this->last_modified->setVisibility();
        $this->entered_by->setVisibility();
        $this->modified_by->setVisibility();
    }

    // Constructor
    public function __construct()
    {
        parent::__construct();
        global $Language, $DashboardReport, $DebugTimer, $UserTable;
        $this->TableVar = 'tb_employee';
        $this->TableName = 'tb_employee';

        // Table CSS class
        $this->TableClass = "table table-striped table-bordered table-hover table-sm ew-desktop-table ew-edit-table";

        // Initialize
        $GLOBALS["Page"] = &$this;

        // Language object
        $Language = Container("language");

        // Table object (tb_employee)
        if (!isset($GLOBALS["tb_employee"]) || get_class($GLOBALS["tb_employee"]) == PROJECT_NAMESPACE . "tb_employee") {
            $GLOBALS["tb_employee"] = &$this;
        }

        // Table name (for backward compatibility only)
        if (!defined(PROJECT_NAMESPACE . "TABLE_NAME")) {
            define(PROJECT_NAMESPACE . "TABLE_NAME", 'tb_employee');
        }

        // Start timer
        $DebugTimer = Container("timer");

        // Debug message
        LoadDebugMessage();

        // Open connection
        $GLOBALS["Conn"] ??= $this->getConnection();

        // User table object
        $UserTable = Container("usertable");
    }

    // Get content from stream
    public function getContents(): string
    {
        global $Response;
        return is_object($Response) ? $Response->getBody() : ob_get_clean();
    }

    // Is lookup
    public function isLookup()
    {
        return SameText(Route(0), Config("API_LOOKUP_ACTION"));
    }

    // Is AutoFill
    public function isAutoFill()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autofill");
    }

    // Is AutoSuggest
    public function isAutoSuggest()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autosuggest");
    }

    // Is modal lookup
    public function isModalLookup()
    {
        return $this->isLookup() && SameText(Post("ajax"), "modal");
    }

    // Is terminated
    public function isTerminated()
    {
        return $this->terminated;
    }

    /**
     * Terminate page
     *
     * @param string $url URL for direction
     * @return void
     */
    public function terminate($url = "")
    {
        if ($this->terminated) {
            return;
        }
        global $TempImages, $DashboardReport, $Response;

        // Page is terminated
        $this->terminated = true;

        // Page Unload event
        if (method_exists($this, "pageUnload")) {
            $this->pageUnload();
        }

        // Global Page Unloaded event (in userfn*.php)
        Page_Unloaded();
        if (!IsApi() && method_exists($this, "pageRedirecting")) {
            $this->pageRedirecting($url);
        }

        // Close connection
        CloseConnections();

        // Return for API
        if (IsApi()) {
            $res = $url === true;
            if (!$res) { // Show response for API
                $ar = array_merge($this->getMessages(), $url ? ["url" => GetUrl($url)] : []);
                WriteJson($ar);
            }
            $this->clearMessages(); // Clear messages for API request
            return;
        } else { // Check if response is JSON
            if (StartsString("application/json", $Response->getHeaderLine("Content-type")) && $Response->getBody()->getSize()) { // With JSON response
                $this->clearMessages();
                return;
            }
        }

        // Go to URL if specified
        if ($url != "") {
            if (!Config("DEBUG") && ob_get_length()) {
                ob_end_clean();
            }

            // Handle modal response (Assume return to modal for simplicity)
            if ($this->IsModal) { // Show as modal
                $result = ["url" => GetUrl($url), "modal" => "1"];
                $pageName = GetPageName($url);
                if ($pageName != $this->getListUrl()) { // Not List page => View page
                    $result["caption"] = $this->getModalCaption($pageName);
                    $result["view"] = $pageName == "tbemployeeview"; // If View page, no primary button
                } else { // List page
                    // $result["list"] = $this->PageID == "search"; // Refresh List page if current page is Search page
                    $result["error"] = $this->getFailureMessage(); // List page should not be shown as modal => error
                    $this->clearFailureMessage();
                }
                WriteJson($result);
            } else {
                SaveDebugMessage();
                Redirect(GetUrl($url));
            }
        }
        return; // Return to controller
    }

    // Get records from recordset
    protected function getRecordsFromRecordset($rs, $current = false)
    {
        $rows = [];
        if (is_object($rs)) { // Recordset
            while ($rs && !$rs->EOF) {
                $this->loadRowValues($rs); // Set up DbValue/CurrentValue
                $row = $this->getRecordFromArray($rs->fields);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
                $rs->moveNext();
            }
        } elseif (is_array($rs)) {
            foreach ($rs as $ar) {
                $row = $this->getRecordFromArray($ar);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
            }
        }
        return $rows;
    }

    // Get record from array
    protected function getRecordFromArray($ar)
    {
        $row = [];
        if (is_array($ar)) {
            foreach ($ar as $fldname => $val) {
                if (array_key_exists($fldname, $this->Fields) && ($this->Fields[$fldname]->Visible || $this->Fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
                    $fld = &$this->Fields[$fldname];
                    if ($fld->HtmlTag == "FILE") { // Upload field
                        if (EmptyValue($val)) {
                            $row[$fldname] = null;
                        } else {
                            if ($fld->DataType == DATATYPE_BLOB) {
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . $fld->Param . "/" . rawurlencode($this->getRecordKeyValue($ar))));
                                $row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
                            } elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $val)));
                                $row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
                            } else { // Multiple files
                                $files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
                                $ar = [];
                                foreach ($files as $file) {
                                    $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                        "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $file)));
                                    if (!EmptyValue($file)) {
                                        $ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
                                    }
                                }
                                $row[$fldname] = $ar;
                            }
                        }
                    } else {
                        $row[$fldname] = $val;
                    }
                }
            }
        }
        return $row;
    }

    // Get record key value from array
    protected function getRecordKeyValue($ar)
    {
        $key = "";
        if (is_array($ar)) {
            $key .= @$ar['id'];
        }
        return $key;
    }

    /**
     * Hide fields for add/edit
     *
     * @return void
     */
    protected function hideFieldsForAddEdit()
    {
        if ($this->isAdd() || $this->isCopy() || $this->isGridAdd()) {
            $this->id->Visible = false;
        }
    }

    // Lookup data
    public function lookup($ar = null)
    {
        global $Language, $Security;

        // Get lookup object
        $fieldName = $ar["field"] ?? Post("field");
        $lookup = $this->Fields[$fieldName]->Lookup;
        $name = $ar["name"] ?? Post("name");
        $isQuery = ContainsString($name, "query_builder_rule");
        if ($isQuery) {
            $lookup->FilterFields = []; // Skip parent fields if any
        }

        // Get lookup parameters
        $lookupType = $ar["ajax"] ?? Post("ajax", "unknown");
        $pageSize = -1;
        $offset = -1;
        $searchValue = "";
        if (SameText($lookupType, "modal") || SameText($lookupType, "filter")) {
            $searchValue = $ar["q"] ?? Param("q") ?? $ar["sv"] ?? Post("sv", "");
            $pageSize = $ar["n"] ?? Param("n") ?? $ar["recperpage"] ?? Post("recperpage", 10);
        } elseif (SameText($lookupType, "autosuggest")) {
            $searchValue = $ar["q"] ?? Param("q", "");
            $pageSize = $ar["n"] ?? Param("n", -1);
            $pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
            if ($pageSize <= 0) {
                $pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
            }
        }
        $start = $ar["start"] ?? Param("start", -1);
        $start = is_numeric($start) ? (int)$start : -1;
        $page = $ar["page"] ?? Param("page", -1);
        $page = is_numeric($page) ? (int)$page : -1;
        $offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
        $userSelect = Decrypt($ar["s"] ?? Post("s", ""));
        $userFilter = Decrypt($ar["f"] ?? Post("f", ""));
        $userOrderBy = Decrypt($ar["o"] ?? Post("o", ""));
        $keys = $ar["keys"] ?? Post("keys");
        $lookup->LookupType = $lookupType; // Lookup type
        $lookup->FilterValues = []; // Clear filter values first
        if ($keys !== null) { // Selected records from modal
            if (is_array($keys)) {
                $keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
            }
            $lookup->FilterFields = []; // Skip parent fields if any
            $lookup->FilterValues[] = $keys; // Lookup values
            $pageSize = -1; // Show all records
        } else { // Lookup values
            $lookup->FilterValues[] = $ar["v0"] ?? $ar["lookupValue"] ?? Post("v0", Post("lookupValue", ""));
        }
        $cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
        for ($i = 1; $i <= $cnt; $i++) {
            $lookup->FilterValues[] = $ar["v" . $i] ?? Post("v" . $i, "");
        }
        $lookup->SearchValue = $searchValue;
        $lookup->PageSize = $pageSize;
        $lookup->Offset = $offset;
        if ($userSelect != "") {
            $lookup->UserSelect = $userSelect;
        }
        if ($userFilter != "") {
            $lookup->UserFilter = $userFilter;
        }
        if ($userOrderBy != "") {
            $lookup->UserOrderBy = $userOrderBy;
        }
        return $lookup->toJson($this, !is_array($ar)); // Use settings from current page
    }

    // Properties
    public $FormClassName = "ew-form ew-edit-form overlay-wrapper";
    public $IsModal = false;
    public $IsMobileOrModal = false;
    public $DbMasterFilter;
    public $DbDetailFilter;
    public $HashValue; // Hash Value
    public $DisplayRecords = 1;
    public $StartRecord;
    public $StopRecord;
    public $TotalRecords = 0;
    public $RecordRange = 10;
    public $RecordCount;

    /**
     * Page run
     *
     * @return void
     */
    public function run()
    {
        global $ExportType, $UserProfile, $Language, $Security, $CurrentForm, $SkipHeaderFooter;

        // Is modal
        $this->IsModal = ConvertToBool(Param("modal"));
        $this->UseLayout = $this->UseLayout && !$this->IsModal;

        // Use layout
        $this->UseLayout = $this->UseLayout && ConvertToBool(Param(Config("PAGE_LAYOUT"), true));

        // View
        $this->View = Get(Config("VIEW"));

        // Create form object
        $CurrentForm = new HttpForm();
        $this->CurrentAction = Param("action"); // Set up current action
        $this->setVisibility();

        // Set lookup cache
        if (!in_array($this->PageID, Config("LOOKUP_CACHE_PAGE_IDS"))) {
            $this->setUseLookupCache(false);
        }

        // Global Page Loading event (in userfn*.php)
        Page_Loading();

        // Page Load event
        if (method_exists($this, "pageLoad")) {
            $this->pageLoad();
        }

        // Hide fields for add/edit
        if (!$this->UseAjaxActions) {
            $this->hideFieldsForAddEdit();
        }
        // Use inline delete
        if ($this->UseAjaxActions) {
            $this->InlineDelete = true;
        }

        // Set up lookup cache
        $this->setupLookupOptions($this->current_status);
        $this->setupLookupOptions($this->employement_type);
        $this->setupLookupOptions($this->work_schedule);
        $this->setupLookupOptions($this->sex);
        $this->setupLookupOptions($this->entered_by);
        $this->setupLookupOptions($this->modified_by);

        // Check modal
        if ($this->IsModal) {
            $SkipHeaderFooter = true;
        }
        $this->IsMobileOrModal = IsMobile() || $this->IsModal;
        $loaded = false;
        $postBack = false;

        // Set up current action and primary key
        if (IsApi()) {
            // Load key values
            $loaded = true;
            if (($keyValue = Get("id") ?? Key(0) ?? Route(2)) !== null) {
                $this->id->setQueryStringValue($keyValue);
                $this->id->setOldValue($this->id->QueryStringValue);
            } elseif (Post("id") !== null) {
                $this->id->setFormValue(Post("id"));
                $this->id->setOldValue($this->id->FormValue);
            } else {
                $loaded = false; // Unable to load key
            }

            // Load record
            if ($loaded) {
                $loaded = $this->loadRow();
            }
            if (!$loaded) {
                $this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
                $this->terminate();
                return;
            }
            $this->CurrentAction = "update"; // Update record directly
            $this->OldKey = $this->getKey(true); // Get from CurrentValue
            $postBack = true;
        } else {
            if (Post("action", "") !== "") {
                $this->CurrentAction = Post("action"); // Get action code
                if (!$this->isShow()) { // Not reload record, handle as postback
                    $postBack = true;
                }

                // Get key from Form
                $this->setKey(Post($this->OldKeyName), $this->isShow());
            } else {
                $this->CurrentAction = "show"; // Default action is display

                // Load key from QueryString
                $loadByQuery = false;
                if (($keyValue = Get("id") ?? Route("id")) !== null) {
                    $this->id->setQueryStringValue($keyValue);
                    $loadByQuery = true;
                } else {
                    $this->id->CurrentValue = null;
                }
            }

            // Load recordset
            if ($this->isShow()) {
                    // Load current record
                    $loaded = $this->loadRow();
                $this->OldKey = $loaded ? $this->getKey(true) : ""; // Get from CurrentValue
            }
        }

        // Process form if post back
        if ($postBack) {
            $this->loadFormValues(); // Get form values
        }

        // Validate form if post back
        if ($postBack) {
            if (!$this->validateForm()) {
                $this->EventCancelled = true; // Event cancelled
                $this->restoreFormValues();
                if (IsApi()) {
                    $this->terminate();
                    return;
                } else {
                    $this->CurrentAction = ""; // Form error, reset action
                }
            }
        }

        // Perform current action
        switch ($this->CurrentAction) {
            case "show": // Get a record to display
                    if (!$loaded) { // Load record based on key
                        if ($this->getFailureMessage() == "") {
                            $this->setFailureMessage($Language->phrase("NoRecord")); // No record found
                        }
                        $this->terminate("tbemployeelist"); // No matching record, return to list
                        return;
                    }
                break;
            case "update": // Update
                $returnUrl = $this->getReturnUrl();
                if (GetPageName($returnUrl) == "tbemployeelist") {
                    $returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
                }
                $this->SendEmail = true; // Send email on update success
                if ($this->editRow()) { // Update record based on key
                    if ($this->getSuccessMessage() == "") {
                        $this->setSuccessMessage($Language->phrase("UpdateSuccess")); // Update success
                    }

                    // Handle UseAjaxActions with return page
                    if ($this->IsModal && $this->UseAjaxActions) {
                        $this->IsModal = false;
                        if (GetPageName($returnUrl) != "tbemployeelist") {
                            Container("flash")->addMessage("Return-Url", $returnUrl); // Save return URL
                            $returnUrl = "tbemployeelist"; // Return list page content
                        }
                    }
                    if (IsJsonResponse()) {
                        $this->terminate(true);
                        return;
                    } else {
                        $this->terminate($returnUrl); // Return to caller
                        return;
                    }
                } elseif (IsApi()) { // API request, return
                    $this->terminate();
                    return;
                } elseif ($this->IsModal && $this->UseAjaxActions) { // Return JSON error message
                    WriteJson([ "success" => false, "validation" => $this->getValidationErrors(), "error" => $this->getFailureMessage() ]);
                    $this->clearFailureMessage();
                    $this->terminate();
                    return;
                } elseif ($this->getFailureMessage() == $Language->phrase("NoRecord")) {
                    $this->terminate($returnUrl); // Return to caller
                    return;
                } else {
                    $this->EventCancelled = true; // Event cancelled
                    $this->restoreFormValues(); // Restore form values if update failed
                }
        }

        // Set up Breadcrumb
        $this->setupBreadcrumb();

        // Render the record
        $this->RowType = ROWTYPE_EDIT; // Render as Edit
        $this->resetAttributes();
        $this->renderRow();

        // Set LoginStatus / Page_Rendering / Page_Render
        if (!IsApi() && !$this->isTerminated()) {
            // Setup login status
            SetupLoginStatus();

            // Pass login status to client side
            SetClientVar("login", LoginStatus());

            // Global Page Rendering event (in userfn*.php)
            Page_Rendering();

            // Page Render event
            if (method_exists($this, "pageRender")) {
                $this->pageRender();
            }

            // Render search option
            if (method_exists($this, "renderSearchOptions")) {
                $this->renderSearchOptions();
            }
        }
    }

    // Get upload files
    protected function getUploadFiles()
    {
        global $CurrentForm, $Language;
    }

    // Load form values
    protected function loadFormValues()
    {
        // Load from form
        global $CurrentForm;
        $validate = !Config("SERVER_VALIDATE");

        // Check field name 'id' first before field var 'x_id'
        $val = $CurrentForm->hasValue("id") ? $CurrentForm->getValue("id") : $CurrentForm->getValue("x_id");
        if (!$this->id->IsDetailKey) {
            $this->id->setFormValue($val);
        }

        // Check field name 'employee_number' first before field var 'x_employee_number'
        $val = $CurrentForm->hasValue("employee_number") ? $CurrentForm->getValue("employee_number") : $CurrentForm->getValue("x_employee_number");
        if (!$this->employee_number->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->employee_number->Visible = false; // Disable update for API request
            } else {
                $this->employee_number->setFormValue($val);
            }
        }

        // Check field name 'first_name' first before field var 'x_first_name'
        $val = $CurrentForm->hasValue("first_name") ? $CurrentForm->getValue("first_name") : $CurrentForm->getValue("x_first_name");
        if (!$this->first_name->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->first_name->Visible = false; // Disable update for API request
            } else {
                $this->first_name->setFormValue($val);
            }
        }

        // Check field name 'last_name' first before field var 'x_last_name'
        $val = $CurrentForm->hasValue("last_name") ? $CurrentForm->getValue("last_name") : $CurrentForm->getValue("x_last_name");
        if (!$this->last_name->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->last_name->Visible = false; // Disable update for API request
            } else {
                $this->last_name->setFormValue($val);
            }
        }

        // Check field name 'other_name' first before field var 'x_other_name'
        $val = $CurrentForm->hasValue("other_name") ? $CurrentForm->getValue("other_name") : $CurrentForm->getValue("x_other_name");
        if (!$this->other_name->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->other_name->Visible = false; // Disable update for API request
            } else {
                $this->other_name->setFormValue($val);
            }
        }

        // Check field name 'job_tile' first before field var 'x_job_tile'
        $val = $CurrentForm->hasValue("job_tile") ? $CurrentForm->getValue("job_tile") : $CurrentForm->getValue("x_job_tile");
        if (!$this->job_tile->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->job_tile->Visible = false; // Disable update for API request
            } else {
                $this->job_tile->setFormValue($val);
            }
        }

        // Check field name 'pri_phone_no' first before field var 'x_pri_phone_no'
        $val = $CurrentForm->hasValue("pri_phone_no") ? $CurrentForm->getValue("pri_phone_no") : $CurrentForm->getValue("x_pri_phone_no");
        if (!$this->pri_phone_no->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->pri_phone_no->Visible = false; // Disable update for API request
            } else {
                $this->pri_phone_no->setFormValue($val);
            }
        }

        // Check field name 'alt_phone_no' first before field var 'x_alt_phone_no'
        $val = $CurrentForm->hasValue("alt_phone_no") ? $CurrentForm->getValue("alt_phone_no") : $CurrentForm->getValue("x_alt_phone_no");
        if (!$this->alt_phone_no->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->alt_phone_no->Visible = false; // Disable update for API request
            } else {
                $this->alt_phone_no->setFormValue($val);
            }
        }

        // Check field name 'personal_email' first before field var 'x_personal_email'
        $val = $CurrentForm->hasValue("personal_email") ? $CurrentForm->getValue("personal_email") : $CurrentForm->getValue("x_personal_email");
        if (!$this->personal_email->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->personal_email->Visible = false; // Disable update for API request
            } else {
                $this->personal_email->setFormValue($val);
            }
        }

        // Check field name 'official_email' first before field var 'x_official_email'
        $val = $CurrentForm->hasValue("official_email") ? $CurrentForm->getValue("official_email") : $CurrentForm->getValue("x_official_email");
        if (!$this->official_email->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->official_email->Visible = false; // Disable update for API request
            } else {
                $this->official_email->setFormValue($val);
            }
        }

        // Check field name 'department' first before field var 'x_department'
        $val = $CurrentForm->hasValue("department") ? $CurrentForm->getValue("department") : $CurrentForm->getValue("x_department");
        if (!$this->department->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->department->Visible = false; // Disable update for API request
            } else {
                $this->department->setFormValue($val);
            }
        }

        // Check field name 'hire_date' first before field var 'x_hire_date'
        $val = $CurrentForm->hasValue("hire_date") ? $CurrentForm->getValue("hire_date") : $CurrentForm->getValue("x_hire_date");
        if (!$this->hire_date->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->hire_date->Visible = false; // Disable update for API request
            } else {
                $this->hire_date->setFormValue($val, true, $validate);
            }
            $this->hire_date->CurrentValue = UnFormatDateTime($this->hire_date->CurrentValue, $this->hire_date->formatPattern());
        }

        // Check field name 'current_status' first before field var 'x_current_status'
        $val = $CurrentForm->hasValue("current_status") ? $CurrentForm->getValue("current_status") : $CurrentForm->getValue("x_current_status");
        if (!$this->current_status->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->current_status->Visible = false; // Disable update for API request
            } else {
                $this->current_status->setFormValue($val);
            }
        }

        // Check field name 'tin_number' first before field var 'x_tin_number'
        $val = $CurrentForm->hasValue("tin_number") ? $CurrentForm->getValue("tin_number") : $CurrentForm->getValue("x_tin_number");
        if (!$this->tin_number->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->tin_number->Visible = false; // Disable update for API request
            } else {
                $this->tin_number->setFormValue($val);
            }
        }

        // Check field name 'nssf_number' first before field var 'x_nssf_number'
        $val = $CurrentForm->hasValue("nssf_number") ? $CurrentForm->getValue("nssf_number") : $CurrentForm->getValue("x_nssf_number");
        if (!$this->nssf_number->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->nssf_number->Visible = false; // Disable update for API request
            } else {
                $this->nssf_number->setFormValue($val);
            }
        }

        // Check field name 'salary_amount' first before field var 'x_salary_amount'
        $val = $CurrentForm->hasValue("salary_amount") ? $CurrentForm->getValue("salary_amount") : $CurrentForm->getValue("x_salary_amount");
        if (!$this->salary_amount->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->salary_amount->Visible = false; // Disable update for API request
            } else {
                $this->salary_amount->setFormValue($val, true, $validate);
            }
        }

        // Check field name 'employement_type' first before field var 'x_employement_type'
        $val = $CurrentForm->hasValue("employement_type") ? $CurrentForm->getValue("employement_type") : $CurrentForm->getValue("x_employement_type");
        if (!$this->employement_type->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->employement_type->Visible = false; // Disable update for API request
            } else {
                $this->employement_type->setFormValue($val);
            }
        }

        // Check field name 'work_schedule' first before field var 'x_work_schedule'
        $val = $CurrentForm->hasValue("work_schedule") ? $CurrentForm->getValue("work_schedule") : $CurrentForm->getValue("x_work_schedule");
        if (!$this->work_schedule->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->work_schedule->Visible = false; // Disable update for API request
            } else {
                $this->work_schedule->setFormValue($val);
            }
        }

        // Check field name 'sex' first before field var 'x_sex'
        $val = $CurrentForm->hasValue("sex") ? $CurrentForm->getValue("sex") : $CurrentForm->getValue("x_sex");
        if (!$this->sex->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->sex->Visible = false; // Disable update for API request
            } else {
                $this->sex->setFormValue($val);
            }
        }

        // Check field name 'entry_date' first before field var 'x_entry_date'
        $val = $CurrentForm->hasValue("entry_date") ? $CurrentForm->getValue("entry_date") : $CurrentForm->getValue("x_entry_date");
        if (!$this->entry_date->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->entry_date->Visible = false; // Disable update for API request
            } else {
                $this->entry_date->setFormValue($val);
            }
            $this->entry_date->CurrentValue = UnFormatDateTime($this->entry_date->CurrentValue, $this->entry_date->formatPattern());
        }

        // Check field name 'last_modified' first before field var 'x_last_modified'
        $val = $CurrentForm->hasValue("last_modified") ? $CurrentForm->getValue("last_modified") : $CurrentForm->getValue("x_last_modified");
        if (!$this->last_modified->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->last_modified->Visible = false; // Disable update for API request
            } else {
                $this->last_modified->setFormValue($val);
            }
            $this->last_modified->CurrentValue = UnFormatDateTime($this->last_modified->CurrentValue, $this->last_modified->formatPattern());
        }

        // Check field name 'entered_by' first before field var 'x_entered_by'
        $val = $CurrentForm->hasValue("entered_by") ? $CurrentForm->getValue("entered_by") : $CurrentForm->getValue("x_entered_by");
        if (!$this->entered_by->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->entered_by->Visible = false; // Disable update for API request
            } else {
                $this->entered_by->setFormValue($val);
            }
        }

        // Check field name 'modified_by' first before field var 'x_modified_by'
        $val = $CurrentForm->hasValue("modified_by") ? $CurrentForm->getValue("modified_by") : $CurrentForm->getValue("x_modified_by");
        if (!$this->modified_by->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->modified_by->Visible = false; // Disable update for API request
            } else {
                $this->modified_by->setFormValue($val);
            }
        }
    }

    // Restore form values
    public function restoreFormValues()
    {
        global $CurrentForm;
        $this->id->CurrentValue = $this->id->FormValue;
        $this->employee_number->CurrentValue = $this->employee_number->FormValue;
        $this->first_name->CurrentValue = $this->first_name->FormValue;
        $this->last_name->CurrentValue = $this->last_name->FormValue;
        $this->other_name->CurrentValue = $this->other_name->FormValue;
        $this->job_tile->CurrentValue = $this->job_tile->FormValue;
        $this->pri_phone_no->CurrentValue = $this->pri_phone_no->FormValue;
        $this->alt_phone_no->CurrentValue = $this->alt_phone_no->FormValue;
        $this->personal_email->CurrentValue = $this->personal_email->FormValue;
        $this->official_email->CurrentValue = $this->official_email->FormValue;
        $this->department->CurrentValue = $this->department->FormValue;
        $this->hire_date->CurrentValue = $this->hire_date->FormValue;
        $this->hire_date->CurrentValue = UnFormatDateTime($this->hire_date->CurrentValue, $this->hire_date->formatPattern());
        $this->current_status->CurrentValue = $this->current_status->FormValue;
        $this->tin_number->CurrentValue = $this->tin_number->FormValue;
        $this->nssf_number->CurrentValue = $this->nssf_number->FormValue;
        $this->salary_amount->CurrentValue = $this->salary_amount->FormValue;
        $this->employement_type->CurrentValue = $this->employement_type->FormValue;
        $this->work_schedule->CurrentValue = $this->work_schedule->FormValue;
        $this->sex->CurrentValue = $this->sex->FormValue;
        $this->entry_date->CurrentValue = $this->entry_date->FormValue;
        $this->entry_date->CurrentValue = UnFormatDateTime($this->entry_date->CurrentValue, $this->entry_date->formatPattern());
        $this->last_modified->CurrentValue = $this->last_modified->FormValue;
        $this->last_modified->CurrentValue = UnFormatDateTime($this->last_modified->CurrentValue, $this->last_modified->formatPattern());
        $this->entered_by->CurrentValue = $this->entered_by->FormValue;
        $this->modified_by->CurrentValue = $this->modified_by->FormValue;
    }

    /**
     * Load row based on key values
     *
     * @return void
     */
    public function loadRow()
    {
        global $Security, $Language;
        $filter = $this->getRecordFilter();

        // Call Row Selecting event
        $this->rowSelecting($filter);

        // Load SQL based on filter
        $this->CurrentFilter = $filter;
        $sql = $this->getCurrentSql();
        $conn = $this->getConnection();
        $res = false;
        $row = $conn->fetchAssociative($sql);
        if ($row) {
            $res = true;
            $this->loadRowValues($row); // Load row values
        }
        return $res;
    }

    /**
     * Load row values from recordset or record
     *
     * @param Recordset|array $rs Record
     * @return void
     */
    public function loadRowValues($rs = null)
    {
        if (is_array($rs)) {
            $row = $rs;
        } elseif ($rs && property_exists($rs, "fields")) { // Recordset
            $row = $rs->fields;
        } else {
            $row = $this->newRow();
        }
        if (!$row) {
            return;
        }

        // Call Row Selected event
        $this->rowSelected($row);
        $this->id->setDbValue($row['id']);
        $this->employee_number->setDbValue($row['employee_number']);
        $this->first_name->setDbValue($row['first_name']);
        $this->last_name->setDbValue($row['last_name']);
        $this->other_name->setDbValue($row['other_name']);
        $this->job_tile->setDbValue($row['job_tile']);
        $this->pri_phone_no->setDbValue($row['pri_phone_no']);
        $this->alt_phone_no->setDbValue($row['alt_phone_no']);
        $this->personal_email->setDbValue($row['personal_email']);
        $this->official_email->setDbValue($row['official_email']);
        $this->department->setDbValue($row['department']);
        $this->hire_date->setDbValue($row['hire_date']);
        $this->current_status->setDbValue($row['current_status']);
        $this->tin_number->setDbValue($row['tin_number']);
        $this->nssf_number->setDbValue($row['nssf_number']);
        $this->salary_amount->setDbValue($row['salary_amount']);
        $this->employement_type->setDbValue($row['employement_type']);
        $this->work_schedule->setDbValue($row['work_schedule']);
        $this->sex->setDbValue($row['sex']);
        $this->entry_date->setDbValue($row['entry_date']);
        $this->last_modified->setDbValue($row['last_modified']);
        $this->entered_by->setDbValue($row['entered_by']);
        if (array_key_exists('EV__entered_by', $row)) {
            $this->entered_by->VirtualValue = $row['EV__entered_by']; // Set up virtual field value
        } else {
            $this->entered_by->VirtualValue = ""; // Clear value
        }
        $this->modified_by->setDbValue($row['modified_by']);
        if (array_key_exists('EV__modified_by', $row)) {
            $this->modified_by->VirtualValue = $row['EV__modified_by']; // Set up virtual field value
        } else {
            $this->modified_by->VirtualValue = ""; // Clear value
        }
    }

    // Return a row with default values
    protected function newRow()
    {
        $row = [];
        $row['id'] = $this->id->DefaultValue;
        $row['employee_number'] = $this->employee_number->DefaultValue;
        $row['first_name'] = $this->first_name->DefaultValue;
        $row['last_name'] = $this->last_name->DefaultValue;
        $row['other_name'] = $this->other_name->DefaultValue;
        $row['job_tile'] = $this->job_tile->DefaultValue;
        $row['pri_phone_no'] = $this->pri_phone_no->DefaultValue;
        $row['alt_phone_no'] = $this->alt_phone_no->DefaultValue;
        $row['personal_email'] = $this->personal_email->DefaultValue;
        $row['official_email'] = $this->official_email->DefaultValue;
        $row['department'] = $this->department->DefaultValue;
        $row['hire_date'] = $this->hire_date->DefaultValue;
        $row['current_status'] = $this->current_status->DefaultValue;
        $row['tin_number'] = $this->tin_number->DefaultValue;
        $row['nssf_number'] = $this->nssf_number->DefaultValue;
        $row['salary_amount'] = $this->salary_amount->DefaultValue;
        $row['employement_type'] = $this->employement_type->DefaultValue;
        $row['work_schedule'] = $this->work_schedule->DefaultValue;
        $row['sex'] = $this->sex->DefaultValue;
        $row['entry_date'] = $this->entry_date->DefaultValue;
        $row['last_modified'] = $this->last_modified->DefaultValue;
        $row['entered_by'] = $this->entered_by->DefaultValue;
        $row['modified_by'] = $this->modified_by->DefaultValue;
        return $row;
    }

    // Load old record
    protected function loadOldRecord()
    {
        // Load old record
        if ($this->OldKey != "") {
            $this->setKey($this->OldKey);
            $this->CurrentFilter = $this->getRecordFilter();
            $sql = $this->getCurrentSql();
            $conn = $this->getConnection();
            $rs = LoadRecordset($sql, $conn);
            if ($rs && ($row = $rs->fields)) {
                $this->loadRowValues($row); // Load row values
                return $row;
            }
        }
        $this->loadRowValues(); // Load default row values
        return null;
    }

    // Render row values based on field settings
    public function renderRow()
    {
        global $Security, $Language, $CurrentLanguage;

        // Initialize URLs

        // Call Row_Rendering event
        $this->rowRendering();

        // Common render codes for all row types

        // id
        $this->id->RowCssClass = "row";

        // employee_number
        $this->employee_number->RowCssClass = "row";

        // first_name
        $this->first_name->RowCssClass = "row";

        // last_name
        $this->last_name->RowCssClass = "row";

        // other_name
        $this->other_name->RowCssClass = "row";

        // job_tile
        $this->job_tile->RowCssClass = "row";

        // pri_phone_no
        $this->pri_phone_no->RowCssClass = "row";

        // alt_phone_no
        $this->alt_phone_no->RowCssClass = "row";

        // personal_email
        $this->personal_email->RowCssClass = "row";

        // official_email
        $this->official_email->RowCssClass = "row";

        // department
        $this->department->RowCssClass = "row";

        // hire_date
        $this->hire_date->RowCssClass = "row";

        // current_status
        $this->current_status->RowCssClass = "row";

        // tin_number
        $this->tin_number->RowCssClass = "row";

        // nssf_number
        $this->nssf_number->RowCssClass = "row";

        // salary_amount
        $this->salary_amount->RowCssClass = "row";

        // employement_type
        $this->employement_type->RowCssClass = "row";

        // work_schedule
        $this->work_schedule->RowCssClass = "row";

        // sex
        $this->sex->RowCssClass = "row";

        // entry_date
        $this->entry_date->RowCssClass = "row";

        // last_modified
        $this->last_modified->RowCssClass = "row";

        // entered_by
        $this->entered_by->RowCssClass = "row";

        // modified_by
        $this->modified_by->RowCssClass = "row";

        // View row
        if ($this->RowType == ROWTYPE_VIEW) {
            // id
            $this->id->ViewValue = $this->id->CurrentValue;
            $this->id->ViewValue = FormatNumber($this->id->ViewValue, $this->id->formatPattern());

            // employee_number
            $this->employee_number->ViewValue = $this->employee_number->CurrentValue;

            // first_name
            $this->first_name->ViewValue = $this->first_name->CurrentValue;

            // last_name
            $this->last_name->ViewValue = $this->last_name->CurrentValue;

            // other_name
            $this->other_name->ViewValue = $this->other_name->CurrentValue;

            // job_tile
            $this->job_tile->ViewValue = $this->job_tile->CurrentValue;

            // pri_phone_no
            $this->pri_phone_no->ViewValue = $this->pri_phone_no->CurrentValue;

            // alt_phone_no
            $this->alt_phone_no->ViewValue = $this->alt_phone_no->CurrentValue;

            // personal_email
            $this->personal_email->ViewValue = $this->personal_email->CurrentValue;

            // official_email
            $this->official_email->ViewValue = $this->official_email->CurrentValue;

            // department
            $this->department->ViewValue = $this->department->CurrentValue;

            // hire_date
            $this->hire_date->ViewValue = $this->hire_date->CurrentValue;
            $this->hire_date->ViewValue = FormatDateTime($this->hire_date->ViewValue, $this->hire_date->formatPattern());

            // current_status
            if (strval($this->current_status->CurrentValue) != "") {
                $this->current_status->ViewValue = $this->current_status->optionCaption($this->current_status->CurrentValue);
            } else {
                $this->current_status->ViewValue = null;
            }

            // tin_number
            $this->tin_number->ViewValue = $this->tin_number->CurrentValue;

            // nssf_number
            $this->nssf_number->ViewValue = $this->nssf_number->CurrentValue;

            // salary_amount
            $this->salary_amount->ViewValue = $this->salary_amount->CurrentValue;
            $this->salary_amount->ViewValue = FormatNumber($this->salary_amount->ViewValue, $this->salary_amount->formatPattern());

            // employement_type
            if (strval($this->employement_type->CurrentValue) != "") {
                $this->employement_type->ViewValue = $this->employement_type->optionCaption($this->employement_type->CurrentValue);
            } else {
                $this->employement_type->ViewValue = null;
            }

            // work_schedule
            if (strval($this->work_schedule->CurrentValue) != "") {
                $this->work_schedule->ViewValue = $this->work_schedule->optionCaption($this->work_schedule->CurrentValue);
            } else {
                $this->work_schedule->ViewValue = null;
            }

            // sex
            if (strval($this->sex->CurrentValue) != "") {
                $this->sex->ViewValue = $this->sex->optionCaption($this->sex->CurrentValue);
            } else {
                $this->sex->ViewValue = null;
            }

            // entry_date
            $this->entry_date->ViewValue = $this->entry_date->CurrentValue;
            $this->entry_date->ViewValue = FormatDateTime($this->entry_date->ViewValue, $this->entry_date->formatPattern());

            // last_modified
            $this->last_modified->ViewValue = $this->last_modified->CurrentValue;
            $this->last_modified->ViewValue = FormatDateTime($this->last_modified->ViewValue, $this->last_modified->formatPattern());

            // entered_by
            if ($this->entered_by->VirtualValue != "") {
                $this->entered_by->ViewValue = $this->entered_by->VirtualValue;
            } else {
                $this->entered_by->ViewValue = $this->entered_by->CurrentValue;
                $curVal = strval($this->entered_by->CurrentValue);
                if ($curVal != "") {
                    $this->entered_by->ViewValue = $this->entered_by->lookupCacheOption($curVal);
                    if ($this->entered_by->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->entered_by->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->entered_by->Lookup->renderViewRow($rswrk[0]);
                            $this->entered_by->ViewValue = $this->entered_by->displayValue($arwrk);
                        } else {
                            $this->entered_by->ViewValue = FormatNumber($this->entered_by->CurrentValue, $this->entered_by->formatPattern());
                        }
                    }
                } else {
                    $this->entered_by->ViewValue = null;
                }
            }

            // modified_by
            if ($this->modified_by->VirtualValue != "") {
                $this->modified_by->ViewValue = $this->modified_by->VirtualValue;
            } else {
                $this->modified_by->ViewValue = $this->modified_by->CurrentValue;
                $curVal = strval($this->modified_by->CurrentValue);
                if ($curVal != "") {
                    $this->modified_by->ViewValue = $this->modified_by->lookupCacheOption($curVal);
                    if ($this->modified_by->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->modified_by->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->modified_by->Lookup->renderViewRow($rswrk[0]);
                            $this->modified_by->ViewValue = $this->modified_by->displayValue($arwrk);
                        } else {
                            $this->modified_by->ViewValue = FormatNumber($this->modified_by->CurrentValue, $this->modified_by->formatPattern());
                        }
                    }
                } else {
                    $this->modified_by->ViewValue = null;
                }
            }

            // id
            $this->id->HrefValue = "";

            // employee_number
            $this->employee_number->HrefValue = "";

            // first_name
            $this->first_name->HrefValue = "";

            // last_name
            $this->last_name->HrefValue = "";

            // other_name
            $this->other_name->HrefValue = "";

            // job_tile
            $this->job_tile->HrefValue = "";

            // pri_phone_no
            $this->pri_phone_no->HrefValue = "";

            // alt_phone_no
            $this->alt_phone_no->HrefValue = "";

            // personal_email
            $this->personal_email->HrefValue = "";

            // official_email
            $this->official_email->HrefValue = "";

            // department
            $this->department->HrefValue = "";

            // hire_date
            $this->hire_date->HrefValue = "";

            // current_status
            $this->current_status->HrefValue = "";

            // tin_number
            $this->tin_number->HrefValue = "";

            // nssf_number
            $this->nssf_number->HrefValue = "";

            // salary_amount
            $this->salary_amount->HrefValue = "";

            // employement_type
            $this->employement_type->HrefValue = "";

            // work_schedule
            $this->work_schedule->HrefValue = "";

            // sex
            $this->sex->HrefValue = "";

            // entry_date
            $this->entry_date->HrefValue = "";

            // last_modified
            $this->last_modified->HrefValue = "";

            // entered_by
            $this->entered_by->HrefValue = "";

            // modified_by
            $this->modified_by->HrefValue = "";
        } elseif ($this->RowType == ROWTYPE_EDIT) {
            // id
            $this->id->setupEditAttributes();
            $this->id->EditValue = $this->id->CurrentValue;
            $this->id->EditValue = FormatNumber($this->id->EditValue, $this->id->formatPattern());

            // employee_number
            $this->employee_number->setupEditAttributes();
            if (!$this->employee_number->Raw) {
                $this->employee_number->CurrentValue = HtmlDecode($this->employee_number->CurrentValue);
            }
            $this->employee_number->EditValue = HtmlEncode($this->employee_number->CurrentValue);
            $this->employee_number->PlaceHolder = RemoveHtml($this->employee_number->title());

            // first_name
            $this->first_name->setupEditAttributes();
            if (!$this->first_name->Raw) {
                $this->first_name->CurrentValue = HtmlDecode($this->first_name->CurrentValue);
            }
            $this->first_name->EditValue = HtmlEncode($this->first_name->CurrentValue);
            $this->first_name->PlaceHolder = RemoveHtml($this->first_name->title());

            // last_name
            $this->last_name->setupEditAttributes();
            if (!$this->last_name->Raw) {
                $this->last_name->CurrentValue = HtmlDecode($this->last_name->CurrentValue);
            }
            $this->last_name->EditValue = HtmlEncode($this->last_name->CurrentValue);
            $this->last_name->PlaceHolder = RemoveHtml($this->last_name->title());

            // other_name
            $this->other_name->setupEditAttributes();
            if (!$this->other_name->Raw) {
                $this->other_name->CurrentValue = HtmlDecode($this->other_name->CurrentValue);
            }
            $this->other_name->EditValue = HtmlEncode($this->other_name->CurrentValue);
            $this->other_name->PlaceHolder = RemoveHtml($this->other_name->title());

            // job_tile
            $this->job_tile->setupEditAttributes();
            if (!$this->job_tile->Raw) {
                $this->job_tile->CurrentValue = HtmlDecode($this->job_tile->CurrentValue);
            }
            $this->job_tile->EditValue = HtmlEncode($this->job_tile->CurrentValue);
            $this->job_tile->PlaceHolder = RemoveHtml($this->job_tile->title());

            // pri_phone_no
            $this->pri_phone_no->setupEditAttributes();
            if (!$this->pri_phone_no->Raw) {
                $this->pri_phone_no->CurrentValue = HtmlDecode($this->pri_phone_no->CurrentValue);
            }
            $this->pri_phone_no->EditValue = HtmlEncode($this->pri_phone_no->CurrentValue);
            $this->pri_phone_no->PlaceHolder = RemoveHtml($this->pri_phone_no->title());

            // alt_phone_no
            $this->alt_phone_no->setupEditAttributes();
            if (!$this->alt_phone_no->Raw) {
                $this->alt_phone_no->CurrentValue = HtmlDecode($this->alt_phone_no->CurrentValue);
            }
            $this->alt_phone_no->EditValue = HtmlEncode($this->alt_phone_no->CurrentValue);
            $this->alt_phone_no->PlaceHolder = RemoveHtml($this->alt_phone_no->title());

            // personal_email
            $this->personal_email->setupEditAttributes();
            if (!$this->personal_email->Raw) {
                $this->personal_email->CurrentValue = HtmlDecode($this->personal_email->CurrentValue);
            }
            $this->personal_email->EditValue = HtmlEncode($this->personal_email->CurrentValue);
            $this->personal_email->PlaceHolder = RemoveHtml($this->personal_email->title());

            // official_email
            $this->official_email->setupEditAttributes();
            if (!$this->official_email->Raw) {
                $this->official_email->CurrentValue = HtmlDecode($this->official_email->CurrentValue);
            }
            $this->official_email->EditValue = HtmlEncode($this->official_email->CurrentValue);
            $this->official_email->PlaceHolder = RemoveHtml($this->official_email->title());

            // department
            $this->department->setupEditAttributes();
            if (!$this->department->Raw) {
                $this->department->CurrentValue = HtmlDecode($this->department->CurrentValue);
            }
            $this->department->EditValue = HtmlEncode($this->department->CurrentValue);
            $this->department->PlaceHolder = RemoveHtml($this->department->title());

            // hire_date
            $this->hire_date->setupEditAttributes();
            $this->hire_date->EditValue = HtmlEncode(FormatDateTime($this->hire_date->CurrentValue, $this->hire_date->formatPattern()));
            $this->hire_date->PlaceHolder = RemoveHtml($this->hire_date->title());

            // current_status
            $this->current_status->setupEditAttributes();
            $this->current_status->EditValue = $this->current_status->options(true);
            $this->current_status->PlaceHolder = RemoveHtml($this->current_status->title());

            // tin_number
            $this->tin_number->setupEditAttributes();
            if (!$this->tin_number->Raw) {
                $this->tin_number->CurrentValue = HtmlDecode($this->tin_number->CurrentValue);
            }
            $this->tin_number->EditValue = HtmlEncode($this->tin_number->CurrentValue);
            $this->tin_number->PlaceHolder = RemoveHtml($this->tin_number->title());

            // nssf_number
            $this->nssf_number->setupEditAttributes();
            if (!$this->nssf_number->Raw) {
                $this->nssf_number->CurrentValue = HtmlDecode($this->nssf_number->CurrentValue);
            }
            $this->nssf_number->EditValue = HtmlEncode($this->nssf_number->CurrentValue);
            $this->nssf_number->PlaceHolder = RemoveHtml($this->nssf_number->title());

            // salary_amount
            $this->salary_amount->setupEditAttributes(["step" => "50"]);
            $this->salary_amount->EditValue = $this->salary_amount->CurrentValue;
            $this->salary_amount->PlaceHolder = RemoveHtml($this->salary_amount->title());
            if (strval($this->salary_amount->EditValue) != "" && is_numeric($this->salary_amount->EditValue)) {
                $this->salary_amount->EditValue = FormatNumber($this->salary_amount->EditValue, null);
            }

            // employement_type
            $this->employement_type->setupEditAttributes();
            $this->employement_type->EditValue = $this->employement_type->options(true);
            $this->employement_type->PlaceHolder = RemoveHtml($this->employement_type->title());

            // work_schedule
            $this->work_schedule->setupEditAttributes();
            $this->work_schedule->EditValue = $this->work_schedule->options(true);
            $this->work_schedule->PlaceHolder = RemoveHtml($this->work_schedule->title());

            // sex
            $this->sex->setupEditAttributes();
            $this->sex->EditValue = $this->sex->options(true);
            $this->sex->PlaceHolder = RemoveHtml($this->sex->title());

            // entry_date

            // last_modified

            // entered_by

            // modified_by

            // Edit refer script

            // id
            $this->id->HrefValue = "";

            // employee_number
            $this->employee_number->HrefValue = "";

            // first_name
            $this->first_name->HrefValue = "";

            // last_name
            $this->last_name->HrefValue = "";

            // other_name
            $this->other_name->HrefValue = "";

            // job_tile
            $this->job_tile->HrefValue = "";

            // pri_phone_no
            $this->pri_phone_no->HrefValue = "";

            // alt_phone_no
            $this->alt_phone_no->HrefValue = "";

            // personal_email
            $this->personal_email->HrefValue = "";

            // official_email
            $this->official_email->HrefValue = "";

            // department
            $this->department->HrefValue = "";

            // hire_date
            $this->hire_date->HrefValue = "";

            // current_status
            $this->current_status->HrefValue = "";

            // tin_number
            $this->tin_number->HrefValue = "";

            // nssf_number
            $this->nssf_number->HrefValue = "";

            // salary_amount
            $this->salary_amount->HrefValue = "";

            // employement_type
            $this->employement_type->HrefValue = "";

            // work_schedule
            $this->work_schedule->HrefValue = "";

            // sex
            $this->sex->HrefValue = "";

            // entry_date
            $this->entry_date->HrefValue = "";

            // last_modified
            $this->last_modified->HrefValue = "";

            // entered_by
            $this->entered_by->HrefValue = "";

            // modified_by
            $this->modified_by->HrefValue = "";
        }
        if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) { // Add/Edit/Search row
            $this->setupFieldTitles();
        }

        // Call Row Rendered event
        if ($this->RowType != ROWTYPE_AGGREGATEINIT) {
            $this->rowRendered();
        }
    }

    // Validate form
    protected function validateForm()
    {
        global $Language, $Security;

        // Check if validation required
        if (!Config("SERVER_VALIDATE")) {
            return true;
        }
        $validateForm = true;
        if ($this->id->Visible && $this->id->Required) {
            if (!$this->id->IsDetailKey && EmptyValue($this->id->FormValue)) {
                $this->id->addErrorMessage(str_replace("%s", $this->id->caption(), $this->id->RequiredErrorMessage));
            }
        }
        if ($this->employee_number->Visible && $this->employee_number->Required) {
            if (!$this->employee_number->IsDetailKey && EmptyValue($this->employee_number->FormValue)) {
                $this->employee_number->addErrorMessage(str_replace("%s", $this->employee_number->caption(), $this->employee_number->RequiredErrorMessage));
            }
        }
        if ($this->first_name->Visible && $this->first_name->Required) {
            if (!$this->first_name->IsDetailKey && EmptyValue($this->first_name->FormValue)) {
                $this->first_name->addErrorMessage(str_replace("%s", $this->first_name->caption(), $this->first_name->RequiredErrorMessage));
            }
        }
        if ($this->last_name->Visible && $this->last_name->Required) {
            if (!$this->last_name->IsDetailKey && EmptyValue($this->last_name->FormValue)) {
                $this->last_name->addErrorMessage(str_replace("%s", $this->last_name->caption(), $this->last_name->RequiredErrorMessage));
            }
        }
        if ($this->other_name->Visible && $this->other_name->Required) {
            if (!$this->other_name->IsDetailKey && EmptyValue($this->other_name->FormValue)) {
                $this->other_name->addErrorMessage(str_replace("%s", $this->other_name->caption(), $this->other_name->RequiredErrorMessage));
            }
        }
        if ($this->job_tile->Visible && $this->job_tile->Required) {
            if (!$this->job_tile->IsDetailKey && EmptyValue($this->job_tile->FormValue)) {
                $this->job_tile->addErrorMessage(str_replace("%s", $this->job_tile->caption(), $this->job_tile->RequiredErrorMessage));
            }
        }
        if ($this->pri_phone_no->Visible && $this->pri_phone_no->Required) {
            if (!$this->pri_phone_no->IsDetailKey && EmptyValue($this->pri_phone_no->FormValue)) {
                $this->pri_phone_no->addErrorMessage(str_replace("%s", $this->pri_phone_no->caption(), $this->pri_phone_no->RequiredErrorMessage));
            }
        }
        if ($this->alt_phone_no->Visible && $this->alt_phone_no->Required) {
            if (!$this->alt_phone_no->IsDetailKey && EmptyValue($this->alt_phone_no->FormValue)) {
                $this->alt_phone_no->addErrorMessage(str_replace("%s", $this->alt_phone_no->caption(), $this->alt_phone_no->RequiredErrorMessage));
            }
        }
        if ($this->personal_email->Visible && $this->personal_email->Required) {
            if (!$this->personal_email->IsDetailKey && EmptyValue($this->personal_email->FormValue)) {
                $this->personal_email->addErrorMessage(str_replace("%s", $this->personal_email->caption(), $this->personal_email->RequiredErrorMessage));
            }
        }
        if ($this->official_email->Visible && $this->official_email->Required) {
            if (!$this->official_email->IsDetailKey && EmptyValue($this->official_email->FormValue)) {
                $this->official_email->addErrorMessage(str_replace("%s", $this->official_email->caption(), $this->official_email->RequiredErrorMessage));
            }
        }
        if ($this->department->Visible && $this->department->Required) {
            if (!$this->department->IsDetailKey && EmptyValue($this->department->FormValue)) {
                $this->department->addErrorMessage(str_replace("%s", $this->department->caption(), $this->department->RequiredErrorMessage));
            }
        }
        if ($this->hire_date->Visible && $this->hire_date->Required) {
            if (!$this->hire_date->IsDetailKey && EmptyValue($this->hire_date->FormValue)) {
                $this->hire_date->addErrorMessage(str_replace("%s", $this->hire_date->caption(), $this->hire_date->RequiredErrorMessage));
            }
        }
        if (!CheckDate($this->hire_date->FormValue, $this->hire_date->formatPattern())) {
            $this->hire_date->addErrorMessage($this->hire_date->getErrorMessage(false));
        }
        if ($this->current_status->Visible && $this->current_status->Required) {
            if (!$this->current_status->IsDetailKey && EmptyValue($this->current_status->FormValue)) {
                $this->current_status->addErrorMessage(str_replace("%s", $this->current_status->caption(), $this->current_status->RequiredErrorMessage));
            }
        }
        if ($this->tin_number->Visible && $this->tin_number->Required) {
            if (!$this->tin_number->IsDetailKey && EmptyValue($this->tin_number->FormValue)) {
                $this->tin_number->addErrorMessage(str_replace("%s", $this->tin_number->caption(), $this->tin_number->RequiredErrorMessage));
            }
        }
        if ($this->nssf_number->Visible && $this->nssf_number->Required) {
            if (!$this->nssf_number->IsDetailKey && EmptyValue($this->nssf_number->FormValue)) {
                $this->nssf_number->addErrorMessage(str_replace("%s", $this->nssf_number->caption(), $this->nssf_number->RequiredErrorMessage));
            }
        }
        if ($this->salary_amount->Visible && $this->salary_amount->Required) {
            if (!$this->salary_amount->IsDetailKey && EmptyValue($this->salary_amount->FormValue)) {
                $this->salary_amount->addErrorMessage(str_replace("%s", $this->salary_amount->caption(), $this->salary_amount->RequiredErrorMessage));
            }
        }
        if (!CheckNumber($this->salary_amount->FormValue)) {
            $this->salary_amount->addErrorMessage($this->salary_amount->getErrorMessage(false));
        }
        if ($this->employement_type->Visible && $this->employement_type->Required) {
            if (!$this->employement_type->IsDetailKey && EmptyValue($this->employement_type->FormValue)) {
                $this->employement_type->addErrorMessage(str_replace("%s", $this->employement_type->caption(), $this->employement_type->RequiredErrorMessage));
            }
        }
        if ($this->work_schedule->Visible && $this->work_schedule->Required) {
            if (!$this->work_schedule->IsDetailKey && EmptyValue($this->work_schedule->FormValue)) {
                $this->work_schedule->addErrorMessage(str_replace("%s", $this->work_schedule->caption(), $this->work_schedule->RequiredErrorMessage));
            }
        }
        if ($this->sex->Visible && $this->sex->Required) {
            if (!$this->sex->IsDetailKey && EmptyValue($this->sex->FormValue)) {
                $this->sex->addErrorMessage(str_replace("%s", $this->sex->caption(), $this->sex->RequiredErrorMessage));
            }
        }
        if ($this->entry_date->Visible && $this->entry_date->Required) {
            if (!$this->entry_date->IsDetailKey && EmptyValue($this->entry_date->FormValue)) {
                $this->entry_date->addErrorMessage(str_replace("%s", $this->entry_date->caption(), $this->entry_date->RequiredErrorMessage));
            }
        }
        if ($this->last_modified->Visible && $this->last_modified->Required) {
            if (!$this->last_modified->IsDetailKey && EmptyValue($this->last_modified->FormValue)) {
                $this->last_modified->addErrorMessage(str_replace("%s", $this->last_modified->caption(), $this->last_modified->RequiredErrorMessage));
            }
        }
        if ($this->entered_by->Visible && $this->entered_by->Required) {
            if (!$this->entered_by->IsDetailKey && EmptyValue($this->entered_by->FormValue)) {
                $this->entered_by->addErrorMessage(str_replace("%s", $this->entered_by->caption(), $this->entered_by->RequiredErrorMessage));
            }
        }
        if ($this->modified_by->Visible && $this->modified_by->Required) {
            if (!$this->modified_by->IsDetailKey && EmptyValue($this->modified_by->FormValue)) {
                $this->modified_by->addErrorMessage(str_replace("%s", $this->modified_by->caption(), $this->modified_by->RequiredErrorMessage));
            }
        }

        // Return validate result
        $validateForm = $validateForm && !$this->hasInvalidFields();

        // Call Form_CustomValidate event
        $formCustomError = "";
        $validateForm = $validateForm && $this->formCustomValidate($formCustomError);
        if ($formCustomError != "") {
            $this->setFailureMessage($formCustomError);
        }
        return $validateForm;
    }

    // Update record based on key values
    protected function editRow()
    {
        global $Security, $Language;
        $oldKeyFilter = $this->getRecordFilter();
        $filter = $this->applyUserIDFilters($oldKeyFilter);
        $conn = $this->getConnection();

        // Load old row
        $this->CurrentFilter = $filter;
        $sql = $this->getCurrentSql();
        $rsold = $conn->fetchAssociative($sql);
        if (!$rsold) {
            $this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
            return false; // Update Failed
        } else {
            // Save old values
            $this->loadDbValues($rsold);
        }

        // Set new row
        $rsnew = [];

        // employee_number
        $this->employee_number->setDbValueDef($rsnew, $this->employee_number->CurrentValue, $this->employee_number->ReadOnly);

        // first_name
        $this->first_name->setDbValueDef($rsnew, $this->first_name->CurrentValue, $this->first_name->ReadOnly);

        // last_name
        $this->last_name->setDbValueDef($rsnew, $this->last_name->CurrentValue, $this->last_name->ReadOnly);

        // other_name
        $this->other_name->setDbValueDef($rsnew, $this->other_name->CurrentValue, $this->other_name->ReadOnly);

        // job_tile
        $this->job_tile->setDbValueDef($rsnew, $this->job_tile->CurrentValue, $this->job_tile->ReadOnly);

        // pri_phone_no
        $this->pri_phone_no->setDbValueDef($rsnew, $this->pri_phone_no->CurrentValue, $this->pri_phone_no->ReadOnly);

        // alt_phone_no
        $this->alt_phone_no->setDbValueDef($rsnew, $this->alt_phone_no->CurrentValue, $this->alt_phone_no->ReadOnly);

        // personal_email
        $this->personal_email->setDbValueDef($rsnew, $this->personal_email->CurrentValue, $this->personal_email->ReadOnly);

        // official_email
        $this->official_email->setDbValueDef($rsnew, $this->official_email->CurrentValue, $this->official_email->ReadOnly);

        // department
        $this->department->setDbValueDef($rsnew, $this->department->CurrentValue, $this->department->ReadOnly);

        // hire_date
        $this->hire_date->setDbValueDef($rsnew, UnFormatDateTime($this->hire_date->CurrentValue, $this->hire_date->formatPattern()), $this->hire_date->ReadOnly);

        // current_status
        $this->current_status->setDbValueDef($rsnew, $this->current_status->CurrentValue, $this->current_status->ReadOnly);

        // tin_number
        $this->tin_number->setDbValueDef($rsnew, $this->tin_number->CurrentValue, $this->tin_number->ReadOnly);

        // nssf_number
        $this->nssf_number->setDbValueDef($rsnew, $this->nssf_number->CurrentValue, $this->nssf_number->ReadOnly);

        // salary_amount
        $this->salary_amount->setDbValueDef($rsnew, $this->salary_amount->CurrentValue, $this->salary_amount->ReadOnly);

        // employement_type
        $this->employement_type->setDbValueDef($rsnew, $this->employement_type->CurrentValue, $this->employement_type->ReadOnly);

        // work_schedule
        $this->work_schedule->setDbValueDef($rsnew, $this->work_schedule->CurrentValue, $this->work_schedule->ReadOnly);

        // sex
        $this->sex->setDbValueDef($rsnew, $this->sex->CurrentValue, $this->sex->ReadOnly);

        // entry_date
        $this->entry_date->CurrentValue = $this->entry_date->getAutoUpdateValue(); // PHP
        $this->entry_date->setDbValueDef($rsnew, $this->entry_date->CurrentValue);

        // last_modified
        $this->last_modified->CurrentValue = $this->last_modified->getAutoUpdateValue(); // PHP
        $this->last_modified->setDbValueDef($rsnew, $this->last_modified->CurrentValue);

        // entered_by
        $this->entered_by->CurrentValue = $this->entered_by->getAutoUpdateValue(); // PHP
        $this->entered_by->setDbValueDef($rsnew, $this->entered_by->CurrentValue);

        // modified_by
        $this->modified_by->CurrentValue = $this->modified_by->getAutoUpdateValue(); // PHP
        $this->modified_by->setDbValueDef($rsnew, $this->modified_by->CurrentValue);

        // Update current values
        $this->setCurrentValues($rsnew);

        // Check field with unique index (employee_number)
        if ($this->employee_number->CurrentValue != "") {
            $filterChk = "(`employee_number` = '" . AdjustSql($this->employee_number->CurrentValue, $this->Dbid) . "')";
            $filterChk .= " AND NOT (" . $filter . ")";
            $this->CurrentFilter = $filterChk;
            $sqlChk = $this->getCurrentSql();
            $rsChk = $conn->executeQuery($sqlChk);
            if (!$rsChk) {
                return false;
            }
            if ($rsChk->fetch()) {
                $idxErrMsg = str_replace("%f", $this->employee_number->caption(), $Language->phrase("DupIndex"));
                $idxErrMsg = str_replace("%v", $this->employee_number->CurrentValue, $idxErrMsg);
                $this->setFailureMessage($idxErrMsg);
                return false;
            }
        }

        // Call Row Updating event
        $updateRow = $this->rowUpdating($rsold, $rsnew);
        if ($updateRow) {
            if (count($rsnew) > 0) {
                $this->CurrentFilter = $filter; // Set up current filter
                $editRow = $this->update($rsnew, "", $rsold);
                if (!$editRow && !EmptyValue($this->DbErrorMessage)) { // Show database error
                    $this->setFailureMessage($this->DbErrorMessage);
                }
            } else {
                $editRow = true; // No field to update
            }
            if ($editRow) {
            }
        } else {
            if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {
                // Use the message, do nothing
            } elseif ($this->CancelMessage != "") {
                $this->setFailureMessage($this->CancelMessage);
                $this->CancelMessage = "";
            } else {
                $this->setFailureMessage($Language->phrase("UpdateCancelled"));
            }
            $editRow = false;
        }

        // Call Row_Updated event
        if ($editRow) {
            $this->rowUpdated($rsold, $rsnew);
        }

        // Write JSON response
        if (IsJsonResponse() && $editRow) {
            $row = $this->getRecordsFromRecordset([$rsnew], true);
            $table = $this->TableVar;
            WriteJson(["success" => true, "action" => Config("API_EDIT_ACTION"), $table => $row]);
        }
        return $editRow;
    }

    // Set up Breadcrumb
    protected function setupBreadcrumb()
    {
        global $Breadcrumb, $Language;
        $Breadcrumb = new Breadcrumb("index");
        $url = CurrentUrl();
        $Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("tbemployeelist"), "", $this->TableVar, true);
        $pageId = "edit";
        $Breadcrumb->add("edit", $pageId, $url);
    }

    // Setup lookup options
    public function setupLookupOptions($fld)
    {
        if ($fld->Lookup !== null && $fld->Lookup->Options === null) {
            // Get default connection and filter
            $conn = $this->getConnection();
            $lookupFilter = "";

            // No need to check any more
            $fld->Lookup->Options = [];

            // Set up lookup SQL and connection
            switch ($fld->FieldVar) {
                case "x_current_status":
                    break;
                case "x_employement_type":
                    break;
                case "x_work_schedule":
                    break;
                case "x_sex":
                    break;
                case "x_entered_by":
                    break;
                case "x_modified_by":
                    break;
                default:
                    $lookupFilter = "";
                    break;
            }

            // Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
            $sql = $fld->Lookup->getSql(false, "", $lookupFilter, $this);

            // Set up lookup cache
            if (!$fld->hasLookupOptions() && $fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0 && count($fld->Lookup->FilterFields) == 0) {
                $totalCnt = $this->getRecordCount($sql, $conn);
                if ($totalCnt > $fld->LookupCacheCount) { // Total count > cache count, do not cache
                    return;
                }
                $rows = $conn->executeQuery($sql)->fetchAll();
                $ar = [];
                foreach ($rows as $row) {
                    $row = $fld->Lookup->renderViewRow($row, Container($fld->Lookup->LinkTable));
                    $key = $row["lf"];
                    if (IsFloatType($fld->Type)) { // Handle float field
                        $key = (float)$key;
                    }
                    $ar[strval($key)] = $row;
                }
                $fld->Lookup->Options = $ar;
            }
        }
    }

    // Set up starting record parameters
    public function setupStartRecord()
    {
        if ($this->DisplayRecords == 0) {
            return;
        }
        $pageNo = Get(Config("TABLE_PAGE_NUMBER"));
        $startRec = Get(Config("TABLE_START_REC"));
        $infiniteScroll = false;
        $recordNo = $pageNo ?? $startRec; // Record number = page number or start record
        if ($recordNo !== null && is_numeric($recordNo)) {
            $this->StartRecord = $recordNo;
        } else {
            $this->StartRecord = $this->getStartRecordNumber();
        }

        // Check if correct start record counter
        if (!is_numeric($this->StartRecord) || intval($this->StartRecord) <= 0) { // Avoid invalid start record counter
            $this->StartRecord = 1; // Reset start record counter
        } elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
            $this->StartRecord = (int)(($this->TotalRecords - 1) / $this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
        } elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
            $this->StartRecord = (int)(($this->StartRecord - 1) / $this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
        }
        if (!$infiniteScroll) {
            $this->setStartRecordNumber($this->StartRecord);
        }
    }

    // Get page count
    public function pageCount() {
        return ceil($this->TotalRecords / $this->DisplayRecords);
    }

    // Page Load event
    public function pageLoad()
    {
        //Log("Page Load");
    	$GLOBALS["Language"]->setPhrase("edit", "Change Details"); 
    	$GLOBALS["Language"]->setPhrase("savebtn", "<i class='fa fa-check fa-1x'></i> Save and Apply");  
    	$GLOBALS["Language"]->setPhrase("cancelbtn", "<i class='fa fa-close fa-1x'></i> Cancel Transaction");
    	$GLOBALS["Language"]->setPhrase("updatesuccess", "Transaction Completed Successfully.");    
    }

    // Page Unload event
    public function pageUnload()
    {
        //Log("Page Unload");
    }

    // Page Redirecting event
    public function pageRedirecting(&$url)
    {
        // Example:
        //$url = "your URL";
    }

    // Message Showing event
    // $type = ''|'success'|'failure'|'warning'
    public function messageShowing(&$msg, $type)
    {
        if ($type == 'success') {
            //$msg = "your success message";
        } elseif ($type == 'failure') {
            //$msg = "your failure message";
        } elseif ($type == 'warning') {
            //$msg = "your warning message";
        } else {
            //$msg = "your message";
        }
    }

    // Page Render event
    public function pageRender()
    {
        //Log("Page Render");
    }

    // Page Data Rendering event
    public function pageDataRendering(&$header)
    {
        // Example:
        //$header = "your header";

        //Warning about mandatory fields
        $header .= '<div class="callout callout-warning rounded-0 py-1" style="font-size: 13px; color: #c23321 !important; border-color: #c23321;background-color: #fff3cd !important;">';
        $header .= 'All Form Fields Marked With an Asterisk (*) are Mandatory.';
    	$header .= '</div>';  
    }

    // Page Data Rendered event
    public function pageDataRendered(&$footer)
    {
        // Example:
        //$footer = "your footer";
    }

    // Page Breaking event
    public function pageBreaking(&$break, &$content)
    {
        // Example:
        //$break = false; // Skip page break, or
        //$content = "<div style=\"break-after:page;\"></div>"; // Modify page break content
    }

    // Form Custom Validate event
    public function formCustomValidate(&$customError)
    {
        // Return error message in $customError
        return true;
    }
}
