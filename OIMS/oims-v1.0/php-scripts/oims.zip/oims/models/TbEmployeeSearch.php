<?php

namespace PHPMaker2023\OIMS;

use Doctrine\DBAL\ParameterType;
use Doctrine\DBAL\FetchMode;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;

/**
 * Page class
 */
class TbEmployeeSearch extends TbEmployee
{
    use MessagesTrait;

    // Page ID
    public $PageID = "search";

    // Project ID
    public $ProjectID = PROJECT_ID;

    // Page object name
    public $PageObjName = "TbEmployeeSearch";

    // View file path
    public $View = null;

    // Title
    public $Title = null; // Title for <title> tag

    // Rendering View
    public $RenderingView = false;

    // CSS class/style
    public $CurrentPageName = "tbemployeesearch";

    // Page headings
    public $Heading = "";
    public $Subheading = "";
    public $PageHeader;
    public $PageFooter;

    // Page layout
    public $UseLayout = true;

    // Page terminated
    private $terminated = false;

    // Page heading
    public function pageHeading()
    {
        global $Language;
        if ($this->Heading != "") {
            return $this->Heading;
        }
        if (method_exists($this, "tableCaption")) {
            return $this->tableCaption();
        }
        return "";
    }

    // Page subheading
    public function pageSubheading()
    {
        global $Language;
        if ($this->Subheading != "") {
            return $this->Subheading;
        }
        if ($this->TableName) {
            return $Language->phrase($this->PageID);
        }
        return "";
    }

    // Page name
    public function pageName()
    {
        return CurrentPageName();
    }

    // Page URL
    public function pageUrl($withArgs = true)
    {
        $route = GetRoute();
        $args = RemoveXss($route->getArguments());
        if (!$withArgs) {
            foreach ($args as $key => &$val) {
                $val = "";
            }
            unset($val);
        }
        return rtrim(UrlFor($route->getName(), $args), "/") . "?";
    }

    // Show Page Header
    public function showPageHeader()
    {
        $header = $this->PageHeader;
        $this->pageDataRendering($header);
        if ($header != "") { // Header exists, display
            echo '<p id="ew-page-header">' . $header . '</p>';
        }
    }

    // Show Page Footer
    public function showPageFooter()
    {
        $footer = $this->PageFooter;
        $this->pageDataRendered($footer);
        if ($footer != "") { // Footer exists, display
            echo '<p id="ew-page-footer">' . $footer . '</p>';
        }
    }

    // Set field visibility
    public function setVisibility()
    {
        $this->id->setVisibility();
        $this->employee_number->setVisibility();
        $this->first_name->setVisibility();
        $this->last_name->setVisibility();
        $this->other_name->setVisibility();
        $this->job_tile->setVisibility();
        $this->pri_phone_no->setVisibility();
        $this->alt_phone_no->setVisibility();
        $this->personal_email->setVisibility();
        $this->official_email->setVisibility();
        $this->department->setVisibility();
        $this->hire_date->setVisibility();
        $this->current_status->setVisibility();
        $this->tin_number->setVisibility();
        $this->nssf_number->setVisibility();
        $this->salary_amount->setVisibility();
        $this->employement_type->setVisibility();
        $this->work_schedule->setVisibility();
        $this->sex->setVisibility();
        $this->entry_date->Visible = false;
        $this->last_modified->Visible = false;
        $this->entered_by->Visible = false;
        $this->modified_by->Visible = false;
    }

    // Constructor
    public function __construct()
    {
        parent::__construct();
        global $Language, $DashboardReport, $DebugTimer, $UserTable;
        $this->TableVar = 'tb_employee';
        $this->TableName = 'tb_employee';

        // Table CSS class
        $this->TableClass = "table table-striped table-bordered table-hover table-sm ew-desktop-table ew-search-table";

        // Initialize
        $GLOBALS["Page"] = &$this;

        // Language object
        $Language = Container("language");

        // Table object (tb_employee)
        if (!isset($GLOBALS["tb_employee"]) || get_class($GLOBALS["tb_employee"]) == PROJECT_NAMESPACE . "tb_employee") {
            $GLOBALS["tb_employee"] = &$this;
        }

        // Table name (for backward compatibility only)
        if (!defined(PROJECT_NAMESPACE . "TABLE_NAME")) {
            define(PROJECT_NAMESPACE . "TABLE_NAME", 'tb_employee');
        }

        // Start timer
        $DebugTimer = Container("timer");

        // Debug message
        LoadDebugMessage();

        // Open connection
        $GLOBALS["Conn"] ??= $this->getConnection();

        // User table object
        $UserTable = Container("usertable");
    }

    // Get content from stream
    public function getContents(): string
    {
        global $Response;
        return is_object($Response) ? $Response->getBody() : ob_get_clean();
    }

    // Is lookup
    public function isLookup()
    {
        return SameText(Route(0), Config("API_LOOKUP_ACTION"));
    }

    // Is AutoFill
    public function isAutoFill()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autofill");
    }

    // Is AutoSuggest
    public function isAutoSuggest()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autosuggest");
    }

    // Is modal lookup
    public function isModalLookup()
    {
        return $this->isLookup() && SameText(Post("ajax"), "modal");
    }

    // Is terminated
    public function isTerminated()
    {
        return $this->terminated;
    }

    /**
     * Terminate page
     *
     * @param string $url URL for direction
     * @return void
     */
    public function terminate($url = "")
    {
        if ($this->terminated) {
            return;
        }
        global $TempImages, $DashboardReport, $Response;

        // Page is terminated
        $this->terminated = true;

        // Page Unload event
        if (method_exists($this, "pageUnload")) {
            $this->pageUnload();
        }

        // Global Page Unloaded event (in userfn*.php)
        Page_Unloaded();
        if (!IsApi() && method_exists($this, "pageRedirecting")) {
            $this->pageRedirecting($url);
        }

        // Close connection
        CloseConnections();

        // Return for API
        if (IsApi()) {
            $res = $url === true;
            if (!$res) { // Show response for API
                $ar = array_merge($this->getMessages(), $url ? ["url" => GetUrl($url)] : []);
                WriteJson($ar);
            }
            $this->clearMessages(); // Clear messages for API request
            return;
        } else { // Check if response is JSON
            if (StartsString("application/json", $Response->getHeaderLine("Content-type")) && $Response->getBody()->getSize()) { // With JSON response
                $this->clearMessages();
                return;
            }
        }

        // Go to URL if specified
        if ($url != "") {
            if (!Config("DEBUG") && ob_get_length()) {
                ob_end_clean();
            }

            // Handle modal response (Assume return to modal for simplicity)
            if ($this->IsModal) { // Show as modal
                $result = ["url" => GetUrl($url), "modal" => "1"];
                $pageName = GetPageName($url);
                if ($pageName != $this->getListUrl()) { // Not List page => View page
                    $result["caption"] = $this->getModalCaption($pageName);
                    $result["view"] = $pageName == "tbemployeeview"; // If View page, no primary button
                } else { // List page
                    // $result["list"] = $this->PageID == "search"; // Refresh List page if current page is Search page
                    $result["error"] = $this->getFailureMessage(); // List page should not be shown as modal => error
                    $this->clearFailureMessage();
                }
                WriteJson($result);
            } else {
                SaveDebugMessage();
                Redirect(GetUrl($url));
            }
        }
        return; // Return to controller
    }

    // Get records from recordset
    protected function getRecordsFromRecordset($rs, $current = false)
    {
        $rows = [];
        if (is_object($rs)) { // Recordset
            while ($rs && !$rs->EOF) {
                $this->loadRowValues($rs); // Set up DbValue/CurrentValue
                $row = $this->getRecordFromArray($rs->fields);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
                $rs->moveNext();
            }
        } elseif (is_array($rs)) {
            foreach ($rs as $ar) {
                $row = $this->getRecordFromArray($ar);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
            }
        }
        return $rows;
    }

    // Get record from array
    protected function getRecordFromArray($ar)
    {
        $row = [];
        if (is_array($ar)) {
            foreach ($ar as $fldname => $val) {
                if (array_key_exists($fldname, $this->Fields) && ($this->Fields[$fldname]->Visible || $this->Fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
                    $fld = &$this->Fields[$fldname];
                    if ($fld->HtmlTag == "FILE") { // Upload field
                        if (EmptyValue($val)) {
                            $row[$fldname] = null;
                        } else {
                            if ($fld->DataType == DATATYPE_BLOB) {
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . $fld->Param . "/" . rawurlencode($this->getRecordKeyValue($ar))));
                                $row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
                            } elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $val)));
                                $row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
                            } else { // Multiple files
                                $files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
                                $ar = [];
                                foreach ($files as $file) {
                                    $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                        "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $file)));
                                    if (!EmptyValue($file)) {
                                        $ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
                                    }
                                }
                                $row[$fldname] = $ar;
                            }
                        }
                    } else {
                        $row[$fldname] = $val;
                    }
                }
            }
        }
        return $row;
    }

    // Get record key value from array
    protected function getRecordKeyValue($ar)
    {
        $key = "";
        if (is_array($ar)) {
            $key .= @$ar['id'];
        }
        return $key;
    }

    /**
     * Hide fields for add/edit
     *
     * @return void
     */
    protected function hideFieldsForAddEdit()
    {
        if ($this->isAdd() || $this->isCopy() || $this->isGridAdd()) {
            $this->id->Visible = false;
        }
    }

    // Lookup data
    public function lookup($ar = null)
    {
        global $Language, $Security;

        // Get lookup object
        $fieldName = $ar["field"] ?? Post("field");
        $lookup = $this->Fields[$fieldName]->Lookup;
        $name = $ar["name"] ?? Post("name");
        $isQuery = ContainsString($name, "query_builder_rule");
        if ($isQuery) {
            $lookup->FilterFields = []; // Skip parent fields if any
        }

        // Get lookup parameters
        $lookupType = $ar["ajax"] ?? Post("ajax", "unknown");
        $pageSize = -1;
        $offset = -1;
        $searchValue = "";
        if (SameText($lookupType, "modal") || SameText($lookupType, "filter")) {
            $searchValue = $ar["q"] ?? Param("q") ?? $ar["sv"] ?? Post("sv", "");
            $pageSize = $ar["n"] ?? Param("n") ?? $ar["recperpage"] ?? Post("recperpage", 10);
        } elseif (SameText($lookupType, "autosuggest")) {
            $searchValue = $ar["q"] ?? Param("q", "");
            $pageSize = $ar["n"] ?? Param("n", -1);
            $pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
            if ($pageSize <= 0) {
                $pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
            }
        }
        $start = $ar["start"] ?? Param("start", -1);
        $start = is_numeric($start) ? (int)$start : -1;
        $page = $ar["page"] ?? Param("page", -1);
        $page = is_numeric($page) ? (int)$page : -1;
        $offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
        $userSelect = Decrypt($ar["s"] ?? Post("s", ""));
        $userFilter = Decrypt($ar["f"] ?? Post("f", ""));
        $userOrderBy = Decrypt($ar["o"] ?? Post("o", ""));
        $keys = $ar["keys"] ?? Post("keys");
        $lookup->LookupType = $lookupType; // Lookup type
        $lookup->FilterValues = []; // Clear filter values first
        if ($keys !== null) { // Selected records from modal
            if (is_array($keys)) {
                $keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
            }
            $lookup->FilterFields = []; // Skip parent fields if any
            $lookup->FilterValues[] = $keys; // Lookup values
            $pageSize = -1; // Show all records
        } else { // Lookup values
            $lookup->FilterValues[] = $ar["v0"] ?? $ar["lookupValue"] ?? Post("v0", Post("lookupValue", ""));
        }
        $cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
        for ($i = 1; $i <= $cnt; $i++) {
            $lookup->FilterValues[] = $ar["v" . $i] ?? Post("v" . $i, "");
        }
        $lookup->SearchValue = $searchValue;
        $lookup->PageSize = $pageSize;
        $lookup->Offset = $offset;
        if ($userSelect != "") {
            $lookup->UserSelect = $userSelect;
        }
        if ($userFilter != "") {
            $lookup->UserFilter = $userFilter;
        }
        if ($userOrderBy != "") {
            $lookup->UserOrderBy = $userOrderBy;
        }
        return $lookup->toJson($this, !is_array($ar)); // Use settings from current page
    }
    public $FormClassName = "ew-form ew-search-form";
    public $IsModal = false;
    public $IsMobileOrModal = false;

    /**
     * Page run
     *
     * @return void
     */
    public function run()
    {
        global $ExportType, $UserProfile, $Language, $Security, $CurrentForm, $SkipHeaderFooter;

        // Is modal
        $this->IsModal = ConvertToBool(Param("modal"));
        $this->UseLayout = $this->UseLayout && !$this->IsModal;

        // Use layout
        $this->UseLayout = $this->UseLayout && ConvertToBool(Param(Config("PAGE_LAYOUT"), true));

        // View
        $this->View = Get(Config("VIEW"));

        // Create form object
        $CurrentForm = new HttpForm();
        $this->CurrentAction = Param("action"); // Set up current action
        $this->setVisibility();

        // Set lookup cache
        if (!in_array($this->PageID, Config("LOOKUP_CACHE_PAGE_IDS"))) {
            $this->setUseLookupCache(false);
        }

        // Global Page Loading event (in userfn*.php)
        Page_Loading();

        // Page Load event
        if (method_exists($this, "pageLoad")) {
            $this->pageLoad();
        }

        // Hide fields for add/edit
        if (!$this->UseAjaxActions) {
            $this->hideFieldsForAddEdit();
        }
        // Use inline delete
        if ($this->UseAjaxActions) {
            $this->InlineDelete = true;
        }

        // Set up lookup cache
        $this->setupLookupOptions($this->current_status);
        $this->setupLookupOptions($this->employement_type);
        $this->setupLookupOptions($this->work_schedule);
        $this->setupLookupOptions($this->sex);
        $this->setupLookupOptions($this->entered_by);
        $this->setupLookupOptions($this->modified_by);

        // Set up Breadcrumb
        $this->setupBreadcrumb();

        // Check modal
        if ($this->IsModal) {
            $SkipHeaderFooter = true;
        }
        $this->IsMobileOrModal = IsMobile() || $this->IsModal;

        // Get action
        $this->CurrentAction = Post("action");
        if ($this->isSearch()) {
            // Build search string for advanced search, remove blank field
            $this->loadSearchValues(); // Get search values
            $srchStr = $this->validateSearch() ? $this->buildAdvancedSearch() : "";
            if ($srchStr != "") {
                $srchStr = "tbemployeelist" . "?" . $srchStr;
                // Do not return Json for UseAjaxActions
                if ($this->IsModal && $this->UseAjaxActions) {
                    $this->IsModal = false;
                }
                $this->terminate($srchStr); // Go to list page
                return;
            }
        }

        // Restore search settings from Session
        if (!$this->hasInvalidFields()) {
            $this->loadAdvancedSearch();
        }

        // Render row for search
        $this->RowType = ROWTYPE_SEARCH;
        $this->resetAttributes();
        $this->renderRow();

        // Set LoginStatus / Page_Rendering / Page_Render
        if (!IsApi() && !$this->isTerminated()) {
            // Setup login status
            SetupLoginStatus();

            // Pass login status to client side
            SetClientVar("login", LoginStatus());

            // Global Page Rendering event (in userfn*.php)
            Page_Rendering();

            // Page Render event
            if (method_exists($this, "pageRender")) {
                $this->pageRender();
            }

            // Render search option
            if (method_exists($this, "renderSearchOptions")) {
                $this->renderSearchOptions();
            }
        }
    }

    // Build advanced search
    protected function buildAdvancedSearch()
    {
        $srchUrl = "";
        $this->buildSearchUrl($srchUrl, $this->id); // id
        $this->buildSearchUrl($srchUrl, $this->employee_number); // employee_number
        $this->buildSearchUrl($srchUrl, $this->first_name); // first_name
        $this->buildSearchUrl($srchUrl, $this->last_name); // last_name
        $this->buildSearchUrl($srchUrl, $this->other_name); // other_name
        $this->buildSearchUrl($srchUrl, $this->job_tile); // job_tile
        $this->buildSearchUrl($srchUrl, $this->pri_phone_no); // pri_phone_no
        $this->buildSearchUrl($srchUrl, $this->alt_phone_no); // alt_phone_no
        $this->buildSearchUrl($srchUrl, $this->personal_email); // personal_email
        $this->buildSearchUrl($srchUrl, $this->official_email); // official_email
        $this->buildSearchUrl($srchUrl, $this->department); // department
        $this->buildSearchUrl($srchUrl, $this->hire_date); // hire_date
        $this->buildSearchUrl($srchUrl, $this->current_status); // current_status
        $this->buildSearchUrl($srchUrl, $this->tin_number); // tin_number
        $this->buildSearchUrl($srchUrl, $this->nssf_number); // nssf_number
        $this->buildSearchUrl($srchUrl, $this->salary_amount); // salary_amount
        $this->buildSearchUrl($srchUrl, $this->employement_type); // employement_type
        $this->buildSearchUrl($srchUrl, $this->work_schedule); // work_schedule
        $this->buildSearchUrl($srchUrl, $this->sex); // sex
        if ($srchUrl != "") {
            $srchUrl .= "&";
        }
        $srchUrl .= "cmd=search";
        return $srchUrl;
    }

    // Build search URL
    protected function buildSearchUrl(&$url, $fld, $oprOnly = false)
    {
        global $CurrentForm;
        $wrk = "";
        $fldParm = $fld->Param;
        [
            "value" => $fldVal,
            "operator" => $fldOpr,
            "condition" => $fldCond,
            "value2" => $fldVal2,
            "operator2" => $fldOpr2
        ] = $CurrentForm->getSearchValues($fldParm);
        if (is_array($fldVal)) {
            $fldVal = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal);
        }
        if (is_array($fldVal2)) {
            $fldVal2 = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $fldVal2);
        }
        $fldDataType = $fld->DataType;
        $value = ConvertSearchValue($fldVal, $fldOpr, $fld); // For testing if numeric only
        $value2 = ConvertSearchValue($fldVal2, $fldOpr2, $fld); // For testing if numeric only
        $fldOpr = ConvertSearchOperator($fldOpr, $fld, $value);
        $fldOpr2 = ConvertSearchOperator($fldOpr2, $fld, $value2);
        if (in_array($fldOpr, ["BETWEEN", "NOT BETWEEN"])) {
            $isValidValue = $fldDataType != DATATYPE_NUMBER || $fld->VirtualSearch || IsNumericSearchValue($value, $fldOpr, $fld) && IsNumericSearchValue($value2, $fldOpr2, $fld);
            if ($fldVal != "" && $fldVal2 != "" && $isValidValue) {
                $wrk = "x_" . $fldParm . "=" . urlencode($fldVal) . "&y_" . $fldParm . "=" . urlencode($fldVal2) . "&z_" . $fldParm . "=" . urlencode($fldOpr);
            }
        } else {
            $isValidValue = $fldDataType != DATATYPE_NUMBER || $fld->VirtualSearch || IsNumericSearchValue($value, $fldOpr, $fld);
            if ($fldVal != "" && $isValidValue && IsValidOperator($fldOpr)) {
                $wrk = "x_" . $fldParm . "=" . urlencode($fldVal) . "&z_" . $fldParm . "=" . urlencode($fldOpr);
            } elseif (in_array($fldOpr, ["IS NULL", "IS NOT NULL", "IS EMPTY", "IS NOT EMPTY"]) || ($fldOpr != "" && $oprOnly && IsValidOperator($fldOpr))) {
                $wrk = "z_" . $fldParm . "=" . urlencode($fldOpr);
            }
            $isValidValue = $fldDataType != DATATYPE_NUMBER || $fld->VirtualSearch || IsNumericSearchValue($value2, $fldOpr2, $fld);
            if ($fldVal2 != "" && $isValidValue && IsValidOperator($fldOpr2)) {
                if ($wrk != "") {
                    $wrk .= "&v_" . $fldParm . "=" . urlencode($fldCond) . "&";
                }
                $wrk .= "y_" . $fldParm . "=" . urlencode($fldVal2) . "&w_" . $fldParm . "=" . urlencode($fldOpr2);
            } elseif (in_array($fldOpr2, ["IS NULL", "IS NOT NULL", "IS EMPTY", "IS NOT EMPTY"]) || ($fldOpr2 != "" && $oprOnly && IsValidOperator($fldOpr2))) {
                if ($wrk != "") {
                    $wrk .= "&v_" . $fldParm . "=" . urlencode($fldCond) . "&";
                }
                $wrk .= "w_" . $fldParm . "=" . urlencode($fldOpr2);
            }
        }
        if ($wrk != "") {
            if ($url != "") {
                $url .= "&";
            }
            $url .= $wrk;
        }
    }

    // Load search values for validation
    protected function loadSearchValues()
    {
        // Load search values
        $hasValue = false;

        // id
        if ($this->id->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // employee_number
        if ($this->employee_number->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // first_name
        if ($this->first_name->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // last_name
        if ($this->last_name->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // other_name
        if ($this->other_name->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // job_tile
        if ($this->job_tile->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // pri_phone_no
        if ($this->pri_phone_no->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // alt_phone_no
        if ($this->alt_phone_no->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // personal_email
        if ($this->personal_email->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // official_email
        if ($this->official_email->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // department
        if ($this->department->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // hire_date
        if ($this->hire_date->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // current_status
        if ($this->current_status->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // tin_number
        if ($this->tin_number->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // nssf_number
        if ($this->nssf_number->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // salary_amount
        if ($this->salary_amount->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // employement_type
        if ($this->employement_type->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // work_schedule
        if ($this->work_schedule->AdvancedSearch->get()) {
            $hasValue = true;
        }

        // sex
        if ($this->sex->AdvancedSearch->get()) {
            $hasValue = true;
        }
        return $hasValue;
    }

    // Render row values based on field settings
    public function renderRow()
    {
        global $Security, $Language, $CurrentLanguage;

        // Initialize URLs

        // Call Row_Rendering event
        $this->rowRendering();

        // Common render codes for all row types

        // id
        $this->id->RowCssClass = "row";

        // employee_number
        $this->employee_number->RowCssClass = "row";

        // first_name
        $this->first_name->RowCssClass = "row";

        // last_name
        $this->last_name->RowCssClass = "row";

        // other_name
        $this->other_name->RowCssClass = "row";

        // job_tile
        $this->job_tile->RowCssClass = "row";

        // pri_phone_no
        $this->pri_phone_no->RowCssClass = "row";

        // alt_phone_no
        $this->alt_phone_no->RowCssClass = "row";

        // personal_email
        $this->personal_email->RowCssClass = "row";

        // official_email
        $this->official_email->RowCssClass = "row";

        // department
        $this->department->RowCssClass = "row";

        // hire_date
        $this->hire_date->RowCssClass = "row";

        // current_status
        $this->current_status->RowCssClass = "row";

        // tin_number
        $this->tin_number->RowCssClass = "row";

        // nssf_number
        $this->nssf_number->RowCssClass = "row";

        // salary_amount
        $this->salary_amount->RowCssClass = "row";

        // employement_type
        $this->employement_type->RowCssClass = "row";

        // work_schedule
        $this->work_schedule->RowCssClass = "row";

        // sex
        $this->sex->RowCssClass = "row";

        // entry_date
        $this->entry_date->RowCssClass = "row";

        // last_modified
        $this->last_modified->RowCssClass = "row";

        // entered_by
        $this->entered_by->RowCssClass = "row";

        // modified_by
        $this->modified_by->RowCssClass = "row";

        // View row
        if ($this->RowType == ROWTYPE_VIEW) {
            // id
            $this->id->ViewValue = $this->id->CurrentValue;
            $this->id->ViewValue = FormatNumber($this->id->ViewValue, $this->id->formatPattern());

            // employee_number
            $this->employee_number->ViewValue = $this->employee_number->CurrentValue;

            // first_name
            $this->first_name->ViewValue = $this->first_name->CurrentValue;

            // last_name
            $this->last_name->ViewValue = $this->last_name->CurrentValue;

            // other_name
            $this->other_name->ViewValue = $this->other_name->CurrentValue;

            // job_tile
            $this->job_tile->ViewValue = $this->job_tile->CurrentValue;

            // pri_phone_no
            $this->pri_phone_no->ViewValue = $this->pri_phone_no->CurrentValue;

            // alt_phone_no
            $this->alt_phone_no->ViewValue = $this->alt_phone_no->CurrentValue;

            // personal_email
            $this->personal_email->ViewValue = $this->personal_email->CurrentValue;

            // official_email
            $this->official_email->ViewValue = $this->official_email->CurrentValue;

            // department
            $this->department->ViewValue = $this->department->CurrentValue;

            // hire_date
            $this->hire_date->ViewValue = $this->hire_date->CurrentValue;
            $this->hire_date->ViewValue = FormatDateTime($this->hire_date->ViewValue, $this->hire_date->formatPattern());

            // current_status
            if (strval($this->current_status->CurrentValue) != "") {
                $this->current_status->ViewValue = $this->current_status->optionCaption($this->current_status->CurrentValue);
            } else {
                $this->current_status->ViewValue = null;
            }

            // tin_number
            $this->tin_number->ViewValue = $this->tin_number->CurrentValue;

            // nssf_number
            $this->nssf_number->ViewValue = $this->nssf_number->CurrentValue;

            // salary_amount
            $this->salary_amount->ViewValue = $this->salary_amount->CurrentValue;
            $this->salary_amount->ViewValue = FormatNumber($this->salary_amount->ViewValue, $this->salary_amount->formatPattern());

            // employement_type
            if (strval($this->employement_type->CurrentValue) != "") {
                $this->employement_type->ViewValue = $this->employement_type->optionCaption($this->employement_type->CurrentValue);
            } else {
                $this->employement_type->ViewValue = null;
            }

            // work_schedule
            if (strval($this->work_schedule->CurrentValue) != "") {
                $this->work_schedule->ViewValue = $this->work_schedule->optionCaption($this->work_schedule->CurrentValue);
            } else {
                $this->work_schedule->ViewValue = null;
            }

            // sex
            if (strval($this->sex->CurrentValue) != "") {
                $this->sex->ViewValue = $this->sex->optionCaption($this->sex->CurrentValue);
            } else {
                $this->sex->ViewValue = null;
            }

            // entry_date
            $this->entry_date->ViewValue = $this->entry_date->CurrentValue;
            $this->entry_date->ViewValue = FormatDateTime($this->entry_date->ViewValue, $this->entry_date->formatPattern());

            // last_modified
            $this->last_modified->ViewValue = $this->last_modified->CurrentValue;
            $this->last_modified->ViewValue = FormatDateTime($this->last_modified->ViewValue, $this->last_modified->formatPattern());

            // entered_by
            if ($this->entered_by->VirtualValue != "") {
                $this->entered_by->ViewValue = $this->entered_by->VirtualValue;
            } else {
                $this->entered_by->ViewValue = $this->entered_by->CurrentValue;
                $curVal = strval($this->entered_by->CurrentValue);
                if ($curVal != "") {
                    $this->entered_by->ViewValue = $this->entered_by->lookupCacheOption($curVal);
                    if ($this->entered_by->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->entered_by->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->entered_by->Lookup->renderViewRow($rswrk[0]);
                            $this->entered_by->ViewValue = $this->entered_by->displayValue($arwrk);
                        } else {
                            $this->entered_by->ViewValue = FormatNumber($this->entered_by->CurrentValue, $this->entered_by->formatPattern());
                        }
                    }
                } else {
                    $this->entered_by->ViewValue = null;
                }
            }

            // modified_by
            if ($this->modified_by->VirtualValue != "") {
                $this->modified_by->ViewValue = $this->modified_by->VirtualValue;
            } else {
                $this->modified_by->ViewValue = $this->modified_by->CurrentValue;
                $curVal = strval($this->modified_by->CurrentValue);
                if ($curVal != "") {
                    $this->modified_by->ViewValue = $this->modified_by->lookupCacheOption($curVal);
                    if ($this->modified_by->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->modified_by->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->modified_by->Lookup->renderViewRow($rswrk[0]);
                            $this->modified_by->ViewValue = $this->modified_by->displayValue($arwrk);
                        } else {
                            $this->modified_by->ViewValue = FormatNumber($this->modified_by->CurrentValue, $this->modified_by->formatPattern());
                        }
                    }
                } else {
                    $this->modified_by->ViewValue = null;
                }
            }

            // id
            $this->id->HrefValue = "";
            $this->id->TooltipValue = "";

            // employee_number
            $this->employee_number->HrefValue = "";
            $this->employee_number->TooltipValue = "";

            // first_name
            $this->first_name->HrefValue = "";
            $this->first_name->TooltipValue = "";

            // last_name
            $this->last_name->HrefValue = "";
            $this->last_name->TooltipValue = "";

            // other_name
            $this->other_name->HrefValue = "";
            $this->other_name->TooltipValue = "";

            // job_tile
            $this->job_tile->HrefValue = "";
            $this->job_tile->TooltipValue = "";

            // pri_phone_no
            $this->pri_phone_no->HrefValue = "";
            $this->pri_phone_no->TooltipValue = "";

            // alt_phone_no
            $this->alt_phone_no->HrefValue = "";
            $this->alt_phone_no->TooltipValue = "";

            // personal_email
            $this->personal_email->HrefValue = "";
            $this->personal_email->TooltipValue = "";

            // official_email
            $this->official_email->HrefValue = "";
            $this->official_email->TooltipValue = "";

            // department
            $this->department->HrefValue = "";
            $this->department->TooltipValue = "";

            // hire_date
            $this->hire_date->HrefValue = "";
            $this->hire_date->TooltipValue = "";

            // current_status
            $this->current_status->HrefValue = "";
            $this->current_status->TooltipValue = "";

            // tin_number
            $this->tin_number->HrefValue = "";
            $this->tin_number->TooltipValue = "";

            // nssf_number
            $this->nssf_number->HrefValue = "";
            $this->nssf_number->TooltipValue = "";

            // salary_amount
            $this->salary_amount->HrefValue = "";
            $this->salary_amount->TooltipValue = "";

            // employement_type
            $this->employement_type->HrefValue = "";
            $this->employement_type->TooltipValue = "";

            // work_schedule
            $this->work_schedule->HrefValue = "";
            $this->work_schedule->TooltipValue = "";

            // sex
            $this->sex->HrefValue = "";
            $this->sex->TooltipValue = "";
        } elseif ($this->RowType == ROWTYPE_SEARCH) {
            // id
            $this->id->setupEditAttributes();
            $this->id->EditValue = $this->id->AdvancedSearch->SearchValue;
            $this->id->PlaceHolder = RemoveHtml($this->id->title());
            $this->id->setupEditAttributes();
            $this->id->EditValue2 = $this->id->AdvancedSearch->SearchValue2;
            $this->id->PlaceHolder = RemoveHtml($this->id->title());

            // employee_number
            $this->employee_number->setupEditAttributes();
            if (!$this->employee_number->Raw) {
                $this->employee_number->AdvancedSearch->SearchValue = HtmlDecode($this->employee_number->AdvancedSearch->SearchValue);
            }
            $this->employee_number->EditValue = HtmlEncode($this->employee_number->AdvancedSearch->SearchValue);
            $this->employee_number->PlaceHolder = RemoveHtml($this->employee_number->title());

            // first_name
            $this->first_name->setupEditAttributes();
            if (!$this->first_name->Raw) {
                $this->first_name->AdvancedSearch->SearchValue = HtmlDecode($this->first_name->AdvancedSearch->SearchValue);
            }
            $this->first_name->EditValue = HtmlEncode($this->first_name->AdvancedSearch->SearchValue);
            $this->first_name->PlaceHolder = RemoveHtml($this->first_name->title());

            // last_name
            $this->last_name->setupEditAttributes();
            if (!$this->last_name->Raw) {
                $this->last_name->AdvancedSearch->SearchValue = HtmlDecode($this->last_name->AdvancedSearch->SearchValue);
            }
            $this->last_name->EditValue = HtmlEncode($this->last_name->AdvancedSearch->SearchValue);
            $this->last_name->PlaceHolder = RemoveHtml($this->last_name->title());

            // other_name
            $this->other_name->setupEditAttributes();
            if (!$this->other_name->Raw) {
                $this->other_name->AdvancedSearch->SearchValue = HtmlDecode($this->other_name->AdvancedSearch->SearchValue);
            }
            $this->other_name->EditValue = HtmlEncode($this->other_name->AdvancedSearch->SearchValue);
            $this->other_name->PlaceHolder = RemoveHtml($this->other_name->title());

            // job_tile
            $this->job_tile->setupEditAttributes();
            if (!$this->job_tile->Raw) {
                $this->job_tile->AdvancedSearch->SearchValue = HtmlDecode($this->job_tile->AdvancedSearch->SearchValue);
            }
            $this->job_tile->EditValue = HtmlEncode($this->job_tile->AdvancedSearch->SearchValue);
            $this->job_tile->PlaceHolder = RemoveHtml($this->job_tile->title());

            // pri_phone_no
            $this->pri_phone_no->setupEditAttributes();
            if (!$this->pri_phone_no->Raw) {
                $this->pri_phone_no->AdvancedSearch->SearchValue = HtmlDecode($this->pri_phone_no->AdvancedSearch->SearchValue);
            }
            $this->pri_phone_no->EditValue = HtmlEncode($this->pri_phone_no->AdvancedSearch->SearchValue);
            $this->pri_phone_no->PlaceHolder = RemoveHtml($this->pri_phone_no->title());

            // alt_phone_no
            $this->alt_phone_no->setupEditAttributes();
            if (!$this->alt_phone_no->Raw) {
                $this->alt_phone_no->AdvancedSearch->SearchValue = HtmlDecode($this->alt_phone_no->AdvancedSearch->SearchValue);
            }
            $this->alt_phone_no->EditValue = HtmlEncode($this->alt_phone_no->AdvancedSearch->SearchValue);
            $this->alt_phone_no->PlaceHolder = RemoveHtml($this->alt_phone_no->title());

            // personal_email
            $this->personal_email->setupEditAttributes();
            if (!$this->personal_email->Raw) {
                $this->personal_email->AdvancedSearch->SearchValue = HtmlDecode($this->personal_email->AdvancedSearch->SearchValue);
            }
            $this->personal_email->EditValue = HtmlEncode($this->personal_email->AdvancedSearch->SearchValue);
            $this->personal_email->PlaceHolder = RemoveHtml($this->personal_email->title());

            // official_email
            $this->official_email->setupEditAttributes();
            if (!$this->official_email->Raw) {
                $this->official_email->AdvancedSearch->SearchValue = HtmlDecode($this->official_email->AdvancedSearch->SearchValue);
            }
            $this->official_email->EditValue = HtmlEncode($this->official_email->AdvancedSearch->SearchValue);
            $this->official_email->PlaceHolder = RemoveHtml($this->official_email->title());

            // department
            $this->department->setupEditAttributes();
            if (!$this->department->Raw) {
                $this->department->AdvancedSearch->SearchValue = HtmlDecode($this->department->AdvancedSearch->SearchValue);
            }
            $this->department->EditValue = HtmlEncode($this->department->AdvancedSearch->SearchValue);
            $this->department->PlaceHolder = RemoveHtml($this->department->title());

            // hire_date
            $this->hire_date->setupEditAttributes();
            $this->hire_date->EditValue = HtmlEncode(FormatDateTime(UnFormatDateTime($this->hire_date->AdvancedSearch->SearchValue, $this->hire_date->formatPattern()), $this->hire_date->formatPattern()));
            $this->hire_date->PlaceHolder = RemoveHtml($this->hire_date->title());

            // current_status
            $this->current_status->setupEditAttributes();
            $this->current_status->EditValue = $this->current_status->options(true);
            $this->current_status->PlaceHolder = RemoveHtml($this->current_status->title());

            // tin_number
            $this->tin_number->setupEditAttributes();
            if (!$this->tin_number->Raw) {
                $this->tin_number->AdvancedSearch->SearchValue = HtmlDecode($this->tin_number->AdvancedSearch->SearchValue);
            }
            $this->tin_number->EditValue = HtmlEncode($this->tin_number->AdvancedSearch->SearchValue);
            $this->tin_number->PlaceHolder = RemoveHtml($this->tin_number->title());

            // nssf_number
            $this->nssf_number->setupEditAttributes();
            if (!$this->nssf_number->Raw) {
                $this->nssf_number->AdvancedSearch->SearchValue = HtmlDecode($this->nssf_number->AdvancedSearch->SearchValue);
            }
            $this->nssf_number->EditValue = HtmlEncode($this->nssf_number->AdvancedSearch->SearchValue);
            $this->nssf_number->PlaceHolder = RemoveHtml($this->nssf_number->title());

            // salary_amount
            $this->salary_amount->setupEditAttributes(["step" => "50"]);
            $this->salary_amount->EditValue = $this->salary_amount->AdvancedSearch->SearchValue;
            $this->salary_amount->PlaceHolder = RemoveHtml($this->salary_amount->title());

            // employement_type
            $this->employement_type->setupEditAttributes();
            $this->employement_type->EditValue = $this->employement_type->options(true);
            $this->employement_type->PlaceHolder = RemoveHtml($this->employement_type->title());

            // work_schedule
            $this->work_schedule->setupEditAttributes();
            $this->work_schedule->EditValue = $this->work_schedule->options(true);
            $this->work_schedule->PlaceHolder = RemoveHtml($this->work_schedule->title());

            // sex
            $this->sex->setupEditAttributes();
            $this->sex->EditValue = $this->sex->options(true);
            $this->sex->PlaceHolder = RemoveHtml($this->sex->title());
        }
        if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) { // Add/Edit/Search row
            $this->setupFieldTitles();
        }

        // Call Row Rendered event
        if ($this->RowType != ROWTYPE_AGGREGATEINIT) {
            $this->rowRendered();
        }
    }

    // Validate search
    protected function validateSearch()
    {
        // Check if validation required
        if (!Config("SERVER_VALIDATE")) {
            return true;
        }
        if (!CheckInteger($this->id->AdvancedSearch->SearchValue)) {
            $this->id->addErrorMessage($this->id->getErrorMessage(false));
        }
        if (!CheckInteger($this->id->AdvancedSearch->SearchValue2)) {
            $this->id->addErrorMessage($this->id->getErrorMessage(false));
        }
        if (!CheckDate($this->hire_date->AdvancedSearch->SearchValue, $this->hire_date->formatPattern())) {
            $this->hire_date->addErrorMessage($this->hire_date->getErrorMessage(false));
        }
        if (!CheckNumber($this->salary_amount->AdvancedSearch->SearchValue)) {
            $this->salary_amount->addErrorMessage($this->salary_amount->getErrorMessage(false));
        }

        // Return validate result
        $validateSearch = !$this->hasInvalidFields();

        // Call Form_CustomValidate event
        $formCustomError = "";
        $validateSearch = $validateSearch && $this->formCustomValidate($formCustomError);
        if ($formCustomError != "") {
            $this->setFailureMessage($formCustomError);
        }
        return $validateSearch;
    }

    // Load advanced search
    public function loadAdvancedSearch()
    {
        $this->id->AdvancedSearch->load();
        $this->employee_number->AdvancedSearch->load();
        $this->first_name->AdvancedSearch->load();
        $this->last_name->AdvancedSearch->load();
        $this->other_name->AdvancedSearch->load();
        $this->job_tile->AdvancedSearch->load();
        $this->pri_phone_no->AdvancedSearch->load();
        $this->alt_phone_no->AdvancedSearch->load();
        $this->personal_email->AdvancedSearch->load();
        $this->official_email->AdvancedSearch->load();
        $this->department->AdvancedSearch->load();
        $this->hire_date->AdvancedSearch->load();
        $this->current_status->AdvancedSearch->load();
        $this->tin_number->AdvancedSearch->load();
        $this->nssf_number->AdvancedSearch->load();
        $this->salary_amount->AdvancedSearch->load();
        $this->employement_type->AdvancedSearch->load();
        $this->work_schedule->AdvancedSearch->load();
        $this->sex->AdvancedSearch->load();
    }

    // Set up Breadcrumb
    protected function setupBreadcrumb()
    {
        global $Breadcrumb, $Language;
        $Breadcrumb = new Breadcrumb("index");
        $url = CurrentUrl();
        $Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("tbemployeelist"), "", $this->TableVar, true);
        $pageId = "search";
        $Breadcrumb->add("search", $pageId, $url);
    }

    // Setup lookup options
    public function setupLookupOptions($fld)
    {
        if ($fld->Lookup !== null && $fld->Lookup->Options === null) {
            // Get default connection and filter
            $conn = $this->getConnection();
            $lookupFilter = "";

            // No need to check any more
            $fld->Lookup->Options = [];

            // Set up lookup SQL and connection
            switch ($fld->FieldVar) {
                case "x_current_status":
                    break;
                case "x_employement_type":
                    break;
                case "x_work_schedule":
                    break;
                case "x_sex":
                    break;
                case "x_entered_by":
                    break;
                case "x_modified_by":
                    break;
                default:
                    $lookupFilter = "";
                    break;
            }

            // Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
            $sql = $fld->Lookup->getSql(false, "", $lookupFilter, $this);

            // Set up lookup cache
            if (!$fld->hasLookupOptions() && $fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0 && count($fld->Lookup->FilterFields) == 0) {
                $totalCnt = $this->getRecordCount($sql, $conn);
                if ($totalCnt > $fld->LookupCacheCount) { // Total count > cache count, do not cache
                    return;
                }
                $rows = $conn->executeQuery($sql)->fetchAll();
                $ar = [];
                foreach ($rows as $row) {
                    $row = $fld->Lookup->renderViewRow($row, Container($fld->Lookup->LinkTable));
                    $key = $row["lf"];
                    if (IsFloatType($fld->Type)) { // Handle float field
                        $key = (float)$key;
                    }
                    $ar[strval($key)] = $row;
                }
                $fld->Lookup->Options = $ar;
            }
        }
    }

    // Page Load event
    public function pageLoad()
    {
        //Log("Page Load");
    }

    // Page Unload event
    public function pageUnload()
    {
        //Log("Page Unload");
    }

    // Page Redirecting event
    public function pageRedirecting(&$url)
    {
        // Example:
        //$url = "your URL";
    }

    // Message Showing event
    // $type = ''|'success'|'failure'|'warning'
    public function messageShowing(&$msg, $type)
    {
        if ($type == 'success') {
            //$msg = "your success message";
        } elseif ($type == 'failure') {
            //$msg = "your failure message";
        } elseif ($type == 'warning') {
            //$msg = "your warning message";
        } else {
            //$msg = "your message";
        }
    }

    // Page Render event
    public function pageRender()
    {
        //Log("Page Render");
    }

    // Page Data Rendering event
    public function pageDataRendering(&$header)
    {
        // Example:
        //$header = "your header";
    }

    // Page Data Rendered event
    public function pageDataRendered(&$footer)
    {
        // Example:
        //$footer = "your footer";
    }

    // Page Breaking event
    public function pageBreaking(&$break, &$content)
    {
        // Example:
        //$break = false; // Skip page break, or
        //$content = "<div style=\"break-after:page;\"></div>"; // Modify page break content
    }

    // Form Custom Validate event
    public function formCustomValidate(&$customError)
    {
        // Return error message in $customError
        return true;
    }
}
