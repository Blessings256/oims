<?php

namespace PHPMaker2023\OIMS;

use Doctrine\DBAL\ParameterType;
use Doctrine\DBAL\FetchMode;
use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;

/**
 * Page class
 */
class TbImmunisationEdit extends TbImmunisation
{
    use MessagesTrait;

    // Page ID
    public $PageID = "edit";

    // Project ID
    public $ProjectID = PROJECT_ID;

    // Page object name
    public $PageObjName = "TbImmunisationEdit";

    // View file path
    public $View = null;

    // Title
    public $Title = null; // Title for <title> tag

    // Rendering View
    public $RenderingView = false;

    // CSS class/style
    public $CurrentPageName = "tbimmunisationedit";

    // Page headings
    public $Heading = "";
    public $Subheading = "";
    public $PageHeader;
    public $PageFooter;

    // Page layout
    public $UseLayout = true;

    // Page terminated
    private $terminated = false;

    // Page heading
    public function pageHeading()
    {
        global $Language;
        if ($this->Heading != "") {
            return $this->Heading;
        }
        if (method_exists($this, "tableCaption")) {
            return $this->tableCaption();
        }
        return "";
    }

    // Page subheading
    public function pageSubheading()
    {
        global $Language;
        if ($this->Subheading != "") {
            return $this->Subheading;
        }
        if ($this->TableName) {
            return $Language->phrase($this->PageID);
        }
        return "";
    }

    // Page name
    public function pageName()
    {
        return CurrentPageName();
    }

    // Page URL
    public function pageUrl($withArgs = true)
    {
        $route = GetRoute();
        $args = RemoveXss($route->getArguments());
        if (!$withArgs) {
            foreach ($args as $key => &$val) {
                $val = "";
            }
            unset($val);
        }
        return rtrim(UrlFor($route->getName(), $args), "/") . "?";
    }

    // Show Page Header
    public function showPageHeader()
    {
        $header = $this->PageHeader;
        $this->pageDataRendering($header);
        if ($header != "") { // Header exists, display
            echo '<p id="ew-page-header">' . $header . '</p>';
        }
    }

    // Show Page Footer
    public function showPageFooter()
    {
        $footer = $this->PageFooter;
        $this->pageDataRendered($footer);
        if ($footer != "") { // Footer exists, display
            echo '<p id="ew-page-footer">' . $footer . '</p>';
        }
    }

    // Set field visibility
    public function setVisibility()
    {
        $this->id->setVisibility();
        $this->vaccination_date->setVisibility();
        $this->child_id->setVisibility();
        $this->vaccine_id->setVisibility();
        $this->dose_cycle->setVisibility();
        $this->next_vaccination_date->setVisibility();
        $this->administered_by->setVisibility();
        $this->remarks->setVisibility();
        $this->entry_date->setVisibility();
        $this->last_modified->setVisibility();
        $this->entered_by->setVisibility();
        $this->modified_by->setVisibility();
    }

    // Constructor
    public function __construct()
    {
        parent::__construct();
        global $Language, $DashboardReport, $DebugTimer, $UserTable;
        $this->TableVar = 'tb_immunisation';
        $this->TableName = 'tb_immunisation';

        // Table CSS class
        $this->TableClass = "table table-striped table-bordered table-hover table-sm ew-desktop-table ew-edit-table";

        // Initialize
        $GLOBALS["Page"] = &$this;

        // Language object
        $Language = Container("language");

        // Table object (tb_immunisation)
        if (!isset($GLOBALS["tb_immunisation"]) || get_class($GLOBALS["tb_immunisation"]) == PROJECT_NAMESPACE . "tb_immunisation") {
            $GLOBALS["tb_immunisation"] = &$this;
        }

        // Table name (for backward compatibility only)
        if (!defined(PROJECT_NAMESPACE . "TABLE_NAME")) {
            define(PROJECT_NAMESPACE . "TABLE_NAME", 'tb_immunisation');
        }

        // Start timer
        $DebugTimer = Container("timer");

        // Debug message
        LoadDebugMessage();

        // Open connection
        $GLOBALS["Conn"] ??= $this->getConnection();

        // User table object
        $UserTable = Container("usertable");
    }

    // Get content from stream
    public function getContents(): string
    {
        global $Response;
        return is_object($Response) ? $Response->getBody() : ob_get_clean();
    }

    // Is lookup
    public function isLookup()
    {
        return SameText(Route(0), Config("API_LOOKUP_ACTION"));
    }

    // Is AutoFill
    public function isAutoFill()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autofill");
    }

    // Is AutoSuggest
    public function isAutoSuggest()
    {
        return $this->isLookup() && SameText(Post("ajax"), "autosuggest");
    }

    // Is modal lookup
    public function isModalLookup()
    {
        return $this->isLookup() && SameText(Post("ajax"), "modal");
    }

    // Is terminated
    public function isTerminated()
    {
        return $this->terminated;
    }

    /**
     * Terminate page
     *
     * @param string $url URL for direction
     * @return void
     */
    public function terminate($url = "")
    {
        if ($this->terminated) {
            return;
        }
        global $TempImages, $DashboardReport, $Response;

        // Page is terminated
        $this->terminated = true;

        // Page Unload event
        if (method_exists($this, "pageUnload")) {
            $this->pageUnload();
        }

        // Global Page Unloaded event (in userfn*.php)
        Page_Unloaded();
        if (!IsApi() && method_exists($this, "pageRedirecting")) {
            $this->pageRedirecting($url);
        }

        // Close connection
        CloseConnections();

        // Return for API
        if (IsApi()) {
            $res = $url === true;
            if (!$res) { // Show response for API
                $ar = array_merge($this->getMessages(), $url ? ["url" => GetUrl($url)] : []);
                WriteJson($ar);
            }
            $this->clearMessages(); // Clear messages for API request
            return;
        } else { // Check if response is JSON
            if (StartsString("application/json", $Response->getHeaderLine("Content-type")) && $Response->getBody()->getSize()) { // With JSON response
                $this->clearMessages();
                return;
            }
        }

        // Go to URL if specified
        if ($url != "") {
            if (!Config("DEBUG") && ob_get_length()) {
                ob_end_clean();
            }

            // Handle modal response (Assume return to modal for simplicity)
            if ($this->IsModal) { // Show as modal
                $result = ["url" => GetUrl($url), "modal" => "1"];
                $pageName = GetPageName($url);
                if ($pageName != $this->getListUrl()) { // Not List page => View page
                    $result["caption"] = $this->getModalCaption($pageName);
                    $result["view"] = $pageName == "tbimmunisationview"; // If View page, no primary button
                } else { // List page
                    // $result["list"] = $this->PageID == "search"; // Refresh List page if current page is Search page
                    $result["error"] = $this->getFailureMessage(); // List page should not be shown as modal => error
                    $this->clearFailureMessage();
                }
                WriteJson($result);
            } else {
                SaveDebugMessage();
                Redirect(GetUrl($url));
            }
        }
        return; // Return to controller
    }

    // Get records from recordset
    protected function getRecordsFromRecordset($rs, $current = false)
    {
        $rows = [];
        if (is_object($rs)) { // Recordset
            while ($rs && !$rs->EOF) {
                $this->loadRowValues($rs); // Set up DbValue/CurrentValue
                $row = $this->getRecordFromArray($rs->fields);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
                $rs->moveNext();
            }
        } elseif (is_array($rs)) {
            foreach ($rs as $ar) {
                $row = $this->getRecordFromArray($ar);
                if ($current) {
                    return $row;
                } else {
                    $rows[] = $row;
                }
            }
        }
        return $rows;
    }

    // Get record from array
    protected function getRecordFromArray($ar)
    {
        $row = [];
        if (is_array($ar)) {
            foreach ($ar as $fldname => $val) {
                if (array_key_exists($fldname, $this->Fields) && ($this->Fields[$fldname]->Visible || $this->Fields[$fldname]->IsPrimaryKey)) { // Primary key or Visible
                    $fld = &$this->Fields[$fldname];
                    if ($fld->HtmlTag == "FILE") { // Upload field
                        if (EmptyValue($val)) {
                            $row[$fldname] = null;
                        } else {
                            if ($fld->DataType == DATATYPE_BLOB) {
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . $fld->Param . "/" . rawurlencode($this->getRecordKeyValue($ar))));
                                $row[$fldname] = ["type" => ContentType($val), "url" => $url, "name" => $fld->Param . ContentExtension($val)];
                            } elseif (!$fld->UploadMultiple || !ContainsString($val, Config("MULTIPLE_UPLOAD_SEPARATOR"))) { // Single file
                                $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                    "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $val)));
                                $row[$fldname] = ["type" => MimeContentType($val), "url" => $url, "name" => $val];
                            } else { // Multiple files
                                $files = explode(Config("MULTIPLE_UPLOAD_SEPARATOR"), $val);
                                $ar = [];
                                foreach ($files as $file) {
                                    $url = FullUrl(GetApiUrl(Config("API_FILE_ACTION") .
                                        "/" . $fld->TableVar . "/" . Encrypt($fld->physicalUploadPath() . $file)));
                                    if (!EmptyValue($file)) {
                                        $ar[] = ["type" => MimeContentType($file), "url" => $url, "name" => $file];
                                    }
                                }
                                $row[$fldname] = $ar;
                            }
                        }
                    } else {
                        $row[$fldname] = $val;
                    }
                }
            }
        }
        return $row;
    }

    // Get record key value from array
    protected function getRecordKeyValue($ar)
    {
        $key = "";
        if (is_array($ar)) {
            $key .= @$ar['id'];
        }
        return $key;
    }

    /**
     * Hide fields for add/edit
     *
     * @return void
     */
    protected function hideFieldsForAddEdit()
    {
        if ($this->isAdd() || $this->isCopy() || $this->isGridAdd()) {
            $this->id->Visible = false;
        }
    }

    // Lookup data
    public function lookup($ar = null)
    {
        global $Language, $Security;

        // Get lookup object
        $fieldName = $ar["field"] ?? Post("field");
        $lookup = $this->Fields[$fieldName]->Lookup;
        $name = $ar["name"] ?? Post("name");
        $isQuery = ContainsString($name, "query_builder_rule");
        if ($isQuery) {
            $lookup->FilterFields = []; // Skip parent fields if any
        }

        // Get lookup parameters
        $lookupType = $ar["ajax"] ?? Post("ajax", "unknown");
        $pageSize = -1;
        $offset = -1;
        $searchValue = "";
        if (SameText($lookupType, "modal") || SameText($lookupType, "filter")) {
            $searchValue = $ar["q"] ?? Param("q") ?? $ar["sv"] ?? Post("sv", "");
            $pageSize = $ar["n"] ?? Param("n") ?? $ar["recperpage"] ?? Post("recperpage", 10);
        } elseif (SameText($lookupType, "autosuggest")) {
            $searchValue = $ar["q"] ?? Param("q", "");
            $pageSize = $ar["n"] ?? Param("n", -1);
            $pageSize = is_numeric($pageSize) ? (int)$pageSize : -1;
            if ($pageSize <= 0) {
                $pageSize = Config("AUTO_SUGGEST_MAX_ENTRIES");
            }
        }
        $start = $ar["start"] ?? Param("start", -1);
        $start = is_numeric($start) ? (int)$start : -1;
        $page = $ar["page"] ?? Param("page", -1);
        $page = is_numeric($page) ? (int)$page : -1;
        $offset = $start >= 0 ? $start : ($page > 0 && $pageSize > 0 ? ($page - 1) * $pageSize : 0);
        $userSelect = Decrypt($ar["s"] ?? Post("s", ""));
        $userFilter = Decrypt($ar["f"] ?? Post("f", ""));
        $userOrderBy = Decrypt($ar["o"] ?? Post("o", ""));
        $keys = $ar["keys"] ?? Post("keys");
        $lookup->LookupType = $lookupType; // Lookup type
        $lookup->FilterValues = []; // Clear filter values first
        if ($keys !== null) { // Selected records from modal
            if (is_array($keys)) {
                $keys = implode(Config("MULTIPLE_OPTION_SEPARATOR"), $keys);
            }
            $lookup->FilterFields = []; // Skip parent fields if any
            $lookup->FilterValues[] = $keys; // Lookup values
            $pageSize = -1; // Show all records
        } else { // Lookup values
            $lookup->FilterValues[] = $ar["v0"] ?? $ar["lookupValue"] ?? Post("v0", Post("lookupValue", ""));
        }
        $cnt = is_array($lookup->FilterFields) ? count($lookup->FilterFields) : 0;
        for ($i = 1; $i <= $cnt; $i++) {
            $lookup->FilterValues[] = $ar["v" . $i] ?? Post("v" . $i, "");
        }
        $lookup->SearchValue = $searchValue;
        $lookup->PageSize = $pageSize;
        $lookup->Offset = $offset;
        if ($userSelect != "") {
            $lookup->UserSelect = $userSelect;
        }
        if ($userFilter != "") {
            $lookup->UserFilter = $userFilter;
        }
        if ($userOrderBy != "") {
            $lookup->UserOrderBy = $userOrderBy;
        }
        return $lookup->toJson($this, !is_array($ar)); // Use settings from current page
    }

    // Properties
    public $FormClassName = "ew-form ew-edit-form overlay-wrapper";
    public $IsModal = false;
    public $IsMobileOrModal = false;
    public $DbMasterFilter;
    public $DbDetailFilter;
    public $HashValue; // Hash Value
    public $DisplayRecords = 1;
    public $StartRecord;
    public $StopRecord;
    public $TotalRecords = 0;
    public $RecordRange = 10;
    public $RecordCount;

    /**
     * Page run
     *
     * @return void
     */
    public function run()
    {
        global $ExportType, $UserProfile, $Language, $Security, $CurrentForm, $SkipHeaderFooter;

        // Is modal
        $this->IsModal = ConvertToBool(Param("modal"));
        $this->UseLayout = $this->UseLayout && !$this->IsModal;

        // Use layout
        $this->UseLayout = $this->UseLayout && ConvertToBool(Param(Config("PAGE_LAYOUT"), true));

        // View
        $this->View = Get(Config("VIEW"));

        // Create form object
        $CurrentForm = new HttpForm();
        $this->CurrentAction = Param("action"); // Set up current action
        $this->setVisibility();

        // Set lookup cache
        if (!in_array($this->PageID, Config("LOOKUP_CACHE_PAGE_IDS"))) {
            $this->setUseLookupCache(false);
        }

        // Global Page Loading event (in userfn*.php)
        Page_Loading();

        // Page Load event
        if (method_exists($this, "pageLoad")) {
            $this->pageLoad();
        }

        // Hide fields for add/edit
        if (!$this->UseAjaxActions) {
            $this->hideFieldsForAddEdit();
        }
        // Use inline delete
        if ($this->UseAjaxActions) {
            $this->InlineDelete = true;
        }

        // Set up lookup cache
        $this->setupLookupOptions($this->child_id);
        $this->setupLookupOptions($this->vaccine_id);
        $this->setupLookupOptions($this->dose_cycle);
        $this->setupLookupOptions($this->administered_by);
        $this->setupLookupOptions($this->entered_by);
        $this->setupLookupOptions($this->modified_by);

        // Check modal
        if ($this->IsModal) {
            $SkipHeaderFooter = true;
        }
        $this->IsMobileOrModal = IsMobile() || $this->IsModal;
        $loaded = false;
        $postBack = false;

        // Set up current action and primary key
        if (IsApi()) {
            // Load key values
            $loaded = true;
            if (($keyValue = Get("id") ?? Key(0) ?? Route(2)) !== null) {
                $this->id->setQueryStringValue($keyValue);
                $this->id->setOldValue($this->id->QueryStringValue);
            } elseif (Post("id") !== null) {
                $this->id->setFormValue(Post("id"));
                $this->id->setOldValue($this->id->FormValue);
            } else {
                $loaded = false; // Unable to load key
            }

            // Load record
            if ($loaded) {
                $loaded = $this->loadRow();
            }
            if (!$loaded) {
                $this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
                $this->terminate();
                return;
            }
            $this->CurrentAction = "update"; // Update record directly
            $this->OldKey = $this->getKey(true); // Get from CurrentValue
            $postBack = true;
        } else {
            if (Post("action", "") !== "") {
                $this->CurrentAction = Post("action"); // Get action code
                if (!$this->isShow()) { // Not reload record, handle as postback
                    $postBack = true;
                }

                // Get key from Form
                $this->setKey(Post($this->OldKeyName), $this->isShow());
            } else {
                $this->CurrentAction = "show"; // Default action is display

                // Load key from QueryString
                $loadByQuery = false;
                if (($keyValue = Get("id") ?? Route("id")) !== null) {
                    $this->id->setQueryStringValue($keyValue);
                    $loadByQuery = true;
                } else {
                    $this->id->CurrentValue = null;
                }
            }

            // Load recordset
            if ($this->isShow()) {
                    // Load current record
                    $loaded = $this->loadRow();
                $this->OldKey = $loaded ? $this->getKey(true) : ""; // Get from CurrentValue
            }
        }

        // Process form if post back
        if ($postBack) {
            $this->loadFormValues(); // Get form values
        }

        // Validate form if post back
        if ($postBack) {
            if (!$this->validateForm()) {
                $this->EventCancelled = true; // Event cancelled
                $this->restoreFormValues();
                if (IsApi()) {
                    $this->terminate();
                    return;
                } else {
                    $this->CurrentAction = ""; // Form error, reset action
                }
            }
        }

        // Perform current action
        switch ($this->CurrentAction) {
            case "show": // Get a record to display
                    if (!$loaded) { // Load record based on key
                        if ($this->getFailureMessage() == "") {
                            $this->setFailureMessage($Language->phrase("NoRecord")); // No record found
                        }
                        $this->terminate("tbimmunisationlist"); // No matching record, return to list
                        return;
                    }
                break;
            case "update": // Update
                $returnUrl = $this->getReturnUrl();
                if (GetPageName($returnUrl) == "tbimmunisationlist") {
                    $returnUrl = $this->addMasterUrl($returnUrl); // List page, return to List page with correct master key if necessary
                }
                $this->SendEmail = true; // Send email on update success
                if ($this->editRow()) { // Update record based on key
                    if ($this->getSuccessMessage() == "") {
                        $this->setSuccessMessage($Language->phrase("UpdateSuccess")); // Update success
                    }

                    // Handle UseAjaxActions with return page
                    if ($this->IsModal && $this->UseAjaxActions) {
                        $this->IsModal = false;
                        if (GetPageName($returnUrl) != "tbimmunisationlist") {
                            Container("flash")->addMessage("Return-Url", $returnUrl); // Save return URL
                            $returnUrl = "tbimmunisationlist"; // Return list page content
                        }
                    }
                    if (IsJsonResponse()) {
                        $this->terminate(true);
                        return;
                    } else {
                        $this->terminate($returnUrl); // Return to caller
                        return;
                    }
                } elseif (IsApi()) { // API request, return
                    $this->terminate();
                    return;
                } elseif ($this->IsModal && $this->UseAjaxActions) { // Return JSON error message
                    WriteJson([ "success" => false, "validation" => $this->getValidationErrors(), "error" => $this->getFailureMessage() ]);
                    $this->clearFailureMessage();
                    $this->terminate();
                    return;
                } elseif ($this->getFailureMessage() == $Language->phrase("NoRecord")) {
                    $this->terminate($returnUrl); // Return to caller
                    return;
                } else {
                    $this->EventCancelled = true; // Event cancelled
                    $this->restoreFormValues(); // Restore form values if update failed
                }
        }

        // Set up Breadcrumb
        $this->setupBreadcrumb();

        // Render the record
        $this->RowType = ROWTYPE_EDIT; // Render as Edit
        $this->resetAttributes();
        $this->renderRow();

        // Set LoginStatus / Page_Rendering / Page_Render
        if (!IsApi() && !$this->isTerminated()) {
            // Setup login status
            SetupLoginStatus();

            // Pass login status to client side
            SetClientVar("login", LoginStatus());

            // Global Page Rendering event (in userfn*.php)
            Page_Rendering();

            // Page Render event
            if (method_exists($this, "pageRender")) {
                $this->pageRender();
            }

            // Render search option
            if (method_exists($this, "renderSearchOptions")) {
                $this->renderSearchOptions();
            }
        }
    }

    // Get upload files
    protected function getUploadFiles()
    {
        global $CurrentForm, $Language;
    }

    // Load form values
    protected function loadFormValues()
    {
        // Load from form
        global $CurrentForm;
        $validate = !Config("SERVER_VALIDATE");

        // Check field name 'id' first before field var 'x_id'
        $val = $CurrentForm->hasValue("id") ? $CurrentForm->getValue("id") : $CurrentForm->getValue("x_id");
        if (!$this->id->IsDetailKey) {
            $this->id->setFormValue($val);
        }

        // Check field name 'vaccination_date' first before field var 'x_vaccination_date'
        $val = $CurrentForm->hasValue("vaccination_date") ? $CurrentForm->getValue("vaccination_date") : $CurrentForm->getValue("x_vaccination_date");
        if (!$this->vaccination_date->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->vaccination_date->Visible = false; // Disable update for API request
            } else {
                $this->vaccination_date->setFormValue($val, true, $validate);
            }
            $this->vaccination_date->CurrentValue = UnFormatDateTime($this->vaccination_date->CurrentValue, $this->vaccination_date->formatPattern());
        }

        // Check field name 'child_id' first before field var 'x_child_id'
        $val = $CurrentForm->hasValue("child_id") ? $CurrentForm->getValue("child_id") : $CurrentForm->getValue("x_child_id");
        if (!$this->child_id->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->child_id->Visible = false; // Disable update for API request
            } else {
                $this->child_id->setFormValue($val);
            }
        }

        // Check field name 'vaccine_id' first before field var 'x_vaccine_id'
        $val = $CurrentForm->hasValue("vaccine_id") ? $CurrentForm->getValue("vaccine_id") : $CurrentForm->getValue("x_vaccine_id");
        if (!$this->vaccine_id->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->vaccine_id->Visible = false; // Disable update for API request
            } else {
                $this->vaccine_id->setFormValue($val);
            }
        }

        // Check field name 'dose_cycle' first before field var 'x_dose_cycle'
        $val = $CurrentForm->hasValue("dose_cycle") ? $CurrentForm->getValue("dose_cycle") : $CurrentForm->getValue("x_dose_cycle");
        if (!$this->dose_cycle->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->dose_cycle->Visible = false; // Disable update for API request
            } else {
                $this->dose_cycle->setFormValue($val);
            }
        }

        // Check field name 'next_vaccination_date' first before field var 'x_next_vaccination_date'
        $val = $CurrentForm->hasValue("next_vaccination_date") ? $CurrentForm->getValue("next_vaccination_date") : $CurrentForm->getValue("x_next_vaccination_date");
        if (!$this->next_vaccination_date->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->next_vaccination_date->Visible = false; // Disable update for API request
            } else {
                $this->next_vaccination_date->setFormValue($val, true, $validate);
            }
            $this->next_vaccination_date->CurrentValue = UnFormatDateTime($this->next_vaccination_date->CurrentValue, $this->next_vaccination_date->formatPattern());
        }

        // Check field name 'administered_by' first before field var 'x_administered_by'
        $val = $CurrentForm->hasValue("administered_by") ? $CurrentForm->getValue("administered_by") : $CurrentForm->getValue("x_administered_by");
        if (!$this->administered_by->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->administered_by->Visible = false; // Disable update for API request
            } else {
                $this->administered_by->setFormValue($val);
            }
        }

        // Check field name 'remarks' first before field var 'x_remarks'
        $val = $CurrentForm->hasValue("remarks") ? $CurrentForm->getValue("remarks") : $CurrentForm->getValue("x_remarks");
        if (!$this->remarks->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->remarks->Visible = false; // Disable update for API request
            } else {
                $this->remarks->setFormValue($val);
            }
        }

        // Check field name 'entry_date' first before field var 'x_entry_date'
        $val = $CurrentForm->hasValue("entry_date") ? $CurrentForm->getValue("entry_date") : $CurrentForm->getValue("x_entry_date");
        if (!$this->entry_date->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->entry_date->Visible = false; // Disable update for API request
            } else {
                $this->entry_date->setFormValue($val);
            }
            $this->entry_date->CurrentValue = UnFormatDateTime($this->entry_date->CurrentValue, $this->entry_date->formatPattern());
        }

        // Check field name 'last_modified' first before field var 'x_last_modified'
        $val = $CurrentForm->hasValue("last_modified") ? $CurrentForm->getValue("last_modified") : $CurrentForm->getValue("x_last_modified");
        if (!$this->last_modified->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->last_modified->Visible = false; // Disable update for API request
            } else {
                $this->last_modified->setFormValue($val);
            }
            $this->last_modified->CurrentValue = UnFormatDateTime($this->last_modified->CurrentValue, $this->last_modified->formatPattern());
        }

        // Check field name 'entered_by' first before field var 'x_entered_by'
        $val = $CurrentForm->hasValue("entered_by") ? $CurrentForm->getValue("entered_by") : $CurrentForm->getValue("x_entered_by");
        if (!$this->entered_by->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->entered_by->Visible = false; // Disable update for API request
            } else {
                $this->entered_by->setFormValue($val);
            }
        }

        // Check field name 'modified_by' first before field var 'x_modified_by'
        $val = $CurrentForm->hasValue("modified_by") ? $CurrentForm->getValue("modified_by") : $CurrentForm->getValue("x_modified_by");
        if (!$this->modified_by->IsDetailKey) {
            if (IsApi() && $val === null) {
                $this->modified_by->Visible = false; // Disable update for API request
            } else {
                $this->modified_by->setFormValue($val);
            }
        }
    }

    // Restore form values
    public function restoreFormValues()
    {
        global $CurrentForm;
        $this->id->CurrentValue = $this->id->FormValue;
        $this->vaccination_date->CurrentValue = $this->vaccination_date->FormValue;
        $this->vaccination_date->CurrentValue = UnFormatDateTime($this->vaccination_date->CurrentValue, $this->vaccination_date->formatPattern());
        $this->child_id->CurrentValue = $this->child_id->FormValue;
        $this->vaccine_id->CurrentValue = $this->vaccine_id->FormValue;
        $this->dose_cycle->CurrentValue = $this->dose_cycle->FormValue;
        $this->next_vaccination_date->CurrentValue = $this->next_vaccination_date->FormValue;
        $this->next_vaccination_date->CurrentValue = UnFormatDateTime($this->next_vaccination_date->CurrentValue, $this->next_vaccination_date->formatPattern());
        $this->administered_by->CurrentValue = $this->administered_by->FormValue;
        $this->remarks->CurrentValue = $this->remarks->FormValue;
        $this->entry_date->CurrentValue = $this->entry_date->FormValue;
        $this->entry_date->CurrentValue = UnFormatDateTime($this->entry_date->CurrentValue, $this->entry_date->formatPattern());
        $this->last_modified->CurrentValue = $this->last_modified->FormValue;
        $this->last_modified->CurrentValue = UnFormatDateTime($this->last_modified->CurrentValue, $this->last_modified->formatPattern());
        $this->entered_by->CurrentValue = $this->entered_by->FormValue;
        $this->modified_by->CurrentValue = $this->modified_by->FormValue;
    }

    /**
     * Load row based on key values
     *
     * @return void
     */
    public function loadRow()
    {
        global $Security, $Language;
        $filter = $this->getRecordFilter();

        // Call Row Selecting event
        $this->rowSelecting($filter);

        // Load SQL based on filter
        $this->CurrentFilter = $filter;
        $sql = $this->getCurrentSql();
        $conn = $this->getConnection();
        $res = false;
        $row = $conn->fetchAssociative($sql);
        if ($row) {
            $res = true;
            $this->loadRowValues($row); // Load row values
        }
        return $res;
    }

    /**
     * Load row values from recordset or record
     *
     * @param Recordset|array $rs Record
     * @return void
     */
    public function loadRowValues($rs = null)
    {
        if (is_array($rs)) {
            $row = $rs;
        } elseif ($rs && property_exists($rs, "fields")) { // Recordset
            $row = $rs->fields;
        } else {
            $row = $this->newRow();
        }
        if (!$row) {
            return;
        }

        // Call Row Selected event
        $this->rowSelected($row);
        $this->id->setDbValue($row['id']);
        $this->vaccination_date->setDbValue($row['vaccination_date']);
        $this->child_id->setDbValue($row['child_id']);
        if (array_key_exists('EV__child_id', $row)) {
            $this->child_id->VirtualValue = $row['EV__child_id']; // Set up virtual field value
        } else {
            $this->child_id->VirtualValue = ""; // Clear value
        }
        $this->vaccine_id->setDbValue($row['vaccine_id']);
        if (array_key_exists('EV__vaccine_id', $row)) {
            $this->vaccine_id->VirtualValue = $row['EV__vaccine_id']; // Set up virtual field value
        } else {
            $this->vaccine_id->VirtualValue = ""; // Clear value
        }
        $this->dose_cycle->setDbValue($row['dose_cycle']);
        $this->next_vaccination_date->setDbValue($row['next_vaccination_date']);
        $this->administered_by->setDbValue($row['administered_by']);
        if (array_key_exists('EV__administered_by', $row)) {
            $this->administered_by->VirtualValue = $row['EV__administered_by']; // Set up virtual field value
        } else {
            $this->administered_by->VirtualValue = ""; // Clear value
        }
        $this->remarks->setDbValue($row['remarks']);
        $this->entry_date->setDbValue($row['entry_date']);
        $this->last_modified->setDbValue($row['last_modified']);
        $this->entered_by->setDbValue($row['entered_by']);
        if (array_key_exists('EV__entered_by', $row)) {
            $this->entered_by->VirtualValue = $row['EV__entered_by']; // Set up virtual field value
        } else {
            $this->entered_by->VirtualValue = ""; // Clear value
        }
        $this->modified_by->setDbValue($row['modified_by']);
        if (array_key_exists('EV__modified_by', $row)) {
            $this->modified_by->VirtualValue = $row['EV__modified_by']; // Set up virtual field value
        } else {
            $this->modified_by->VirtualValue = ""; // Clear value
        }
    }

    // Return a row with default values
    protected function newRow()
    {
        $row = [];
        $row['id'] = $this->id->DefaultValue;
        $row['vaccination_date'] = $this->vaccination_date->DefaultValue;
        $row['child_id'] = $this->child_id->DefaultValue;
        $row['vaccine_id'] = $this->vaccine_id->DefaultValue;
        $row['dose_cycle'] = $this->dose_cycle->DefaultValue;
        $row['next_vaccination_date'] = $this->next_vaccination_date->DefaultValue;
        $row['administered_by'] = $this->administered_by->DefaultValue;
        $row['remarks'] = $this->remarks->DefaultValue;
        $row['entry_date'] = $this->entry_date->DefaultValue;
        $row['last_modified'] = $this->last_modified->DefaultValue;
        $row['entered_by'] = $this->entered_by->DefaultValue;
        $row['modified_by'] = $this->modified_by->DefaultValue;
        return $row;
    }

    // Load old record
    protected function loadOldRecord()
    {
        // Load old record
        if ($this->OldKey != "") {
            $this->setKey($this->OldKey);
            $this->CurrentFilter = $this->getRecordFilter();
            $sql = $this->getCurrentSql();
            $conn = $this->getConnection();
            $rs = LoadRecordset($sql, $conn);
            if ($rs && ($row = $rs->fields)) {
                $this->loadRowValues($row); // Load row values
                return $row;
            }
        }
        $this->loadRowValues(); // Load default row values
        return null;
    }

    // Render row values based on field settings
    public function renderRow()
    {
        global $Security, $Language, $CurrentLanguage;

        // Initialize URLs

        // Call Row_Rendering event
        $this->rowRendering();

        // Common render codes for all row types

        // id
        $this->id->RowCssClass = "row";

        // vaccination_date
        $this->vaccination_date->RowCssClass = "row";

        // child_id
        $this->child_id->RowCssClass = "row";

        // vaccine_id
        $this->vaccine_id->RowCssClass = "row";

        // dose_cycle
        $this->dose_cycle->RowCssClass = "row";

        // next_vaccination_date
        $this->next_vaccination_date->RowCssClass = "row";

        // administered_by
        $this->administered_by->RowCssClass = "row";

        // remarks
        $this->remarks->RowCssClass = "row";

        // entry_date
        $this->entry_date->RowCssClass = "row";

        // last_modified
        $this->last_modified->RowCssClass = "row";

        // entered_by
        $this->entered_by->RowCssClass = "row";

        // modified_by
        $this->modified_by->RowCssClass = "row";

        // View row
        if ($this->RowType == ROWTYPE_VIEW) {
            // id
            $this->id->ViewValue = $this->id->CurrentValue;
            $this->id->ViewValue = FormatNumber($this->id->ViewValue, $this->id->formatPattern());

            // vaccination_date
            $this->vaccination_date->ViewValue = $this->vaccination_date->CurrentValue;
            $this->vaccination_date->ViewValue = FormatDateTime($this->vaccination_date->ViewValue, $this->vaccination_date->formatPattern());

            // child_id
            if ($this->child_id->VirtualValue != "") {
                $this->child_id->ViewValue = $this->child_id->VirtualValue;
            } else {
                $this->child_id->ViewValue = $this->child_id->CurrentValue;
                $curVal = strval($this->child_id->CurrentValue);
                if ($curVal != "") {
                    $this->child_id->ViewValue = $this->child_id->lookupCacheOption($curVal);
                    if ($this->child_id->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->child_id->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->child_id->Lookup->renderViewRow($rswrk[0]);
                            $this->child_id->ViewValue = $this->child_id->displayValue($arwrk);
                        } else {
                            $this->child_id->ViewValue = FormatNumber($this->child_id->CurrentValue, $this->child_id->formatPattern());
                        }
                    }
                } else {
                    $this->child_id->ViewValue = null;
                }
            }

            // vaccine_id
            if ($this->vaccine_id->VirtualValue != "") {
                $this->vaccine_id->ViewValue = $this->vaccine_id->VirtualValue;
            } else {
                $this->vaccine_id->ViewValue = $this->vaccine_id->CurrentValue;
                $curVal = strval($this->vaccine_id->CurrentValue);
                if ($curVal != "") {
                    $this->vaccine_id->ViewValue = $this->vaccine_id->lookupCacheOption($curVal);
                    if ($this->vaccine_id->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->vaccine_id->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->vaccine_id->Lookup->renderViewRow($rswrk[0]);
                            $this->vaccine_id->ViewValue = $this->vaccine_id->displayValue($arwrk);
                        } else {
                            $this->vaccine_id->ViewValue = FormatNumber($this->vaccine_id->CurrentValue, $this->vaccine_id->formatPattern());
                        }
                    }
                } else {
                    $this->vaccine_id->ViewValue = null;
                }
            }

            // dose_cycle
            if (strval($this->dose_cycle->CurrentValue) != "") {
                $this->dose_cycle->ViewValue = $this->dose_cycle->optionCaption($this->dose_cycle->CurrentValue);
            } else {
                $this->dose_cycle->ViewValue = null;
            }

            // next_vaccination_date
            $this->next_vaccination_date->ViewValue = $this->next_vaccination_date->CurrentValue;
            $this->next_vaccination_date->ViewValue = FormatDateTime($this->next_vaccination_date->ViewValue, $this->next_vaccination_date->formatPattern());

            // administered_by
            if ($this->administered_by->VirtualValue != "") {
                $this->administered_by->ViewValue = $this->administered_by->VirtualValue;
            } else {
                $curVal = strval($this->administered_by->CurrentValue);
                if ($curVal != "") {
                    $this->administered_by->ViewValue = $this->administered_by->lookupCacheOption($curVal);
                    if ($this->administered_by->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->administered_by->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->administered_by->Lookup->renderViewRow($rswrk[0]);
                            $this->administered_by->ViewValue = $this->administered_by->displayValue($arwrk);
                        } else {
                            $this->administered_by->ViewValue = FormatNumber($this->administered_by->CurrentValue, $this->administered_by->formatPattern());
                        }
                    }
                } else {
                    $this->administered_by->ViewValue = null;
                }
            }

            // remarks
            $this->remarks->ViewValue = $this->remarks->CurrentValue;

            // entry_date
            $this->entry_date->ViewValue = $this->entry_date->CurrentValue;
            $this->entry_date->ViewValue = FormatDateTime($this->entry_date->ViewValue, $this->entry_date->formatPattern());

            // last_modified
            $this->last_modified->ViewValue = $this->last_modified->CurrentValue;
            $this->last_modified->ViewValue = FormatDateTime($this->last_modified->ViewValue, $this->last_modified->formatPattern());

            // entered_by
            if ($this->entered_by->VirtualValue != "") {
                $this->entered_by->ViewValue = $this->entered_by->VirtualValue;
            } else {
                $this->entered_by->ViewValue = $this->entered_by->CurrentValue;
                $curVal = strval($this->entered_by->CurrentValue);
                if ($curVal != "") {
                    $this->entered_by->ViewValue = $this->entered_by->lookupCacheOption($curVal);
                    if ($this->entered_by->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->entered_by->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->entered_by->Lookup->renderViewRow($rswrk[0]);
                            $this->entered_by->ViewValue = $this->entered_by->displayValue($arwrk);
                        } else {
                            $this->entered_by->ViewValue = FormatNumber($this->entered_by->CurrentValue, $this->entered_by->formatPattern());
                        }
                    }
                } else {
                    $this->entered_by->ViewValue = null;
                }
            }

            // modified_by
            if ($this->modified_by->VirtualValue != "") {
                $this->modified_by->ViewValue = $this->modified_by->VirtualValue;
            } else {
                $this->modified_by->ViewValue = $this->modified_by->CurrentValue;
                $curVal = strval($this->modified_by->CurrentValue);
                if ($curVal != "") {
                    $this->modified_by->ViewValue = $this->modified_by->lookupCacheOption($curVal);
                    if ($this->modified_by->ViewValue === null) { // Lookup from database
                        $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                        $sqlWrk = $this->modified_by->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                        $conn = Conn();
                        $config = $conn->getConfiguration();
                        $config->setResultCacheImpl($this->Cache);
                        $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                        $ari = count($rswrk);
                        if ($ari > 0) { // Lookup values found
                            $arwrk = $this->modified_by->Lookup->renderViewRow($rswrk[0]);
                            $this->modified_by->ViewValue = $this->modified_by->displayValue($arwrk);
                        } else {
                            $this->modified_by->ViewValue = FormatNumber($this->modified_by->CurrentValue, $this->modified_by->formatPattern());
                        }
                    }
                } else {
                    $this->modified_by->ViewValue = null;
                }
            }

            // id
            $this->id->HrefValue = "";

            // vaccination_date
            $this->vaccination_date->HrefValue = "";

            // child_id
            $this->child_id->HrefValue = "";

            // vaccine_id
            $this->vaccine_id->HrefValue = "";

            // dose_cycle
            $this->dose_cycle->HrefValue = "";

            // next_vaccination_date
            $this->next_vaccination_date->HrefValue = "";

            // administered_by
            $this->administered_by->HrefValue = "";

            // remarks
            $this->remarks->HrefValue = "";

            // entry_date
            $this->entry_date->HrefValue = "";

            // last_modified
            $this->last_modified->HrefValue = "";

            // entered_by
            $this->entered_by->HrefValue = "";

            // modified_by
            $this->modified_by->HrefValue = "";
        } elseif ($this->RowType == ROWTYPE_EDIT) {
            // id
            $this->id->setupEditAttributes();
            $this->id->EditValue = $this->id->CurrentValue;
            $this->id->EditValue = FormatNumber($this->id->EditValue, $this->id->formatPattern());

            // vaccination_date
            $this->vaccination_date->setupEditAttributes();
            $this->vaccination_date->EditValue = HtmlEncode(FormatDateTime($this->vaccination_date->CurrentValue, $this->vaccination_date->formatPattern()));
            $this->vaccination_date->PlaceHolder = RemoveHtml($this->vaccination_date->title());

            // child_id
            $this->child_id->setupEditAttributes();
            $this->child_id->EditValue = $this->child_id->CurrentValue;
            $curVal = strval($this->child_id->CurrentValue);
            if ($curVal != "") {
                $this->child_id->EditValue = $this->child_id->lookupCacheOption($curVal);
                if ($this->child_id->EditValue === null) { // Lookup from database
                    $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                    $sqlWrk = $this->child_id->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                    $conn = Conn();
                    $config = $conn->getConfiguration();
                    $config->setResultCacheImpl($this->Cache);
                    $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                    $ari = count($rswrk);
                    if ($ari > 0) { // Lookup values found
                        $arwrk = $this->child_id->Lookup->renderViewRow($rswrk[0]);
                        $this->child_id->EditValue = $this->child_id->displayValue($arwrk);
                    } else {
                        $this->child_id->EditValue = HtmlEncode(FormatNumber($this->child_id->CurrentValue, $this->child_id->formatPattern()));
                    }
                }
            } else {
                $this->child_id->EditValue = null;
            }
            $this->child_id->PlaceHolder = RemoveHtml($this->child_id->title());

            // vaccine_id
            $this->vaccine_id->setupEditAttributes();
            $this->vaccine_id->EditValue = $this->vaccine_id->CurrentValue;
            $curVal = strval($this->vaccine_id->CurrentValue);
            if ($curVal != "") {
                $this->vaccine_id->EditValue = $this->vaccine_id->lookupCacheOption($curVal);
                if ($this->vaccine_id->EditValue === null) { // Lookup from database
                    $filterWrk = SearchFilter("`id`", "=", $curVal, DATATYPE_NUMBER, "");
                    $sqlWrk = $this->vaccine_id->Lookup->getSql(false, $filterWrk, '', $this, true, true);
                    $conn = Conn();
                    $config = $conn->getConfiguration();
                    $config->setResultCacheImpl($this->Cache);
                    $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                    $ari = count($rswrk);
                    if ($ari > 0) { // Lookup values found
                        $arwrk = $this->vaccine_id->Lookup->renderViewRow($rswrk[0]);
                        $this->vaccine_id->EditValue = $this->vaccine_id->displayValue($arwrk);
                    } else {
                        $this->vaccine_id->EditValue = HtmlEncode(FormatNumber($this->vaccine_id->CurrentValue, $this->vaccine_id->formatPattern()));
                    }
                }
            } else {
                $this->vaccine_id->EditValue = null;
            }
            $this->vaccine_id->PlaceHolder = RemoveHtml($this->vaccine_id->title());

            // dose_cycle
            $this->dose_cycle->setupEditAttributes();
            $this->dose_cycle->EditValue = $this->dose_cycle->options(true);
            $this->dose_cycle->PlaceHolder = RemoveHtml($this->dose_cycle->title());

            // next_vaccination_date
            $this->next_vaccination_date->setupEditAttributes();
            $this->next_vaccination_date->EditValue = HtmlEncode(FormatDateTime($this->next_vaccination_date->CurrentValue, $this->next_vaccination_date->formatPattern()));
            $this->next_vaccination_date->PlaceHolder = RemoveHtml($this->next_vaccination_date->title());

            // administered_by
            $this->administered_by->setupEditAttributes();
            $curVal = trim(strval($this->administered_by->CurrentValue));
            if ($curVal != "") {
                $this->administered_by->ViewValue = $this->administered_by->lookupCacheOption($curVal);
            } else {
                $this->administered_by->ViewValue = $this->administered_by->Lookup !== null && is_array($this->administered_by->lookupOptions()) && count($this->administered_by->lookupOptions()) > 0 ? $curVal : null;
            }
            if ($this->administered_by->ViewValue !== null) { // Load from cache
                $this->administered_by->EditValue = array_values($this->administered_by->lookupOptions());
            } else { // Lookup from database
                if ($curVal == "") {
                    $filterWrk = "0=1";
                } else {
                    $filterWrk = SearchFilter("`id`", "=", $this->administered_by->CurrentValue, DATATYPE_NUMBER, "");
                }
                $sqlWrk = $this->administered_by->Lookup->getSql(true, $filterWrk, '', $this, false, true);
                $conn = Conn();
                $config = $conn->getConfiguration();
                $config->setResultCacheImpl($this->Cache);
                $rswrk = $conn->executeCacheQuery($sqlWrk, [], [], $this->CacheProfile)->fetchAll();
                $ari = count($rswrk);
                $arwrk = $rswrk;
                $this->administered_by->EditValue = $arwrk;
            }
            $this->administered_by->PlaceHolder = RemoveHtml($this->administered_by->title());

            // remarks
            $this->remarks->setupEditAttributes();
            $this->remarks->EditValue = HtmlEncode($this->remarks->CurrentValue);
            $this->remarks->PlaceHolder = RemoveHtml($this->remarks->title());

            // entry_date

            // last_modified

            // entered_by

            // modified_by

            // Edit refer script

            // id
            $this->id->HrefValue = "";

            // vaccination_date
            $this->vaccination_date->HrefValue = "";

            // child_id
            $this->child_id->HrefValue = "";

            // vaccine_id
            $this->vaccine_id->HrefValue = "";

            // dose_cycle
            $this->dose_cycle->HrefValue = "";

            // next_vaccination_date
            $this->next_vaccination_date->HrefValue = "";

            // administered_by
            $this->administered_by->HrefValue = "";

            // remarks
            $this->remarks->HrefValue = "";

            // entry_date
            $this->entry_date->HrefValue = "";

            // last_modified
            $this->last_modified->HrefValue = "";

            // entered_by
            $this->entered_by->HrefValue = "";

            // modified_by
            $this->modified_by->HrefValue = "";
        }
        if ($this->RowType == ROWTYPE_ADD || $this->RowType == ROWTYPE_EDIT || $this->RowType == ROWTYPE_SEARCH) { // Add/Edit/Search row
            $this->setupFieldTitles();
        }

        // Call Row Rendered event
        if ($this->RowType != ROWTYPE_AGGREGATEINIT) {
            $this->rowRendered();
        }
    }

    // Validate form
    protected function validateForm()
    {
        global $Language, $Security;

        // Check if validation required
        if (!Config("SERVER_VALIDATE")) {
            return true;
        }
        $validateForm = true;
        if ($this->id->Visible && $this->id->Required) {
            if (!$this->id->IsDetailKey && EmptyValue($this->id->FormValue)) {
                $this->id->addErrorMessage(str_replace("%s", $this->id->caption(), $this->id->RequiredErrorMessage));
            }
        }
        if ($this->vaccination_date->Visible && $this->vaccination_date->Required) {
            if (!$this->vaccination_date->IsDetailKey && EmptyValue($this->vaccination_date->FormValue)) {
                $this->vaccination_date->addErrorMessage(str_replace("%s", $this->vaccination_date->caption(), $this->vaccination_date->RequiredErrorMessage));
            }
        }
        if (!CheckDate($this->vaccination_date->FormValue, $this->vaccination_date->formatPattern())) {
            $this->vaccination_date->addErrorMessage($this->vaccination_date->getErrorMessage(false));
        }
        if ($this->child_id->Visible && $this->child_id->Required) {
            if (!$this->child_id->IsDetailKey && EmptyValue($this->child_id->FormValue)) {
                $this->child_id->addErrorMessage(str_replace("%s", $this->child_id->caption(), $this->child_id->RequiredErrorMessage));
            }
        }
        if ($this->vaccine_id->Visible && $this->vaccine_id->Required) {
            if (!$this->vaccine_id->IsDetailKey && EmptyValue($this->vaccine_id->FormValue)) {
                $this->vaccine_id->addErrorMessage(str_replace("%s", $this->vaccine_id->caption(), $this->vaccine_id->RequiredErrorMessage));
            }
        }
        if ($this->dose_cycle->Visible && $this->dose_cycle->Required) {
            if (!$this->dose_cycle->IsDetailKey && EmptyValue($this->dose_cycle->FormValue)) {
                $this->dose_cycle->addErrorMessage(str_replace("%s", $this->dose_cycle->caption(), $this->dose_cycle->RequiredErrorMessage));
            }
        }
        if ($this->next_vaccination_date->Visible && $this->next_vaccination_date->Required) {
            if (!$this->next_vaccination_date->IsDetailKey && EmptyValue($this->next_vaccination_date->FormValue)) {
                $this->next_vaccination_date->addErrorMessage(str_replace("%s", $this->next_vaccination_date->caption(), $this->next_vaccination_date->RequiredErrorMessage));
            }
        }
        if (!CheckDate($this->next_vaccination_date->FormValue, $this->next_vaccination_date->formatPattern())) {
            $this->next_vaccination_date->addErrorMessage($this->next_vaccination_date->getErrorMessage(false));
        }
        if ($this->administered_by->Visible && $this->administered_by->Required) {
            if (!$this->administered_by->IsDetailKey && EmptyValue($this->administered_by->FormValue)) {
                $this->administered_by->addErrorMessage(str_replace("%s", $this->administered_by->caption(), $this->administered_by->RequiredErrorMessage));
            }
        }
        if ($this->remarks->Visible && $this->remarks->Required) {
            if (!$this->remarks->IsDetailKey && EmptyValue($this->remarks->FormValue)) {
                $this->remarks->addErrorMessage(str_replace("%s", $this->remarks->caption(), $this->remarks->RequiredErrorMessage));
            }
        }
        if ($this->entry_date->Visible && $this->entry_date->Required) {
            if (!$this->entry_date->IsDetailKey && EmptyValue($this->entry_date->FormValue)) {
                $this->entry_date->addErrorMessage(str_replace("%s", $this->entry_date->caption(), $this->entry_date->RequiredErrorMessage));
            }
        }
        if ($this->last_modified->Visible && $this->last_modified->Required) {
            if (!$this->last_modified->IsDetailKey && EmptyValue($this->last_modified->FormValue)) {
                $this->last_modified->addErrorMessage(str_replace("%s", $this->last_modified->caption(), $this->last_modified->RequiredErrorMessage));
            }
        }
        if ($this->entered_by->Visible && $this->entered_by->Required) {
            if (!$this->entered_by->IsDetailKey && EmptyValue($this->entered_by->FormValue)) {
                $this->entered_by->addErrorMessage(str_replace("%s", $this->entered_by->caption(), $this->entered_by->RequiredErrorMessage));
            }
        }
        if ($this->modified_by->Visible && $this->modified_by->Required) {
            if (!$this->modified_by->IsDetailKey && EmptyValue($this->modified_by->FormValue)) {
                $this->modified_by->addErrorMessage(str_replace("%s", $this->modified_by->caption(), $this->modified_by->RequiredErrorMessage));
            }
        }

        // Return validate result
        $validateForm = $validateForm && !$this->hasInvalidFields();

        // Call Form_CustomValidate event
        $formCustomError = "";
        $validateForm = $validateForm && $this->formCustomValidate($formCustomError);
        if ($formCustomError != "") {
            $this->setFailureMessage($formCustomError);
        }
        return $validateForm;
    }

    // Update record based on key values
    protected function editRow()
    {
        global $Security, $Language;
        $oldKeyFilter = $this->getRecordFilter();
        $filter = $this->applyUserIDFilters($oldKeyFilter);
        $conn = $this->getConnection();

        // Load old row
        $this->CurrentFilter = $filter;
        $sql = $this->getCurrentSql();
        $rsold = $conn->fetchAssociative($sql);
        if (!$rsold) {
            $this->setFailureMessage($Language->phrase("NoRecord")); // Set no record message
            return false; // Update Failed
        } else {
            // Save old values
            $this->loadDbValues($rsold);
        }

        // Set new row
        $rsnew = [];

        // vaccination_date
        $this->vaccination_date->setDbValueDef($rsnew, UnFormatDateTime($this->vaccination_date->CurrentValue, $this->vaccination_date->formatPattern()), $this->vaccination_date->ReadOnly);

        // child_id
        $this->child_id->setDbValueDef($rsnew, $this->child_id->CurrentValue, $this->child_id->ReadOnly);

        // vaccine_id
        $this->vaccine_id->setDbValueDef($rsnew, $this->vaccine_id->CurrentValue, $this->vaccine_id->ReadOnly);

        // dose_cycle
        $this->dose_cycle->setDbValueDef($rsnew, $this->dose_cycle->CurrentValue, $this->dose_cycle->ReadOnly);

        // next_vaccination_date
        $this->next_vaccination_date->setDbValueDef($rsnew, UnFormatDateTime($this->next_vaccination_date->CurrentValue, $this->next_vaccination_date->formatPattern()), $this->next_vaccination_date->ReadOnly);

        // administered_by
        $this->administered_by->setDbValueDef($rsnew, $this->administered_by->CurrentValue, $this->administered_by->ReadOnly);

        // remarks
        $this->remarks->setDbValueDef($rsnew, $this->remarks->CurrentValue, $this->remarks->ReadOnly);

        // entry_date
        $this->entry_date->CurrentValue = $this->entry_date->getAutoUpdateValue(); // PHP
        $this->entry_date->setDbValueDef($rsnew, $this->entry_date->CurrentValue);

        // last_modified
        $this->last_modified->CurrentValue = $this->last_modified->getAutoUpdateValue(); // PHP
        $this->last_modified->setDbValueDef($rsnew, $this->last_modified->CurrentValue);

        // entered_by
        $this->entered_by->CurrentValue = $this->entered_by->getAutoUpdateValue(); // PHP
        $this->entered_by->setDbValueDef($rsnew, $this->entered_by->CurrentValue);

        // modified_by
        $this->modified_by->CurrentValue = $this->modified_by->getAutoUpdateValue(); // PHP
        $this->modified_by->setDbValueDef($rsnew, $this->modified_by->CurrentValue);

        // Update current values
        $this->setCurrentValues($rsnew);

        // Call Row Updating event
        $updateRow = $this->rowUpdating($rsold, $rsnew);
        if ($updateRow) {
            if (count($rsnew) > 0) {
                $this->CurrentFilter = $filter; // Set up current filter
                $editRow = $this->update($rsnew, "", $rsold);
                if (!$editRow && !EmptyValue($this->DbErrorMessage)) { // Show database error
                    $this->setFailureMessage($this->DbErrorMessage);
                }
            } else {
                $editRow = true; // No field to update
            }
            if ($editRow) {
            }
        } else {
            if ($this->getSuccessMessage() != "" || $this->getFailureMessage() != "") {
                // Use the message, do nothing
            } elseif ($this->CancelMessage != "") {
                $this->setFailureMessage($this->CancelMessage);
                $this->CancelMessage = "";
            } else {
                $this->setFailureMessage($Language->phrase("UpdateCancelled"));
            }
            $editRow = false;
        }

        // Call Row_Updated event
        if ($editRow) {
            $this->rowUpdated($rsold, $rsnew);
        }

        // Write JSON response
        if (IsJsonResponse() && $editRow) {
            $row = $this->getRecordsFromRecordset([$rsnew], true);
            $table = $this->TableVar;
            WriteJson(["success" => true, "action" => Config("API_EDIT_ACTION"), $table => $row]);
        }
        return $editRow;
    }

    // Set up Breadcrumb
    protected function setupBreadcrumb()
    {
        global $Breadcrumb, $Language;
        $Breadcrumb = new Breadcrumb("index");
        $url = CurrentUrl();
        $Breadcrumb->add("list", $this->TableVar, $this->addMasterUrl("tbimmunisationlist"), "", $this->TableVar, true);
        $pageId = "edit";
        $Breadcrumb->add("edit", $pageId, $url);
    }

    // Setup lookup options
    public function setupLookupOptions($fld)
    {
        if ($fld->Lookup !== null && $fld->Lookup->Options === null) {
            // Get default connection and filter
            $conn = $this->getConnection();
            $lookupFilter = "";

            // No need to check any more
            $fld->Lookup->Options = [];

            // Set up lookup SQL and connection
            switch ($fld->FieldVar) {
                case "x_child_id":
                    break;
                case "x_vaccine_id":
                    break;
                case "x_dose_cycle":
                    break;
                case "x_administered_by":
                    break;
                case "x_entered_by":
                    break;
                case "x_modified_by":
                    break;
                default:
                    $lookupFilter = "";
                    break;
            }

            // Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
            $sql = $fld->Lookup->getSql(false, "", $lookupFilter, $this);

            // Set up lookup cache
            if (!$fld->hasLookupOptions() && $fld->UseLookupCache && $sql != "" && count($fld->Lookup->Options) == 0 && count($fld->Lookup->FilterFields) == 0) {
                $totalCnt = $this->getRecordCount($sql, $conn);
                if ($totalCnt > $fld->LookupCacheCount) { // Total count > cache count, do not cache
                    return;
                }
                $rows = $conn->executeQuery($sql)->fetchAll();
                $ar = [];
                foreach ($rows as $row) {
                    $row = $fld->Lookup->renderViewRow($row, Container($fld->Lookup->LinkTable));
                    $key = $row["lf"];
                    if (IsFloatType($fld->Type)) { // Handle float field
                        $key = (float)$key;
                    }
                    $ar[strval($key)] = $row;
                }
                $fld->Lookup->Options = $ar;
            }
        }
    }

    // Set up starting record parameters
    public function setupStartRecord()
    {
        if ($this->DisplayRecords == 0) {
            return;
        }
        $pageNo = Get(Config("TABLE_PAGE_NUMBER"));
        $startRec = Get(Config("TABLE_START_REC"));
        $infiniteScroll = false;
        $recordNo = $pageNo ?? $startRec; // Record number = page number or start record
        if ($recordNo !== null && is_numeric($recordNo)) {
            $this->StartRecord = $recordNo;
        } else {
            $this->StartRecord = $this->getStartRecordNumber();
        }

        // Check if correct start record counter
        if (!is_numeric($this->StartRecord) || intval($this->StartRecord) <= 0) { // Avoid invalid start record counter
            $this->StartRecord = 1; // Reset start record counter
        } elseif ($this->StartRecord > $this->TotalRecords) { // Avoid starting record > total records
            $this->StartRecord = (int)(($this->TotalRecords - 1) / $this->DisplayRecords) * $this->DisplayRecords + 1; // Point to last page first record
        } elseif (($this->StartRecord - 1) % $this->DisplayRecords != 0) {
            $this->StartRecord = (int)(($this->StartRecord - 1) / $this->DisplayRecords) * $this->DisplayRecords + 1; // Point to page boundary
        }
        if (!$infiniteScroll) {
            $this->setStartRecordNumber($this->StartRecord);
        }
    }

    // Get page count
    public function pageCount() {
        return ceil($this->TotalRecords / $this->DisplayRecords);
    }

    // Page Load event
    public function pageLoad()
    {
        //Log("Page Load");
    	$GLOBALS["Language"]->setPhrase("edit", "Change Details"); 
    	$GLOBALS["Language"]->setPhrase("savebtn", "<i class='fa fa-check fa-1x'></i> Save and Apply");  
    	$GLOBALS["Language"]->setPhrase("cancelbtn", "<i class='fa fa-close fa-1x'></i> Cancel Transaction");
    	$GLOBALS["Language"]->setPhrase("updatesuccess", "Transaction Completed Successfully.");    
    }

    // Page Unload event
    public function pageUnload()
    {
        //Log("Page Unload");
    }

    // Page Redirecting event
    public function pageRedirecting(&$url)
    {
        // Example:
        //$url = "your URL";
    }

    // Message Showing event
    // $type = ''|'success'|'failure'|'warning'
    public function messageShowing(&$msg, $type)
    {
        if ($type == 'success') {
            //$msg = "your success message";
        } elseif ($type == 'failure') {
            //$msg = "your failure message";
        } elseif ($type == 'warning') {
            //$msg = "your warning message";
        } else {
            //$msg = "your message";
        }
    }

    // Page Render event
    public function pageRender()
    {
        //Log("Page Render");
    }

    // Page Data Rendering event
    public function pageDataRendering(&$header)
    {
        // Example:
        //$header = "your header";

        //Warning about mandatory fields
        $header .= '<div class="callout callout-warning rounded-0 py-1" style="font-size: 13px; color: #c23321 !important; border-color: #c23321;background-color: #fff3cd !important;">';
        $header .= 'All Form Fields Marked With an Asterisk (*) are Mandatory.';
    	$header .= '</div>';  
    }

    // Page Data Rendered event
    public function pageDataRendered(&$footer)
    {
        // Example:
        //$footer = "your footer";
    }

    // Page Breaking event
    public function pageBreaking(&$break, &$content)
    {
        // Example:
        //$break = false; // Skip page break, or
        //$content = "<div style=\"break-after:page;\"></div>"; // Modify page break content
    }

    // Form Custom Validate event
    public function formCustomValidate(&$customError)
    {
        // Return error message in $customError
        return true;
    }
}
