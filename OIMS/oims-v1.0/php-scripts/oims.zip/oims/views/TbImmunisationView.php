<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbImmunisationView = &$Page;
?>
<?php if (!$Page->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $Page->ExportOptions->render("body") ?>
<?php $Page->OtherOptions->render("body") ?>
</div>
<?php } ?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="view">
<form name="ftb_immunisationview" id="ftb_immunisationview" class="ew-form ew-view-form overlay-wrapper" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (!$Page->isExport()) { ?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_immunisation: currentTable } });
var currentPageID = ew.PAGE_ID = "view";
var currentForm;
var ftb_immunisationview;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_immunisationview")
        .setPageId("view")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php } ?>
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_immunisation">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<table class="<?= $Page->TableClass ?>">
<?php if ($Page->id->Visible) { // id ?>
    <tr id="r_id"<?= $Page->id->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_id"><?= $Page->id->caption() ?></span></td>
        <td data-name="id"<?= $Page->id->cellAttributes() ?>>
<span id="el_tb_immunisation_id">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->vaccination_date->Visible) { // vaccination_date ?>
    <tr id="r_vaccination_date"<?= $Page->vaccination_date->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_vaccination_date"><?= $Page->vaccination_date->caption() ?></span></td>
        <td data-name="vaccination_date"<?= $Page->vaccination_date->cellAttributes() ?>>
<span id="el_tb_immunisation_vaccination_date">
<span<?= $Page->vaccination_date->viewAttributes() ?>>
<?= $Page->vaccination_date->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->child_id->Visible) { // child_id ?>
    <tr id="r_child_id"<?= $Page->child_id->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_child_id"><?= $Page->child_id->caption() ?></span></td>
        <td data-name="child_id"<?= $Page->child_id->cellAttributes() ?>>
<span id="el_tb_immunisation_child_id">
<span<?= $Page->child_id->viewAttributes() ?>>
<?= $Page->child_id->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->vaccine_id->Visible) { // vaccine_id ?>
    <tr id="r_vaccine_id"<?= $Page->vaccine_id->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_vaccine_id"><?= $Page->vaccine_id->caption() ?></span></td>
        <td data-name="vaccine_id"<?= $Page->vaccine_id->cellAttributes() ?>>
<span id="el_tb_immunisation_vaccine_id">
<span<?= $Page->vaccine_id->viewAttributes() ?>>
<?= $Page->vaccine_id->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->dose_cycle->Visible) { // dose_cycle ?>
    <tr id="r_dose_cycle"<?= $Page->dose_cycle->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_dose_cycle"><?= $Page->dose_cycle->caption() ?></span></td>
        <td data-name="dose_cycle"<?= $Page->dose_cycle->cellAttributes() ?>>
<span id="el_tb_immunisation_dose_cycle">
<span<?= $Page->dose_cycle->viewAttributes() ?>>
<?= $Page->dose_cycle->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->next_vaccination_date->Visible) { // next_vaccination_date ?>
    <tr id="r_next_vaccination_date"<?= $Page->next_vaccination_date->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_next_vaccination_date"><?= $Page->next_vaccination_date->caption() ?></span></td>
        <td data-name="next_vaccination_date"<?= $Page->next_vaccination_date->cellAttributes() ?>>
<span id="el_tb_immunisation_next_vaccination_date">
<span<?= $Page->next_vaccination_date->viewAttributes() ?>>
<?= $Page->next_vaccination_date->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->administered_by->Visible) { // administered_by ?>
    <tr id="r_administered_by"<?= $Page->administered_by->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_administered_by"><?= $Page->administered_by->caption() ?></span></td>
        <td data-name="administered_by"<?= $Page->administered_by->cellAttributes() ?>>
<span id="el_tb_immunisation_administered_by">
<span<?= $Page->administered_by->viewAttributes() ?>>
<?= $Page->administered_by->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->remarks->Visible) { // remarks ?>
    <tr id="r_remarks"<?= $Page->remarks->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_remarks"><?= $Page->remarks->caption() ?></span></td>
        <td data-name="remarks"<?= $Page->remarks->cellAttributes() ?>>
<span id="el_tb_immunisation_remarks">
<span<?= $Page->remarks->viewAttributes() ?>>
<?= $Page->remarks->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
    <tr id="r_entry_date"<?= $Page->entry_date->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_entry_date"><?= $Page->entry_date->caption() ?></span></td>
        <td data-name="entry_date"<?= $Page->entry_date->cellAttributes() ?>>
<span id="el_tb_immunisation_entry_date">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
    <tr id="r_last_modified"<?= $Page->last_modified->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_last_modified"><?= $Page->last_modified->caption() ?></span></td>
        <td data-name="last_modified"<?= $Page->last_modified->cellAttributes() ?>>
<span id="el_tb_immunisation_last_modified">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
    <tr id="r_entered_by"<?= $Page->entered_by->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_entered_by"><?= $Page->entered_by->caption() ?></span></td>
        <td data-name="entered_by"<?= $Page->entered_by->cellAttributes() ?>>
<span id="el_tb_immunisation_entered_by">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
    <tr id="r_modified_by"<?= $Page->modified_by->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_immunisation_modified_by"><?= $Page->modified_by->caption() ?></span></td>
        <td data-name="modified_by"<?= $Page->modified_by->cellAttributes() ?>>
<span id="el_tb_immunisation_modified_by">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
</table>
</form>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<?php if (!$Page->isExport()) { ?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
<?php } ?>
