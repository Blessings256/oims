<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbEmployeeAdd = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_employee: currentTable } });
var currentPageID = ew.PAGE_ID = "add";
var currentForm;
var ftb_employeeadd;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_employeeadd")
        .setPageId("add")

        // Add fields
        .setFields([
            ["employee_number", [fields.employee_number.visible && fields.employee_number.required ? ew.Validators.required(fields.employee_number.caption) : null], fields.employee_number.isInvalid],
            ["first_name", [fields.first_name.visible && fields.first_name.required ? ew.Validators.required(fields.first_name.caption) : null], fields.first_name.isInvalid],
            ["last_name", [fields.last_name.visible && fields.last_name.required ? ew.Validators.required(fields.last_name.caption) : null], fields.last_name.isInvalid],
            ["other_name", [fields.other_name.visible && fields.other_name.required ? ew.Validators.required(fields.other_name.caption) : null], fields.other_name.isInvalid],
            ["job_tile", [fields.job_tile.visible && fields.job_tile.required ? ew.Validators.required(fields.job_tile.caption) : null], fields.job_tile.isInvalid],
            ["pri_phone_no", [fields.pri_phone_no.visible && fields.pri_phone_no.required ? ew.Validators.required(fields.pri_phone_no.caption) : null], fields.pri_phone_no.isInvalid],
            ["alt_phone_no", [fields.alt_phone_no.visible && fields.alt_phone_no.required ? ew.Validators.required(fields.alt_phone_no.caption) : null], fields.alt_phone_no.isInvalid],
            ["personal_email", [fields.personal_email.visible && fields.personal_email.required ? ew.Validators.required(fields.personal_email.caption) : null], fields.personal_email.isInvalid],
            ["official_email", [fields.official_email.visible && fields.official_email.required ? ew.Validators.required(fields.official_email.caption) : null], fields.official_email.isInvalid],
            ["department", [fields.department.visible && fields.department.required ? ew.Validators.required(fields.department.caption) : null], fields.department.isInvalid],
            ["hire_date", [fields.hire_date.visible && fields.hire_date.required ? ew.Validators.required(fields.hire_date.caption) : null, ew.Validators.datetime(fields.hire_date.clientFormatPattern)], fields.hire_date.isInvalid],
            ["current_status", [fields.current_status.visible && fields.current_status.required ? ew.Validators.required(fields.current_status.caption) : null], fields.current_status.isInvalid],
            ["tin_number", [fields.tin_number.visible && fields.tin_number.required ? ew.Validators.required(fields.tin_number.caption) : null], fields.tin_number.isInvalid],
            ["nssf_number", [fields.nssf_number.visible && fields.nssf_number.required ? ew.Validators.required(fields.nssf_number.caption) : null], fields.nssf_number.isInvalid],
            ["salary_amount", [fields.salary_amount.visible && fields.salary_amount.required ? ew.Validators.required(fields.salary_amount.caption) : null, ew.Validators.float], fields.salary_amount.isInvalid],
            ["employement_type", [fields.employement_type.visible && fields.employement_type.required ? ew.Validators.required(fields.employement_type.caption) : null], fields.employement_type.isInvalid],
            ["work_schedule", [fields.work_schedule.visible && fields.work_schedule.required ? ew.Validators.required(fields.work_schedule.caption) : null], fields.work_schedule.isInvalid],
            ["sex", [fields.sex.visible && fields.sex.required ? ew.Validators.required(fields.sex.caption) : null], fields.sex.isInvalid],
            ["entry_date", [fields.entry_date.visible && fields.entry_date.required ? ew.Validators.required(fields.entry_date.caption) : null], fields.entry_date.isInvalid],
            ["last_modified", [fields.last_modified.visible && fields.last_modified.required ? ew.Validators.required(fields.last_modified.caption) : null], fields.last_modified.isInvalid],
            ["entered_by", [fields.entered_by.visible && fields.entered_by.required ? ew.Validators.required(fields.entered_by.caption) : null], fields.entered_by.isInvalid],
            ["modified_by", [fields.modified_by.visible && fields.modified_by.required ? ew.Validators.required(fields.modified_by.caption) : null], fields.modified_by.isInvalid]
        ])

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "current_status": <?= $Page->current_status->toClientList($Page) ?>,
            "employement_type": <?= $Page->employement_type->toClientList($Page) ?>,
            "work_schedule": <?= $Page->work_schedule->toClientList($Page) ?>,
            "sex": <?= $Page->sex->toClientList($Page) ?>,
            "entered_by": <?= $Page->entered_by->toClientList($Page) ?>,
            "modified_by": <?= $Page->modified_by->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_employeeadd" id="ftb_employeeadd" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_employee">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<?php if (IsJsonResponse()) { ?>
<input type="hidden" name="json" value="1">
<?php } ?>
<input type="hidden" name="<?= $Page->OldKeyName ?>" value="<?= $Page->OldKey ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($Page->employee_number->Visible) { // employee_number ?>
    <div id="r_employee_number"<?= $Page->employee_number->rowAttributes() ?>>
        <label id="elh_tb_employee_employee_number" for="x_employee_number" class="<?= $Page->LeftColumnClass ?>"><?= $Page->employee_number->caption() ?><?= $Page->employee_number->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->employee_number->cellAttributes() ?>>
<span id="el_tb_employee_employee_number">
<input type="<?= $Page->employee_number->getInputTextType() ?>" name="x_employee_number" id="x_employee_number" data-table="tb_employee" data-field="x_employee_number" value="<?= $Page->employee_number->EditValue ?>" size="30" maxlength="30" placeholder="<?= HtmlEncode($Page->employee_number->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->employee_number->formatPattern()) ?>"<?= $Page->employee_number->editAttributes() ?> aria-describedby="x_employee_number_help">
<?= $Page->employee_number->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->employee_number->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->first_name->Visible) { // first_name ?>
    <div id="r_first_name"<?= $Page->first_name->rowAttributes() ?>>
        <label id="elh_tb_employee_first_name" for="x_first_name" class="<?= $Page->LeftColumnClass ?>"><?= $Page->first_name->caption() ?><?= $Page->first_name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->first_name->cellAttributes() ?>>
<span id="el_tb_employee_first_name">
<input type="<?= $Page->first_name->getInputTextType() ?>" name="x_first_name" id="x_first_name" data-table="tb_employee" data-field="x_first_name" value="<?= $Page->first_name->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->first_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->first_name->formatPattern()) ?>"<?= $Page->first_name->editAttributes() ?> aria-describedby="x_first_name_help">
<?= $Page->first_name->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->first_name->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->last_name->Visible) { // last_name ?>
    <div id="r_last_name"<?= $Page->last_name->rowAttributes() ?>>
        <label id="elh_tb_employee_last_name" for="x_last_name" class="<?= $Page->LeftColumnClass ?>"><?= $Page->last_name->caption() ?><?= $Page->last_name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->last_name->cellAttributes() ?>>
<span id="el_tb_employee_last_name">
<input type="<?= $Page->last_name->getInputTextType() ?>" name="x_last_name" id="x_last_name" data-table="tb_employee" data-field="x_last_name" value="<?= $Page->last_name->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->last_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->last_name->formatPattern()) ?>"<?= $Page->last_name->editAttributes() ?> aria-describedby="x_last_name_help">
<?= $Page->last_name->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->last_name->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->other_name->Visible) { // other_name ?>
    <div id="r_other_name"<?= $Page->other_name->rowAttributes() ?>>
        <label id="elh_tb_employee_other_name" for="x_other_name" class="<?= $Page->LeftColumnClass ?>"><?= $Page->other_name->caption() ?><?= $Page->other_name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->other_name->cellAttributes() ?>>
<span id="el_tb_employee_other_name">
<input type="<?= $Page->other_name->getInputTextType() ?>" name="x_other_name" id="x_other_name" data-table="tb_employee" data-field="x_other_name" value="<?= $Page->other_name->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->other_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->other_name->formatPattern()) ?>"<?= $Page->other_name->editAttributes() ?> aria-describedby="x_other_name_help">
<?= $Page->other_name->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->other_name->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->job_tile->Visible) { // job_tile ?>
    <div id="r_job_tile"<?= $Page->job_tile->rowAttributes() ?>>
        <label id="elh_tb_employee_job_tile" for="x_job_tile" class="<?= $Page->LeftColumnClass ?>"><?= $Page->job_tile->caption() ?><?= $Page->job_tile->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->job_tile->cellAttributes() ?>>
<span id="el_tb_employee_job_tile">
<input type="<?= $Page->job_tile->getInputTextType() ?>" name="x_job_tile" id="x_job_tile" data-table="tb_employee" data-field="x_job_tile" value="<?= $Page->job_tile->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->job_tile->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->job_tile->formatPattern()) ?>"<?= $Page->job_tile->editAttributes() ?> aria-describedby="x_job_tile_help">
<?= $Page->job_tile->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->job_tile->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->pri_phone_no->Visible) { // pri_phone_no ?>
    <div id="r_pri_phone_no"<?= $Page->pri_phone_no->rowAttributes() ?>>
        <label id="elh_tb_employee_pri_phone_no" for="x_pri_phone_no" class="<?= $Page->LeftColumnClass ?>"><?= $Page->pri_phone_no->caption() ?><?= $Page->pri_phone_no->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->pri_phone_no->cellAttributes() ?>>
<span id="el_tb_employee_pri_phone_no">
<input type="<?= $Page->pri_phone_no->getInputTextType() ?>" name="x_pri_phone_no" id="x_pri_phone_no" data-table="tb_employee" data-field="x_pri_phone_no" value="<?= $Page->pri_phone_no->EditValue ?>" size="30" maxlength="25" placeholder="<?= HtmlEncode($Page->pri_phone_no->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->pri_phone_no->formatPattern()) ?>"<?= $Page->pri_phone_no->editAttributes() ?> aria-describedby="x_pri_phone_no_help">
<?= $Page->pri_phone_no->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->pri_phone_no->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->alt_phone_no->Visible) { // alt_phone_no ?>
    <div id="r_alt_phone_no"<?= $Page->alt_phone_no->rowAttributes() ?>>
        <label id="elh_tb_employee_alt_phone_no" for="x_alt_phone_no" class="<?= $Page->LeftColumnClass ?>"><?= $Page->alt_phone_no->caption() ?><?= $Page->alt_phone_no->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->alt_phone_no->cellAttributes() ?>>
<span id="el_tb_employee_alt_phone_no">
<input type="<?= $Page->alt_phone_no->getInputTextType() ?>" name="x_alt_phone_no" id="x_alt_phone_no" data-table="tb_employee" data-field="x_alt_phone_no" value="<?= $Page->alt_phone_no->EditValue ?>" size="30" maxlength="25" placeholder="<?= HtmlEncode($Page->alt_phone_no->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->alt_phone_no->formatPattern()) ?>"<?= $Page->alt_phone_no->editAttributes() ?> aria-describedby="x_alt_phone_no_help">
<?= $Page->alt_phone_no->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->alt_phone_no->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->personal_email->Visible) { // personal_email ?>
    <div id="r_personal_email"<?= $Page->personal_email->rowAttributes() ?>>
        <label id="elh_tb_employee_personal_email" for="x_personal_email" class="<?= $Page->LeftColumnClass ?>"><?= $Page->personal_email->caption() ?><?= $Page->personal_email->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->personal_email->cellAttributes() ?>>
<span id="el_tb_employee_personal_email">
<input type="<?= $Page->personal_email->getInputTextType() ?>" name="x_personal_email" id="x_personal_email" data-table="tb_employee" data-field="x_personal_email" value="<?= $Page->personal_email->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->personal_email->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->personal_email->formatPattern()) ?>"<?= $Page->personal_email->editAttributes() ?> aria-describedby="x_personal_email_help">
<?= $Page->personal_email->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->personal_email->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->official_email->Visible) { // official_email ?>
    <div id="r_official_email"<?= $Page->official_email->rowAttributes() ?>>
        <label id="elh_tb_employee_official_email" for="x_official_email" class="<?= $Page->LeftColumnClass ?>"><?= $Page->official_email->caption() ?><?= $Page->official_email->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->official_email->cellAttributes() ?>>
<span id="el_tb_employee_official_email">
<input type="<?= $Page->official_email->getInputTextType() ?>" name="x_official_email" id="x_official_email" data-table="tb_employee" data-field="x_official_email" value="<?= $Page->official_email->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->official_email->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->official_email->formatPattern()) ?>"<?= $Page->official_email->editAttributes() ?> aria-describedby="x_official_email_help">
<?= $Page->official_email->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->official_email->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->department->Visible) { // department ?>
    <div id="r_department"<?= $Page->department->rowAttributes() ?>>
        <label id="elh_tb_employee_department" for="x_department" class="<?= $Page->LeftColumnClass ?>"><?= $Page->department->caption() ?><?= $Page->department->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->department->cellAttributes() ?>>
<span id="el_tb_employee_department">
<input type="<?= $Page->department->getInputTextType() ?>" name="x_department" id="x_department" data-table="tb_employee" data-field="x_department" value="<?= $Page->department->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->department->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->department->formatPattern()) ?>"<?= $Page->department->editAttributes() ?> aria-describedby="x_department_help">
<?= $Page->department->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->department->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->hire_date->Visible) { // hire_date ?>
    <div id="r_hire_date"<?= $Page->hire_date->rowAttributes() ?>>
        <label id="elh_tb_employee_hire_date" for="x_hire_date" class="<?= $Page->LeftColumnClass ?>"><?= $Page->hire_date->caption() ?><?= $Page->hire_date->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->hire_date->cellAttributes() ?>>
<span id="el_tb_employee_hire_date">
<input type="<?= $Page->hire_date->getInputTextType() ?>" name="x_hire_date" id="x_hire_date" data-table="tb_employee" data-field="x_hire_date" value="<?= $Page->hire_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->hire_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->hire_date->formatPattern()) ?>"<?= $Page->hire_date->editAttributes() ?> aria-describedby="x_hire_date_help">
<?= $Page->hire_date->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->hire_date->getErrorMessage() ?></div>
<?php if (!$Page->hire_date->ReadOnly && !$Page->hire_date->Disabled && !isset($Page->hire_date->EditAttrs["readonly"]) && !isset($Page->hire_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_employeeadd", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_employeeadd", "x_hire_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->current_status->Visible) { // current_status ?>
    <div id="r_current_status"<?= $Page->current_status->rowAttributes() ?>>
        <label id="elh_tb_employee_current_status" for="x_current_status" class="<?= $Page->LeftColumnClass ?>"><?= $Page->current_status->caption() ?><?= $Page->current_status->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->current_status->cellAttributes() ?>>
<span id="el_tb_employee_current_status">
    <select
        id="x_current_status"
        name="x_current_status"
        class="form-select ew-select<?= $Page->current_status->isInvalidClass() ?>"
        <?php if (!$Page->current_status->IsNativeSelect) { ?>
        data-select2-id="ftb_employeeadd_x_current_status"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_current_status"
        data-value-separator="<?= $Page->current_status->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->current_status->getPlaceHolder()) ?>"
        <?= $Page->current_status->editAttributes() ?>>
        <?= $Page->current_status->selectOptionListHtml("x_current_status") ?>
    </select>
    <?= $Page->current_status->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->current_status->getErrorMessage() ?></div>
<?php if (!$Page->current_status->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeeadd", function() {
    var options = { name: "x_current_status", selectId: "ftb_employeeadd_x_current_status" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeeadd.lists.current_status?.lookupOptions.length) {
        options.data = { id: "x_current_status", form: "ftb_employeeadd" };
    } else {
        options.ajax = { id: "x_current_status", form: "ftb_employeeadd", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.current_status.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->tin_number->Visible) { // tin_number ?>
    <div id="r_tin_number"<?= $Page->tin_number->rowAttributes() ?>>
        <label id="elh_tb_employee_tin_number" for="x_tin_number" class="<?= $Page->LeftColumnClass ?>"><?= $Page->tin_number->caption() ?><?= $Page->tin_number->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->tin_number->cellAttributes() ?>>
<span id="el_tb_employee_tin_number">
<input type="<?= $Page->tin_number->getInputTextType() ?>" name="x_tin_number" id="x_tin_number" data-table="tb_employee" data-field="x_tin_number" value="<?= $Page->tin_number->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->tin_number->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->tin_number->formatPattern()) ?>"<?= $Page->tin_number->editAttributes() ?> aria-describedby="x_tin_number_help">
<?= $Page->tin_number->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->tin_number->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->nssf_number->Visible) { // nssf_number ?>
    <div id="r_nssf_number"<?= $Page->nssf_number->rowAttributes() ?>>
        <label id="elh_tb_employee_nssf_number" for="x_nssf_number" class="<?= $Page->LeftColumnClass ?>"><?= $Page->nssf_number->caption() ?><?= $Page->nssf_number->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->nssf_number->cellAttributes() ?>>
<span id="el_tb_employee_nssf_number">
<input type="<?= $Page->nssf_number->getInputTextType() ?>" name="x_nssf_number" id="x_nssf_number" data-table="tb_employee" data-field="x_nssf_number" value="<?= $Page->nssf_number->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->nssf_number->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->nssf_number->formatPattern()) ?>"<?= $Page->nssf_number->editAttributes() ?> aria-describedby="x_nssf_number_help">
<?= $Page->nssf_number->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->nssf_number->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->salary_amount->Visible) { // salary_amount ?>
    <div id="r_salary_amount"<?= $Page->salary_amount->rowAttributes() ?>>
        <label id="elh_tb_employee_salary_amount" for="x_salary_amount" class="<?= $Page->LeftColumnClass ?>"><?= $Page->salary_amount->caption() ?><?= $Page->salary_amount->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->salary_amount->cellAttributes() ?>>
<span id="el_tb_employee_salary_amount">
<input type="<?= $Page->salary_amount->getInputTextType() ?>" name="x_salary_amount" id="x_salary_amount" data-table="tb_employee" data-field="x_salary_amount" value="<?= $Page->salary_amount->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->salary_amount->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->salary_amount->formatPattern()) ?>"<?= $Page->salary_amount->editAttributes() ?> aria-describedby="x_salary_amount_help">
<?= $Page->salary_amount->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->salary_amount->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->employement_type->Visible) { // employement_type ?>
    <div id="r_employement_type"<?= $Page->employement_type->rowAttributes() ?>>
        <label id="elh_tb_employee_employement_type" for="x_employement_type" class="<?= $Page->LeftColumnClass ?>"><?= $Page->employement_type->caption() ?><?= $Page->employement_type->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->employement_type->cellAttributes() ?>>
<span id="el_tb_employee_employement_type">
    <select
        id="x_employement_type"
        name="x_employement_type"
        class="form-select ew-select<?= $Page->employement_type->isInvalidClass() ?>"
        <?php if (!$Page->employement_type->IsNativeSelect) { ?>
        data-select2-id="ftb_employeeadd_x_employement_type"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_employement_type"
        data-value-separator="<?= $Page->employement_type->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->employement_type->getPlaceHolder()) ?>"
        <?= $Page->employement_type->editAttributes() ?>>
        <?= $Page->employement_type->selectOptionListHtml("x_employement_type") ?>
    </select>
    <?= $Page->employement_type->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->employement_type->getErrorMessage() ?></div>
<?php if (!$Page->employement_type->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeeadd", function() {
    var options = { name: "x_employement_type", selectId: "ftb_employeeadd_x_employement_type" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeeadd.lists.employement_type?.lookupOptions.length) {
        options.data = { id: "x_employement_type", form: "ftb_employeeadd" };
    } else {
        options.ajax = { id: "x_employement_type", form: "ftb_employeeadd", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.employement_type.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->work_schedule->Visible) { // work_schedule ?>
    <div id="r_work_schedule"<?= $Page->work_schedule->rowAttributes() ?>>
        <label id="elh_tb_employee_work_schedule" for="x_work_schedule" class="<?= $Page->LeftColumnClass ?>"><?= $Page->work_schedule->caption() ?><?= $Page->work_schedule->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->work_schedule->cellAttributes() ?>>
<span id="el_tb_employee_work_schedule">
    <select
        id="x_work_schedule"
        name="x_work_schedule"
        class="form-select ew-select<?= $Page->work_schedule->isInvalidClass() ?>"
        <?php if (!$Page->work_schedule->IsNativeSelect) { ?>
        data-select2-id="ftb_employeeadd_x_work_schedule"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_work_schedule"
        data-value-separator="<?= $Page->work_schedule->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->work_schedule->getPlaceHolder()) ?>"
        <?= $Page->work_schedule->editAttributes() ?>>
        <?= $Page->work_schedule->selectOptionListHtml("x_work_schedule") ?>
    </select>
    <?= $Page->work_schedule->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->work_schedule->getErrorMessage() ?></div>
<?php if (!$Page->work_schedule->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeeadd", function() {
    var options = { name: "x_work_schedule", selectId: "ftb_employeeadd_x_work_schedule" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeeadd.lists.work_schedule?.lookupOptions.length) {
        options.data = { id: "x_work_schedule", form: "ftb_employeeadd" };
    } else {
        options.ajax = { id: "x_work_schedule", form: "ftb_employeeadd", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.work_schedule.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->sex->Visible) { // sex ?>
    <div id="r_sex"<?= $Page->sex->rowAttributes() ?>>
        <label id="elh_tb_employee_sex" for="x_sex" class="<?= $Page->LeftColumnClass ?>"><?= $Page->sex->caption() ?><?= $Page->sex->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->sex->cellAttributes() ?>>
<span id="el_tb_employee_sex">
    <select
        id="x_sex"
        name="x_sex"
        class="form-select ew-select<?= $Page->sex->isInvalidClass() ?>"
        <?php if (!$Page->sex->IsNativeSelect) { ?>
        data-select2-id="ftb_employeeadd_x_sex"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_sex"
        data-value-separator="<?= $Page->sex->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->sex->getPlaceHolder()) ?>"
        <?= $Page->sex->editAttributes() ?>>
        <?= $Page->sex->selectOptionListHtml("x_sex") ?>
    </select>
    <?= $Page->sex->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->sex->getErrorMessage() ?></div>
<?php if (!$Page->sex->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeeadd", function() {
    var options = { name: "x_sex", selectId: "ftb_employeeadd_x_sex" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeeadd.lists.sex?.lookupOptions.length) {
        options.data = { id: "x_sex", form: "ftb_employeeadd" };
    } else {
        options.ajax = { id: "x_sex", form: "ftb_employeeadd", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.sex.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_employeeadd"><?= $Language->phrase("AddBtn") ?></button>
<?php if (IsJsonResponse()) { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-bs-dismiss="modal"><?= $Language->phrase("CancelBtn") ?></button>
<?php } else { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_employeeadd" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
<?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_employee");
});
</script>
<script>
loadjs.ready("load", function () {
    // Startup script
    // Write your table-specific startup script here, no need to add script tags.
    // Write your table-specific startup script here, no need to add script tags.
    $('.form-control[type="tel"]').addClass('form-control-sm w-100');
    $('.form-control[type="text"]').addClass('form-control-sm w-100');
    $('.form-control[type="email"]').addClass('form-control-sm w-100');
    $('.form-control.tt-input[type="text"]').addClass('form-control-sm w-100');
    $('[class="form-select ew-select"]').addClass('form-select-sm w-100')
    $('[class="custom-select ew-custom-select"]').addClass('w-100').removeClass('ew-custom-select');
});
</script>
