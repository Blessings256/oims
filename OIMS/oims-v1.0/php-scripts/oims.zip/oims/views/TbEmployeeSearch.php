<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbEmployeeSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_employee: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var ftb_employeesearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_employeesearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["id", [ew.Validators.integer], fields.id.isInvalid],
            ["y_id", [ew.Validators.between], false],
            ["employee_number", [], fields.employee_number.isInvalid],
            ["first_name", [], fields.first_name.isInvalid],
            ["last_name", [], fields.last_name.isInvalid],
            ["other_name", [], fields.other_name.isInvalid],
            ["job_tile", [], fields.job_tile.isInvalid],
            ["pri_phone_no", [], fields.pri_phone_no.isInvalid],
            ["alt_phone_no", [], fields.alt_phone_no.isInvalid],
            ["personal_email", [], fields.personal_email.isInvalid],
            ["official_email", [], fields.official_email.isInvalid],
            ["department", [], fields.department.isInvalid],
            ["hire_date", [ew.Validators.datetime(fields.hire_date.clientFormatPattern)], fields.hire_date.isInvalid],
            ["current_status", [], fields.current_status.isInvalid],
            ["tin_number", [], fields.tin_number.isInvalid],
            ["nssf_number", [], fields.nssf_number.isInvalid],
            ["salary_amount", [ew.Validators.float], fields.salary_amount.isInvalid],
            ["employement_type", [], fields.employement_type.isInvalid],
            ["work_schedule", [], fields.work_schedule.isInvalid],
            ["sex", [], fields.sex.isInvalid]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "current_status": <?= $Page->current_status->toClientList($Page) ?>,
            "employement_type": <?= $Page->employement_type->toClientList($Page) ?>,
            "work_schedule": <?= $Page->work_schedule->toClientList($Page) ?>,
            "sex": <?= $Page->sex->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_employeesearch" id="ftb_employeesearch" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_employee">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<div class="ew-search-div"><!-- page* -->
<?php if ($Page->id->Visible) { // id ?>
    <div id="r_id" class="row"<?= $Page->id->rowAttributes() ?>>
        <label for="x_id" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_id"><?= $Page->id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_id" id="z_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_employee_id" class="ew-search-field">
<input type="<?= $Page->id->getInputTextType() ?>" name="x_id" id="x_id" data-table="tb_employee" data-field="x_id" value="<?= $Page->id->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_employee_id" class="ew-search-field2 d-none">
<input type="<?= $Page->id->getInputTextType() ?>" name="y_id" id="y_id" data-table="tb_employee" data-field="x_id" value="<?= $Page->id->EditValue2 ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->employee_number->Visible) { // employee_number ?>
    <div id="r_employee_number" class="row"<?= $Page->employee_number->rowAttributes() ?>>
        <label for="x_employee_number" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_employee_number"><?= $Page->employee_number->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_employee_number" id="z_employee_number" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->employee_number->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_employee_number" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->employee_number->getInputTextType() ?>" name="x_employee_number" id="x_employee_number" data-table="tb_employee" data-field="x_employee_number" value="<?= $Page->employee_number->EditValue ?>" size="30" maxlength="30" placeholder="<?= HtmlEncode($Page->employee_number->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->employee_number->formatPattern()) ?>"<?= $Page->employee_number->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->employee_number->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->first_name->Visible) { // first_name ?>
    <div id="r_first_name" class="row"<?= $Page->first_name->rowAttributes() ?>>
        <label for="x_first_name" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_first_name"><?= $Page->first_name->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_first_name" id="z_first_name" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->first_name->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_first_name" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->first_name->getInputTextType() ?>" name="x_first_name" id="x_first_name" data-table="tb_employee" data-field="x_first_name" value="<?= $Page->first_name->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->first_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->first_name->formatPattern()) ?>"<?= $Page->first_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->first_name->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->last_name->Visible) { // last_name ?>
    <div id="r_last_name" class="row"<?= $Page->last_name->rowAttributes() ?>>
        <label for="x_last_name" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_last_name"><?= $Page->last_name->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_last_name" id="z_last_name" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->last_name->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_last_name" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->last_name->getInputTextType() ?>" name="x_last_name" id="x_last_name" data-table="tb_employee" data-field="x_last_name" value="<?= $Page->last_name->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->last_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->last_name->formatPattern()) ?>"<?= $Page->last_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->last_name->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->other_name->Visible) { // other_name ?>
    <div id="r_other_name" class="row"<?= $Page->other_name->rowAttributes() ?>>
        <label for="x_other_name" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_other_name"><?= $Page->other_name->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_other_name" id="z_other_name" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->other_name->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_other_name" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->other_name->getInputTextType() ?>" name="x_other_name" id="x_other_name" data-table="tb_employee" data-field="x_other_name" value="<?= $Page->other_name->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->other_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->other_name->formatPattern()) ?>"<?= $Page->other_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->other_name->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->job_tile->Visible) { // job_tile ?>
    <div id="r_job_tile" class="row"<?= $Page->job_tile->rowAttributes() ?>>
        <label for="x_job_tile" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_job_tile"><?= $Page->job_tile->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_job_tile" id="z_job_tile" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->job_tile->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_job_tile" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->job_tile->getInputTextType() ?>" name="x_job_tile" id="x_job_tile" data-table="tb_employee" data-field="x_job_tile" value="<?= $Page->job_tile->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->job_tile->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->job_tile->formatPattern()) ?>"<?= $Page->job_tile->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->job_tile->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->pri_phone_no->Visible) { // pri_phone_no ?>
    <div id="r_pri_phone_no" class="row"<?= $Page->pri_phone_no->rowAttributes() ?>>
        <label for="x_pri_phone_no" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_pri_phone_no"><?= $Page->pri_phone_no->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_pri_phone_no" id="z_pri_phone_no" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->pri_phone_no->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_pri_phone_no" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->pri_phone_no->getInputTextType() ?>" name="x_pri_phone_no" id="x_pri_phone_no" data-table="tb_employee" data-field="x_pri_phone_no" value="<?= $Page->pri_phone_no->EditValue ?>" size="30" maxlength="25" placeholder="<?= HtmlEncode($Page->pri_phone_no->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->pri_phone_no->formatPattern()) ?>"<?= $Page->pri_phone_no->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->pri_phone_no->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->alt_phone_no->Visible) { // alt_phone_no ?>
    <div id="r_alt_phone_no" class="row"<?= $Page->alt_phone_no->rowAttributes() ?>>
        <label for="x_alt_phone_no" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_alt_phone_no"><?= $Page->alt_phone_no->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_alt_phone_no" id="z_alt_phone_no" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->alt_phone_no->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_alt_phone_no" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->alt_phone_no->getInputTextType() ?>" name="x_alt_phone_no" id="x_alt_phone_no" data-table="tb_employee" data-field="x_alt_phone_no" value="<?= $Page->alt_phone_no->EditValue ?>" size="30" maxlength="25" placeholder="<?= HtmlEncode($Page->alt_phone_no->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->alt_phone_no->formatPattern()) ?>"<?= $Page->alt_phone_no->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->alt_phone_no->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->personal_email->Visible) { // personal_email ?>
    <div id="r_personal_email" class="row"<?= $Page->personal_email->rowAttributes() ?>>
        <label for="x_personal_email" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_personal_email"><?= $Page->personal_email->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_personal_email" id="z_personal_email" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->personal_email->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_personal_email" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->personal_email->getInputTextType() ?>" name="x_personal_email" id="x_personal_email" data-table="tb_employee" data-field="x_personal_email" value="<?= $Page->personal_email->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->personal_email->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->personal_email->formatPattern()) ?>"<?= $Page->personal_email->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->personal_email->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->official_email->Visible) { // official_email ?>
    <div id="r_official_email" class="row"<?= $Page->official_email->rowAttributes() ?>>
        <label for="x_official_email" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_official_email"><?= $Page->official_email->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_official_email" id="z_official_email" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->official_email->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_official_email" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->official_email->getInputTextType() ?>" name="x_official_email" id="x_official_email" data-table="tb_employee" data-field="x_official_email" value="<?= $Page->official_email->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->official_email->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->official_email->formatPattern()) ?>"<?= $Page->official_email->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->official_email->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->department->Visible) { // department ?>
    <div id="r_department" class="row"<?= $Page->department->rowAttributes() ?>>
        <label for="x_department" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_department"><?= $Page->department->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_department" id="z_department" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->department->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_department" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->department->getInputTextType() ?>" name="x_department" id="x_department" data-table="tb_employee" data-field="x_department" value="<?= $Page->department->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->department->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->department->formatPattern()) ?>"<?= $Page->department->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->department->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->hire_date->Visible) { // hire_date ?>
    <div id="r_hire_date" class="row"<?= $Page->hire_date->rowAttributes() ?>>
        <label for="x_hire_date" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_hire_date"><?= $Page->hire_date->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_hire_date" id="z_hire_date" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->hire_date->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_hire_date" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->hire_date->getInputTextType() ?>" name="x_hire_date" id="x_hire_date" data-table="tb_employee" data-field="x_hire_date" value="<?= $Page->hire_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->hire_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->hire_date->formatPattern()) ?>"<?= $Page->hire_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->hire_date->getErrorMessage(false) ?></div>
<?php if (!$Page->hire_date->ReadOnly && !$Page->hire_date->Disabled && !isset($Page->hire_date->EditAttrs["readonly"]) && !isset($Page->hire_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_employeesearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_employeesearch", "x_hire_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->current_status->Visible) { // current_status ?>
    <div id="r_current_status" class="row"<?= $Page->current_status->rowAttributes() ?>>
        <label for="x_current_status" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_current_status"><?= $Page->current_status->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_current_status" id="z_current_status" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->current_status->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_current_status" class="ew-search-field ew-search-field-single">
    <select
        id="x_current_status"
        name="x_current_status"
        class="form-select ew-select<?= $Page->current_status->isInvalidClass() ?>"
        <?php if (!$Page->current_status->IsNativeSelect) { ?>
        data-select2-id="ftb_employeesearch_x_current_status"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_current_status"
        data-value-separator="<?= $Page->current_status->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->current_status->getPlaceHolder()) ?>"
        <?= $Page->current_status->editAttributes() ?>>
        <?= $Page->current_status->selectOptionListHtml("x_current_status") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->current_status->getErrorMessage(false) ?></div>
<?php if (!$Page->current_status->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeesearch", function() {
    var options = { name: "x_current_status", selectId: "ftb_employeesearch_x_current_status" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeesearch.lists.current_status?.lookupOptions.length) {
        options.data = { id: "x_current_status", form: "ftb_employeesearch" };
    } else {
        options.ajax = { id: "x_current_status", form: "ftb_employeesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.current_status.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->tin_number->Visible) { // tin_number ?>
    <div id="r_tin_number" class="row"<?= $Page->tin_number->rowAttributes() ?>>
        <label for="x_tin_number" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_tin_number"><?= $Page->tin_number->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_tin_number" id="z_tin_number" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->tin_number->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_tin_number" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->tin_number->getInputTextType() ?>" name="x_tin_number" id="x_tin_number" data-table="tb_employee" data-field="x_tin_number" value="<?= $Page->tin_number->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->tin_number->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->tin_number->formatPattern()) ?>"<?= $Page->tin_number->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->tin_number->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->nssf_number->Visible) { // nssf_number ?>
    <div id="r_nssf_number" class="row"<?= $Page->nssf_number->rowAttributes() ?>>
        <label for="x_nssf_number" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_nssf_number"><?= $Page->nssf_number->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("LIKE") ?>
<input type="hidden" name="z_nssf_number" id="z_nssf_number" value="LIKE">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->nssf_number->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_nssf_number" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->nssf_number->getInputTextType() ?>" name="x_nssf_number" id="x_nssf_number" data-table="tb_employee" data-field="x_nssf_number" value="<?= $Page->nssf_number->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->nssf_number->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->nssf_number->formatPattern()) ?>"<?= $Page->nssf_number->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->nssf_number->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->salary_amount->Visible) { // salary_amount ?>
    <div id="r_salary_amount" class="row"<?= $Page->salary_amount->rowAttributes() ?>>
        <label for="x_salary_amount" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_salary_amount"><?= $Page->salary_amount->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_salary_amount" id="z_salary_amount" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->salary_amount->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_salary_amount" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->salary_amount->getInputTextType() ?>" name="x_salary_amount" id="x_salary_amount" data-table="tb_employee" data-field="x_salary_amount" value="<?= $Page->salary_amount->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->salary_amount->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->salary_amount->formatPattern()) ?>"<?= $Page->salary_amount->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->salary_amount->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->employement_type->Visible) { // employement_type ?>
    <div id="r_employement_type" class="row"<?= $Page->employement_type->rowAttributes() ?>>
        <label for="x_employement_type" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_employement_type"><?= $Page->employement_type->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_employement_type" id="z_employement_type" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->employement_type->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_employement_type" class="ew-search-field ew-search-field-single">
    <select
        id="x_employement_type"
        name="x_employement_type"
        class="form-select ew-select<?= $Page->employement_type->isInvalidClass() ?>"
        <?php if (!$Page->employement_type->IsNativeSelect) { ?>
        data-select2-id="ftb_employeesearch_x_employement_type"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_employement_type"
        data-value-separator="<?= $Page->employement_type->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->employement_type->getPlaceHolder()) ?>"
        <?= $Page->employement_type->editAttributes() ?>>
        <?= $Page->employement_type->selectOptionListHtml("x_employement_type") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->employement_type->getErrorMessage(false) ?></div>
<?php if (!$Page->employement_type->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeesearch", function() {
    var options = { name: "x_employement_type", selectId: "ftb_employeesearch_x_employement_type" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeesearch.lists.employement_type?.lookupOptions.length) {
        options.data = { id: "x_employement_type", form: "ftb_employeesearch" };
    } else {
        options.ajax = { id: "x_employement_type", form: "ftb_employeesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.employement_type.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->work_schedule->Visible) { // work_schedule ?>
    <div id="r_work_schedule" class="row"<?= $Page->work_schedule->rowAttributes() ?>>
        <label for="x_work_schedule" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_work_schedule"><?= $Page->work_schedule->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_work_schedule" id="z_work_schedule" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->work_schedule->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_work_schedule" class="ew-search-field ew-search-field-single">
    <select
        id="x_work_schedule"
        name="x_work_schedule"
        class="form-select ew-select<?= $Page->work_schedule->isInvalidClass() ?>"
        <?php if (!$Page->work_schedule->IsNativeSelect) { ?>
        data-select2-id="ftb_employeesearch_x_work_schedule"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_work_schedule"
        data-value-separator="<?= $Page->work_schedule->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->work_schedule->getPlaceHolder()) ?>"
        <?= $Page->work_schedule->editAttributes() ?>>
        <?= $Page->work_schedule->selectOptionListHtml("x_work_schedule") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->work_schedule->getErrorMessage(false) ?></div>
<?php if (!$Page->work_schedule->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeesearch", function() {
    var options = { name: "x_work_schedule", selectId: "ftb_employeesearch_x_work_schedule" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeesearch.lists.work_schedule?.lookupOptions.length) {
        options.data = { id: "x_work_schedule", form: "ftb_employeesearch" };
    } else {
        options.ajax = { id: "x_work_schedule", form: "ftb_employeesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.work_schedule.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->sex->Visible) { // sex ?>
    <div id="r_sex" class="row"<?= $Page->sex->rowAttributes() ?>>
        <label for="x_sex" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_employee_sex"><?= $Page->sex->caption() ?></span>
        <span class="ew-search-operator">
<?= $Language->phrase("=") ?>
<input type="hidden" name="z_sex" id="z_sex" value="=">
</span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->sex->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                <span id="el_tb_employee_sex" class="ew-search-field ew-search-field-single">
    <select
        id="x_sex"
        name="x_sex"
        class="form-select ew-select<?= $Page->sex->isInvalidClass() ?>"
        <?php if (!$Page->sex->IsNativeSelect) { ?>
        data-select2-id="ftb_employeesearch_x_sex"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_sex"
        data-value-separator="<?= $Page->sex->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->sex->getPlaceHolder()) ?>"
        <?= $Page->sex->editAttributes() ?>>
        <?= $Page->sex->selectOptionListHtml("x_sex") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->sex->getErrorMessage(false) ?></div>
<?php if (!$Page->sex->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeesearch", function() {
    var options = { name: "x_sex", selectId: "ftb_employeesearch_x_sex" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeesearch.lists.sex?.lookupOptions.length) {
        options.data = { id: "x_sex", form: "ftb_employeesearch" };
    } else {
        options.ajax = { id: "x_sex", form: "ftb_employeesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.sex.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_employeesearch"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_employeesearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" form="ftb_employeesearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_employee");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
