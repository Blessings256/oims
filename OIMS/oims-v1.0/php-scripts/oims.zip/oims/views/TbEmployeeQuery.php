<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbEmployeeSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_employee: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var ftb_employeesearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_employeesearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["id", [ew.Validators.integer], fields.id.isInvalid],
            ["y_id", [ew.Validators.between], false],
            ["employee_number", [], fields.employee_number.isInvalid],
            ["first_name", [], fields.first_name.isInvalid],
            ["last_name", [], fields.last_name.isInvalid],
            ["other_name", [], fields.other_name.isInvalid],
            ["job_tile", [], fields.job_tile.isInvalid],
            ["pri_phone_no", [], fields.pri_phone_no.isInvalid],
            ["alt_phone_no", [], fields.alt_phone_no.isInvalid],
            ["personal_email", [], fields.personal_email.isInvalid],
            ["official_email", [], fields.official_email.isInvalid],
            ["department", [], fields.department.isInvalid],
            ["hire_date", [ew.Validators.datetime(fields.hire_date.clientFormatPattern)], fields.hire_date.isInvalid],
            ["current_status", [], fields.current_status.isInvalid],
            ["tin_number", [], fields.tin_number.isInvalid],
            ["nssf_number", [], fields.nssf_number.isInvalid],
            ["salary_amount", [ew.Validators.float], fields.salary_amount.isInvalid],
            ["employement_type", [], fields.employement_type.isInvalid],
            ["work_schedule", [], fields.work_schedule.isInvalid],
            ["sex", [], fields.sex.isInvalid]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setQueryBuilderLists({
            "current_status": <?= $Page->current_status->toClientList($Page) ?>,
            "employement_type": <?= $Page->employement_type->toClientList($Page) ?>,
            "work_schedule": <?= $Page->work_schedule->toClientList($Page) ?>,
            "sex": <?= $Page->sex->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_employeesearch" id="ftb_employeesearch" class="<?= $Page->FormClassName ?>" action="<?= HtmlEncode(GetUrl("tbemployeelist")) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_employee">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<input type="hidden" name="rules" value="<?= HtmlEncode($Page->getSessionRules()) ?>">
<template id="tpx_tb_employee_id" class="tb_employeesearch"><span id="el_tb_employee_id" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->id->getInputTextType() ?>" name="x_id" id="x_id" data-table="tb_employee" data-field="x_id" value="<?= $Page->id->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_employee_number" class="tb_employeesearch"><span id="el_tb_employee_employee_number" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->employee_number->getInputTextType() ?>" name="x_employee_number" id="x_employee_number" data-table="tb_employee" data-field="x_employee_number" value="<?= $Page->employee_number->EditValue ?>" size="30" maxlength="30" placeholder="<?= HtmlEncode($Page->employee_number->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->employee_number->formatPattern()) ?>"<?= $Page->employee_number->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->employee_number->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_first_name" class="tb_employeesearch"><span id="el_tb_employee_first_name" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->first_name->getInputTextType() ?>" name="x_first_name" id="x_first_name" data-table="tb_employee" data-field="x_first_name" value="<?= $Page->first_name->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->first_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->first_name->formatPattern()) ?>"<?= $Page->first_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->first_name->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_last_name" class="tb_employeesearch"><span id="el_tb_employee_last_name" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->last_name->getInputTextType() ?>" name="x_last_name" id="x_last_name" data-table="tb_employee" data-field="x_last_name" value="<?= $Page->last_name->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->last_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->last_name->formatPattern()) ?>"<?= $Page->last_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->last_name->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_other_name" class="tb_employeesearch"><span id="el_tb_employee_other_name" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->other_name->getInputTextType() ?>" name="x_other_name" id="x_other_name" data-table="tb_employee" data-field="x_other_name" value="<?= $Page->other_name->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->other_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->other_name->formatPattern()) ?>"<?= $Page->other_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->other_name->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_job_tile" class="tb_employeesearch"><span id="el_tb_employee_job_tile" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->job_tile->getInputTextType() ?>" name="x_job_tile" id="x_job_tile" data-table="tb_employee" data-field="x_job_tile" value="<?= $Page->job_tile->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->job_tile->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->job_tile->formatPattern()) ?>"<?= $Page->job_tile->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->job_tile->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_pri_phone_no" class="tb_employeesearch"><span id="el_tb_employee_pri_phone_no" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->pri_phone_no->getInputTextType() ?>" name="x_pri_phone_no" id="x_pri_phone_no" data-table="tb_employee" data-field="x_pri_phone_no" value="<?= $Page->pri_phone_no->EditValue ?>" size="30" maxlength="25" placeholder="<?= HtmlEncode($Page->pri_phone_no->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->pri_phone_no->formatPattern()) ?>"<?= $Page->pri_phone_no->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->pri_phone_no->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_alt_phone_no" class="tb_employeesearch"><span id="el_tb_employee_alt_phone_no" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->alt_phone_no->getInputTextType() ?>" name="x_alt_phone_no" id="x_alt_phone_no" data-table="tb_employee" data-field="x_alt_phone_no" value="<?= $Page->alt_phone_no->EditValue ?>" size="30" maxlength="25" placeholder="<?= HtmlEncode($Page->alt_phone_no->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->alt_phone_no->formatPattern()) ?>"<?= $Page->alt_phone_no->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->alt_phone_no->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_personal_email" class="tb_employeesearch"><span id="el_tb_employee_personal_email" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->personal_email->getInputTextType() ?>" name="x_personal_email" id="x_personal_email" data-table="tb_employee" data-field="x_personal_email" value="<?= $Page->personal_email->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->personal_email->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->personal_email->formatPattern()) ?>"<?= $Page->personal_email->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->personal_email->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_official_email" class="tb_employeesearch"><span id="el_tb_employee_official_email" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->official_email->getInputTextType() ?>" name="x_official_email" id="x_official_email" data-table="tb_employee" data-field="x_official_email" value="<?= $Page->official_email->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->official_email->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->official_email->formatPattern()) ?>"<?= $Page->official_email->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->official_email->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_department" class="tb_employeesearch"><span id="el_tb_employee_department" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->department->getInputTextType() ?>" name="x_department" id="x_department" data-table="tb_employee" data-field="x_department" value="<?= $Page->department->EditValue ?>" size="30" maxlength="100" placeholder="<?= HtmlEncode($Page->department->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->department->formatPattern()) ?>"<?= $Page->department->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->department->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_hire_date" class="tb_employeesearch"><span id="el_tb_employee_hire_date" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->hire_date->getInputTextType() ?>" name="x_hire_date" id="x_hire_date" data-table="tb_employee" data-field="x_hire_date" value="<?= $Page->hire_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->hire_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->hire_date->formatPattern()) ?>"<?= $Page->hire_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->hire_date->getErrorMessage(false) ?></div>
<?php if (!$Page->hire_date->ReadOnly && !$Page->hire_date->Disabled && !isset($Page->hire_date->EditAttrs["readonly"]) && !isset($Page->hire_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_employeesearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_employeesearch", "x_hire_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_employee_current_status" class="tb_employeesearch"><span id="el_tb_employee_current_status" class="ew-search-field ew-search-field-single">
    <select
        id="x_current_status"
        name="x_current_status"
        class="form-select ew-select<?= $Page->current_status->isInvalidClass() ?>"
        <?php if (!$Page->current_status->IsNativeSelect) { ?>
        data-select2-id="ftb_employeesearch_x_current_status"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_current_status"
        data-value-separator="<?= $Page->current_status->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->current_status->getPlaceHolder()) ?>"
        <?= $Page->current_status->editAttributes() ?>>
        <?= $Page->current_status->selectOptionListHtml("x_current_status") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->current_status->getErrorMessage(false) ?></div>
<?php if (!$Page->current_status->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeesearch", function() {
    var options = { name: "x_current_status", selectId: "ftb_employeesearch_x_current_status" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeesearch.lists.current_status?.lookupOptions.length) {
        options.data = { id: "x_current_status", form: "ftb_employeesearch" };
    } else {
        options.ajax = { id: "x_current_status", form: "ftb_employeesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.current_status.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_employee_tin_number" class="tb_employeesearch"><span id="el_tb_employee_tin_number" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->tin_number->getInputTextType() ?>" name="x_tin_number" id="x_tin_number" data-table="tb_employee" data-field="x_tin_number" value="<?= $Page->tin_number->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->tin_number->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->tin_number->formatPattern()) ?>"<?= $Page->tin_number->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->tin_number->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_nssf_number" class="tb_employeesearch"><span id="el_tb_employee_nssf_number" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->nssf_number->getInputTextType() ?>" name="x_nssf_number" id="x_nssf_number" data-table="tb_employee" data-field="x_nssf_number" value="<?= $Page->nssf_number->EditValue ?>" size="30" maxlength="50" placeholder="<?= HtmlEncode($Page->nssf_number->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->nssf_number->formatPattern()) ?>"<?= $Page->nssf_number->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->nssf_number->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_salary_amount" class="tb_employeesearch"><span id="el_tb_employee_salary_amount" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->salary_amount->getInputTextType() ?>" name="x_salary_amount" id="x_salary_amount" data-table="tb_employee" data-field="x_salary_amount" value="<?= $Page->salary_amount->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->salary_amount->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->salary_amount->formatPattern()) ?>"<?= $Page->salary_amount->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->salary_amount->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_employee_employement_type" class="tb_employeesearch"><span id="el_tb_employee_employement_type" class="ew-search-field ew-search-field-single">
    <select
        id="x_employement_type"
        name="x_employement_type"
        class="form-select ew-select<?= $Page->employement_type->isInvalidClass() ?>"
        <?php if (!$Page->employement_type->IsNativeSelect) { ?>
        data-select2-id="ftb_employeesearch_x_employement_type"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_employement_type"
        data-value-separator="<?= $Page->employement_type->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->employement_type->getPlaceHolder()) ?>"
        <?= $Page->employement_type->editAttributes() ?>>
        <?= $Page->employement_type->selectOptionListHtml("x_employement_type") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->employement_type->getErrorMessage(false) ?></div>
<?php if (!$Page->employement_type->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeesearch", function() {
    var options = { name: "x_employement_type", selectId: "ftb_employeesearch_x_employement_type" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeesearch.lists.employement_type?.lookupOptions.length) {
        options.data = { id: "x_employement_type", form: "ftb_employeesearch" };
    } else {
        options.ajax = { id: "x_employement_type", form: "ftb_employeesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.employement_type.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_employee_work_schedule" class="tb_employeesearch"><span id="el_tb_employee_work_schedule" class="ew-search-field ew-search-field-single">
    <select
        id="x_work_schedule"
        name="x_work_schedule"
        class="form-select ew-select<?= $Page->work_schedule->isInvalidClass() ?>"
        <?php if (!$Page->work_schedule->IsNativeSelect) { ?>
        data-select2-id="ftb_employeesearch_x_work_schedule"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_work_schedule"
        data-value-separator="<?= $Page->work_schedule->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->work_schedule->getPlaceHolder()) ?>"
        <?= $Page->work_schedule->editAttributes() ?>>
        <?= $Page->work_schedule->selectOptionListHtml("x_work_schedule") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->work_schedule->getErrorMessage(false) ?></div>
<?php if (!$Page->work_schedule->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeesearch", function() {
    var options = { name: "x_work_schedule", selectId: "ftb_employeesearch_x_work_schedule" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeesearch.lists.work_schedule?.lookupOptions.length) {
        options.data = { id: "x_work_schedule", form: "ftb_employeesearch" };
    } else {
        options.ajax = { id: "x_work_schedule", form: "ftb_employeesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.work_schedule.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_employee_sex" class="tb_employeesearch"><span id="el_tb_employee_sex" class="ew-search-field ew-search-field-single">
    <select
        id="x_sex"
        name="x_sex"
        class="form-select ew-select<?= $Page->sex->isInvalidClass() ?>"
        <?php if (!$Page->sex->IsNativeSelect) { ?>
        data-select2-id="ftb_employeesearch_x_sex"
        <?php } ?>
        data-table="tb_employee"
        data-field="x_sex"
        data-value-separator="<?= $Page->sex->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->sex->getPlaceHolder()) ?>"
        <?= $Page->sex->editAttributes() ?>>
        <?= $Page->sex->selectOptionListHtml("x_sex") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->sex->getErrorMessage(false) ?></div>
<?php if (!$Page->sex->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_employeesearch", function() {
    var options = { name: "x_sex", selectId: "ftb_employeesearch_x_sex" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_employeesearch.lists.sex?.lookupOptions.length) {
        options.data = { id: "x_sex", form: "ftb_employeesearch" };
    } else {
        options.ajax = { id: "x_sex", form: "ftb_employeesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_employee.fields.sex.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<div id="tb_employee_query_builder" class="query-builder mb-3"></div>
<div class="btn-group mb-3 query-btn-group"></div>
<button type="button" id="btn-view-rules" class="btn btn-primary d-none disabled" title="<?= HtmlEncode($Language->phrase("View", true)) ?>"><i class="fa-solid fa-eye ew-icon"></i></button>
<button type="button" id="btn-clear-rules" class="btn btn-primary d-none disabled" title="<?= HtmlEncode($Language->phrase("Clear", true)) ?>"><i class="fa-solid fa-xmark ew-icon"></i></button>
<script>
// Filter builder
loadjs.ready(["wrapper", "head"], () => {
    let filters = [
            {
                id: "id",
                type: "integer",
                label: currentTable.fields.id.caption,
                operators: currentTable.fields.id.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.id.validators),
                data: {
                    format: currentTable.fields.id.clientFormatPattern
                }
            },
            {
                id: "employee_number",
                type: "string",
                label: currentTable.fields.employee_number.caption,
                operators: currentTable.fields.employee_number.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.employee_number.validators),
                data: {
                    format: currentTable.fields.employee_number.clientFormatPattern
                }
            },
            {
                id: "first_name",
                type: "string",
                label: currentTable.fields.first_name.caption,
                operators: currentTable.fields.first_name.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.first_name.validators),
                data: {
                    format: currentTable.fields.first_name.clientFormatPattern
                }
            },
            {
                id: "last_name",
                type: "string",
                label: currentTable.fields.last_name.caption,
                operators: currentTable.fields.last_name.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.last_name.validators),
                data: {
                    format: currentTable.fields.last_name.clientFormatPattern
                }
            },
            {
                id: "other_name",
                type: "string",
                label: currentTable.fields.other_name.caption,
                operators: currentTable.fields.other_name.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.other_name.validators),
                data: {
                    format: currentTable.fields.other_name.clientFormatPattern
                }
            },
            {
                id: "job_tile",
                type: "string",
                label: currentTable.fields.job_tile.caption,
                operators: currentTable.fields.job_tile.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.job_tile.validators),
                data: {
                    format: currentTable.fields.job_tile.clientFormatPattern
                }
            },
            {
                id: "pri_phone_no",
                type: "string",
                label: currentTable.fields.pri_phone_no.caption,
                operators: currentTable.fields.pri_phone_no.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.pri_phone_no.validators),
                data: {
                    format: currentTable.fields.pri_phone_no.clientFormatPattern
                }
            },
            {
                id: "alt_phone_no",
                type: "string",
                label: currentTable.fields.alt_phone_no.caption,
                operators: currentTable.fields.alt_phone_no.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.alt_phone_no.validators),
                data: {
                    format: currentTable.fields.alt_phone_no.clientFormatPattern
                }
            },
            {
                id: "personal_email",
                type: "string",
                label: currentTable.fields.personal_email.caption,
                operators: currentTable.fields.personal_email.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.personal_email.validators),
                data: {
                    format: currentTable.fields.personal_email.clientFormatPattern
                }
            },
            {
                id: "official_email",
                type: "string",
                label: currentTable.fields.official_email.caption,
                operators: currentTable.fields.official_email.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.official_email.validators),
                data: {
                    format: currentTable.fields.official_email.clientFormatPattern
                }
            },
            {
                id: "department",
                type: "string",
                label: currentTable.fields.department.caption,
                operators: currentTable.fields.department.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.department.validators),
                data: {
                    format: currentTable.fields.department.clientFormatPattern
                }
            },
            {
                id: "hire_date",
                type: "datetime",
                label: currentTable.fields.hire_date.caption,
                operators: currentTable.fields.hire_date.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.hire_date.validators),
                data: {
                    format: currentTable.fields.hire_date.clientFormatPattern
                }
            },
            {
                id: "current_status",
                type: "string",
                label: currentTable.fields.current_status.caption,
                operators: currentTable.fields.current_status.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.current_status.validators),
                data: {
                    format: currentTable.fields.current_status.clientFormatPattern
                }
            },
            {
                id: "tin_number",
                type: "string",
                label: currentTable.fields.tin_number.caption,
                operators: currentTable.fields.tin_number.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.tin_number.validators),
                data: {
                    format: currentTable.fields.tin_number.clientFormatPattern
                }
            },
            {
                id: "nssf_number",
                type: "string",
                label: currentTable.fields.nssf_number.caption,
                operators: currentTable.fields.nssf_number.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.nssf_number.validators),
                data: {
                    format: currentTable.fields.nssf_number.clientFormatPattern
                }
            },
            {
                id: "salary_amount",
                type: "double",
                label: currentTable.fields.salary_amount.caption,
                operators: currentTable.fields.salary_amount.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.salary_amount.validators),
                data: {
                    format: currentTable.fields.salary_amount.clientFormatPattern
                }
            },
            {
                id: "employement_type",
                type: "string",
                label: currentTable.fields.employement_type.caption,
                operators: currentTable.fields.employement_type.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.employement_type.validators),
                data: {
                    format: currentTable.fields.employement_type.clientFormatPattern
                }
            },
            {
                id: "work_schedule",
                type: "string",
                label: currentTable.fields.work_schedule.caption,
                operators: currentTable.fields.work_schedule.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.work_schedule.validators),
                data: {
                    format: currentTable.fields.work_schedule.clientFormatPattern
                }
            },
            {
                id: "sex",
                type: "string",
                label: currentTable.fields.sex.caption,
                operators: currentTable.fields.sex.clientSearchOperators,
                default_operator: "equal",
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_employeesearch.fields.sex.validators),
                data: {
                    format: currentTable.fields.sex.clientFormatPattern
                }
            },
        ],
        $ = jQuery,
        $qb = $("#tb_employee_query_builder"),
        args = {},
        rules = ew.parseJson($("#ftb_employeesearch input[name=rules]").val()),
        queryBuilderOptions = Object.assign({}, ew.queryBuilderOptions),
        allowViewRules = queryBuilderOptions.allowViewRules,
        allowClearRules = queryBuilderOptions.allowClearRules,
        hasRules = group => Array.isArray(group?.rules) && group.rules.length > 0,
        getRules = () => $qb.queryBuilder("getRules", { skip_empty: true }),
        getSql = () => $qb.queryBuilder("getSQL", false, false, rules)?.sql;
    delete queryBuilderOptions.allowViewRules;
    delete queryBuilderOptions.allowClearRules;
    args.options = ew.deepAssign({
        plugins: Object.assign({}, ew.queryBuilderPlugins),
        lang: ew.language.phrase("querybuilderjs"),
        select_placeholder: ew.language.phrase("PleaseSelect"),
        inputs_separator: `<div class="d-inline-flex ms-2 me-2">${ew.language.phrase("AND")}</div>`, // For "between"
        filters,
        rules
    }, queryBuilderOptions);
    $qb.trigger("querybuilder", [args]);
    $qb.queryBuilder(args.options).on("rulesChanged.queryBuilder", () => {
        let rules = getRules();
        !ew.DEBUG || console.log(rules, getSql());
        $("#btn-reset, #btn-action, #btn-clear-rules, #btn-view-rules").toggleClass("disabled", !rules);
    }).on("afterCreateRuleInput.queryBuilder", function(e, rule) {
        let select = rule.$el.find(".rule-value-container").find("selection-list, select")[0];
        if (select) { // Selection list
            let id = select.dataset.field.replace("^x_", ""),
                form = ew.forms.get(select);
            form.updateList(select, undefined, undefined, true); // Update immediately
        }
    });
    $("#ftb_employeesearch").on("beforesubmit", function () {
        this.rules.value = JSON.stringify(getRules());
    });
    $("#btn-reset").toggleClass("d-none", false).on("click", () => {
        hasRules(rules) ? $qb.queryBuilder("setRules", rules) : $qb.queryBuilder("reset");
        return false;
    });
    $("#btn-action").toggleClass("d-none", false);
    if (allowClearRules) {
        $("#btn-clear-rules").appendTo(".query-btn-group").removeClass("d-none").on("click", () => $qb.queryBuilder("reset"));
    }
    if (allowViewRules) {
        $("#btn-view-rules").appendTo(".query-btn-group").removeClass("d-none").on("click", () => {
            let rules = getRules();
            if (hasRules(rules)) {
                let sql = getSql();
                ew.alert(sql ? '<pre class="text-start fs-6">' + sql + '</pre>' : '', "dark");
                !ew.DEBUG || console.log(rules, sql);
            } else {
                ew.alert(ew.language.phrase("EmptyLabel"));
            }
        });
    }
    if (hasRules(rules)) { // Enable buttons if rules exist initially
        $("#btn-reset, #btn-action, #btn-clear-rules, #btn-view-rules").removeClass("disabled");
    }
});
</script>
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn d-none disabled" name="btn-action" id="btn-action" type="submit" form="ftb_employeesearch" formaction="<?= HtmlEncode(GetUrl("tbemployeelist")) ?>" data-ajax="<?= $Page->UseAjaxActions ? "true" : "false" ?>"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_employeesearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn d-none disabled" name="btn-reset" id="btn-reset" type="button" form="ftb_employeesearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_employee");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
