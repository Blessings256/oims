<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbUnitOfMeasureSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_unit_of_measure: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var ftb_unit_of_measuresearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_unit_of_measuresearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["id", [ew.Validators.integer], fields.id.isInvalid],
            ["y_id", [ew.Validators.between], false],
            ["uom_full_name", [], fields.uom_full_name.isInvalid],
            ["y_uom_full_name", [ew.Validators.between], false],
            ["short_form", [], fields.short_form.isInvalid],
            ["y_short_form", [ew.Validators.between], false]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_unit_of_measuresearch" id="ftb_unit_of_measuresearch" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_unit_of_measure">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<div class="ew-search-div"><!-- page* -->
<?php if ($Page->id->Visible) { // id ?>
    <div id="r_id" class="row"<?= $Page->id->rowAttributes() ?>>
        <label for="x_id" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_unit_of_measure_id"><?= $Page->id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_id" id="z_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_unit_of_measure_id" class="ew-search-field">
<input type="<?= $Page->id->getInputTextType() ?>" name="x_id" id="x_id" data-table="tb_unit_of_measure" data-field="x_id" value="<?= $Page->id->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_unit_of_measure_id" class="ew-search-field2 d-none">
<input type="<?= $Page->id->getInputTextType() ?>" name="y_id" id="y_id" data-table="tb_unit_of_measure" data-field="x_id" value="<?= $Page->id->EditValue2 ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->uom_full_name->Visible) { // uom_full_name ?>
    <div id="r_uom_full_name" class="row"<?= $Page->uom_full_name->rowAttributes() ?>>
        <label for="x_uom_full_name" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_unit_of_measure_uom_full_name"><?= $Page->uom_full_name->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->uom_full_name->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_uom_full_name" id="z_uom_full_name" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->uom_full_name->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->uom_full_name->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_unit_of_measure_uom_full_name" class="ew-search-field">
<input type="<?= $Page->uom_full_name->getInputTextType() ?>" name="x_uom_full_name" id="x_uom_full_name" data-table="tb_unit_of_measure" data-field="x_uom_full_name" value="<?= $Page->uom_full_name->EditValue ?>" maxlength="100" placeholder="<?= HtmlEncode($Page->uom_full_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->uom_full_name->formatPattern()) ?>"<?= $Page->uom_full_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->uom_full_name->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_unit_of_measure_uom_full_name" class="ew-search-field2 d-none">
<input type="<?= $Page->uom_full_name->getInputTextType() ?>" name="y_uom_full_name" id="y_uom_full_name" data-table="tb_unit_of_measure" data-field="x_uom_full_name" value="<?= $Page->uom_full_name->EditValue2 ?>" maxlength="100" placeholder="<?= HtmlEncode($Page->uom_full_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->uom_full_name->formatPattern()) ?>"<?= $Page->uom_full_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->uom_full_name->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->short_form->Visible) { // short_form ?>
    <div id="r_short_form" class="row"<?= $Page->short_form->rowAttributes() ?>>
        <label for="x_short_form" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_unit_of_measure_short_form"><?= $Page->short_form->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->short_form->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_short_form" id="z_short_form" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->short_form->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->short_form->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_unit_of_measure_short_form" class="ew-search-field">
<input type="<?= $Page->short_form->getInputTextType() ?>" name="x_short_form" id="x_short_form" data-table="tb_unit_of_measure" data-field="x_short_form" value="<?= $Page->short_form->EditValue ?>" maxlength="5" placeholder="<?= HtmlEncode($Page->short_form->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->short_form->formatPattern()) ?>"<?= $Page->short_form->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->short_form->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_unit_of_measure_short_form" class="ew-search-field2 d-none">
<input type="<?= $Page->short_form->getInputTextType() ?>" name="y_short_form" id="y_short_form" data-table="tb_unit_of_measure" data-field="x_short_form" value="<?= $Page->short_form->EditValue2 ?>" maxlength="5" placeholder="<?= HtmlEncode($Page->short_form->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->short_form->formatPattern()) ?>"<?= $Page->short_form->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->short_form->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_unit_of_measuresearch"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_unit_of_measuresearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" form="ftb_unit_of_measuresearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_unit_of_measure");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
