<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbUnitOfMeasureEdit = &$Page;
?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="edit">
<form name="ftb_unit_of_measureedit" id="ftb_unit_of_measureedit" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_unit_of_measure: currentTable } });
var currentPageID = ew.PAGE_ID = "edit";
var currentForm;
var ftb_unit_of_measureedit;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_unit_of_measureedit")
        .setPageId("edit")

        // Add fields
        .setFields([
            ["id", [fields.id.visible && fields.id.required ? ew.Validators.required(fields.id.caption) : null], fields.id.isInvalid],
            ["uom_full_name", [fields.uom_full_name.visible && fields.uom_full_name.required ? ew.Validators.required(fields.uom_full_name.caption) : null], fields.uom_full_name.isInvalid],
            ["short_form", [fields.short_form.visible && fields.short_form.required ? ew.Validators.required(fields.short_form.caption) : null], fields.short_form.isInvalid],
            ["description", [fields.description.visible && fields.description.required ? ew.Validators.required(fields.description.caption) : null], fields.description.isInvalid],
            ["entry_date", [fields.entry_date.visible && fields.entry_date.required ? ew.Validators.required(fields.entry_date.caption) : null], fields.entry_date.isInvalid],
            ["last_modified", [fields.last_modified.visible && fields.last_modified.required ? ew.Validators.required(fields.last_modified.caption) : null], fields.last_modified.isInvalid],
            ["entered_by", [fields.entered_by.visible && fields.entered_by.required ? ew.Validators.required(fields.entered_by.caption) : null], fields.entered_by.isInvalid],
            ["modified_by", [fields.modified_by.visible && fields.modified_by.required ? ew.Validators.required(fields.modified_by.caption) : null], fields.modified_by.isInvalid]
        ])

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "entered_by": <?= $Page->entered_by->toClientList($Page) ?>,
            "modified_by": <?= $Page->modified_by->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_unit_of_measure">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<?php if (IsJsonResponse()) { ?>
<input type="hidden" name="json" value="1">
<?php } ?>
<input type="hidden" name="<?= $Page->OldKeyName ?>" value="<?= $Page->OldKey ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($Page->id->Visible) { // id ?>
    <div id="r_id"<?= $Page->id->rowAttributes() ?>>
        <label id="elh_tb_unit_of_measure_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->id->caption() ?><?= $Page->id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->id->cellAttributes() ?>>
<span id="el_tb_unit_of_measure_id">
<span<?= $Page->id->viewAttributes() ?>>
<input type="text" readonly class="form-control-plaintext" value="<?= HtmlEncode(RemoveHtml($Page->id->getDisplayValue($Page->id->EditValue))) ?>"></span>
<input type="hidden" data-table="tb_unit_of_measure" data-field="x_id" data-hidden="1" name="x_id" id="x_id" value="<?= HtmlEncode($Page->id->CurrentValue) ?>">
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->uom_full_name->Visible) { // uom_full_name ?>
    <div id="r_uom_full_name"<?= $Page->uom_full_name->rowAttributes() ?>>
        <label id="elh_tb_unit_of_measure_uom_full_name" for="x_uom_full_name" class="<?= $Page->LeftColumnClass ?>"><?= $Page->uom_full_name->caption() ?><?= $Page->uom_full_name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->uom_full_name->cellAttributes() ?>>
<span id="el_tb_unit_of_measure_uom_full_name">
<input type="<?= $Page->uom_full_name->getInputTextType() ?>" name="x_uom_full_name" id="x_uom_full_name" data-table="tb_unit_of_measure" data-field="x_uom_full_name" value="<?= $Page->uom_full_name->EditValue ?>" maxlength="100" placeholder="<?= HtmlEncode($Page->uom_full_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->uom_full_name->formatPattern()) ?>"<?= $Page->uom_full_name->editAttributes() ?> aria-describedby="x_uom_full_name_help">
<?= $Page->uom_full_name->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->uom_full_name->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->short_form->Visible) { // short_form ?>
    <div id="r_short_form"<?= $Page->short_form->rowAttributes() ?>>
        <label id="elh_tb_unit_of_measure_short_form" for="x_short_form" class="<?= $Page->LeftColumnClass ?>"><?= $Page->short_form->caption() ?><?= $Page->short_form->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->short_form->cellAttributes() ?>>
<span id="el_tb_unit_of_measure_short_form">
<input type="<?= $Page->short_form->getInputTextType() ?>" name="x_short_form" id="x_short_form" data-table="tb_unit_of_measure" data-field="x_short_form" value="<?= $Page->short_form->EditValue ?>" maxlength="5" placeholder="<?= HtmlEncode($Page->short_form->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->short_form->formatPattern()) ?>"<?= $Page->short_form->editAttributes() ?> aria-describedby="x_short_form_help">
<?= $Page->short_form->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->short_form->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->description->Visible) { // description ?>
    <div id="r_description"<?= $Page->description->rowAttributes() ?>>
        <label id="elh_tb_unit_of_measure_description" for="x_description" class="<?= $Page->LeftColumnClass ?>"><?= $Page->description->caption() ?><?= $Page->description->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->description->cellAttributes() ?>>
<span id="el_tb_unit_of_measure_description">
<textarea data-table="tb_unit_of_measure" data-field="x_description" name="x_description" id="x_description" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->description->getPlaceHolder()) ?>"<?= $Page->description->editAttributes() ?> aria-describedby="x_description_help"><?= $Page->description->EditValue ?></textarea>
<?= $Page->description->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->description->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_unit_of_measureedit"><?= $Language->phrase("SaveBtn") ?></button>
<?php if (IsJsonResponse()) { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-bs-dismiss="modal"><?= $Language->phrase("CancelBtn") ?></button>
<?php } else { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_unit_of_measureedit" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
<?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_unit_of_measure");
});
</script>
<script>
loadjs.ready("load", function () {
    // Startup script
    // Write your table-specific startup script here, no need to add script tags.
    $('[class="form-control-plaintext"]').attr("size","0");
    $('[class="form-control-plaintext"]').removeClass('form-control-plaintext').addClass('form-control');
    $('.form-control[type="tel"]').addClass('form-control-sm w-100');
    $('.form-control[type="text"]').addClass('form-control-sm w-100');
    $('.form-control[type="email"]').addClass('form-control-sm w-100');
    $('.form-control.tt-input[type="text"]').addClass('form-control-sm w-100');
    $('[class="form-select ew-select"]').addClass('form-select-sm w-100')
    $('[class="custom-select ew-custom-select"]').addClass('w-100').removeClass('ew-custom-select');
});
</script>
