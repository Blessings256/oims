<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbChildDelete = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_child: currentTable } });
var currentPageID = ew.PAGE_ID = "delete";
var currentForm;
var ftb_childdelete;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_childdelete")
        .setPageId("delete")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_childdelete" id="ftb_childdelete" class="ew-form ew-delete-form" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_child">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($Page->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?= HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid <?= $Page->TableGridClass ?>">
<div class="card-body ew-grid-middle-panel <?= $Page->TableContainerClass ?>" style="<?= $Page->TableContainerStyle ?>">
<table class="<?= $Page->TableClass ?>">
    <thead>
    <tr class="ew-table-header">
<?php if ($Page->id->Visible) { // id ?>
        <th class="<?= $Page->id->headerCellClass() ?>"><span id="elh_tb_child_id" class="tb_child_id"><?= $Page->id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->first_name->Visible) { // first_name ?>
        <th class="<?= $Page->first_name->headerCellClass() ?>"><span id="elh_tb_child_first_name" class="tb_child_first_name"><?= $Page->first_name->caption() ?></span></th>
<?php } ?>
<?php if ($Page->last_name->Visible) { // last_name ?>
        <th class="<?= $Page->last_name->headerCellClass() ?>"><span id="elh_tb_child_last_name" class="tb_child_last_name"><?= $Page->last_name->caption() ?></span></th>
<?php } ?>
<?php if ($Page->date_of_birth->Visible) { // date_of_birth ?>
        <th class="<?= $Page->date_of_birth->headerCellClass() ?>"><span id="elh_tb_child_date_of_birth" class="tb_child_date_of_birth"><?= $Page->date_of_birth->caption() ?></span></th>
<?php } ?>
<?php if ($Page->gender->Visible) { // gender ?>
        <th class="<?= $Page->gender->headerCellClass() ?>"><span id="elh_tb_child_gender" class="tb_child_gender"><?= $Page->gender->caption() ?></span></th>
<?php } ?>
<?php if ($Page->guardian_name->Visible) { // guardian_name ?>
        <th class="<?= $Page->guardian_name->headerCellClass() ?>"><span id="elh_tb_child_guardian_name" class="tb_child_guardian_name"><?= $Page->guardian_name->caption() ?></span></th>
<?php } ?>
<?php if ($Page->guardian_contact->Visible) { // guardian_contact ?>
        <th class="<?= $Page->guardian_contact->headerCellClass() ?>"><span id="elh_tb_child_guardian_contact" class="tb_child_guardian_contact"><?= $Page->guardian_contact->caption() ?></span></th>
<?php } ?>
<?php if ($Page->address->Visible) { // address ?>
        <th class="<?= $Page->address->headerCellClass() ?>"><span id="elh_tb_child_address" class="tb_child_address"><?= $Page->address->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <th class="<?= $Page->entry_date->headerCellClass() ?>"><span id="elh_tb_child_entry_date" class="tb_child_entry_date"><?= $Page->entry_date->caption() ?></span></th>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <th class="<?= $Page->last_modified->headerCellClass() ?>"><span id="elh_tb_child_last_modified" class="tb_child_last_modified"><?= $Page->last_modified->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <th class="<?= $Page->entered_by->headerCellClass() ?>"><span id="elh_tb_child_entered_by" class="tb_child_entered_by"><?= $Page->entered_by->caption() ?></span></th>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <th class="<?= $Page->modified_by->headerCellClass() ?>"><span id="elh_tb_child_modified_by" class="tb_child_modified_by"><?= $Page->modified_by->caption() ?></span></th>
<?php } ?>
    </tr>
    </thead>
    <tbody>
<?php
$Page->RecordCount = 0;
$i = 0;
while (!$Page->Recordset->EOF) {
    $Page->RecordCount++;
    $Page->RowCount++;

    // Set row properties
    $Page->resetAttributes();
    $Page->RowType = ROWTYPE_VIEW; // View

    // Get the field contents
    $Page->loadRowValues($Page->Recordset);

    // Render row
    $Page->renderRow();
?>
    <tr <?= $Page->rowAttributes() ?>>
<?php if ($Page->id->Visible) { // id ?>
        <td<?= $Page->id->cellAttributes() ?>>
<span id="">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->first_name->Visible) { // first_name ?>
        <td<?= $Page->first_name->cellAttributes() ?>>
<span id="">
<span<?= $Page->first_name->viewAttributes() ?>>
<?= $Page->first_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->last_name->Visible) { // last_name ?>
        <td<?= $Page->last_name->cellAttributes() ?>>
<span id="">
<span<?= $Page->last_name->viewAttributes() ?>>
<?= $Page->last_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->date_of_birth->Visible) { // date_of_birth ?>
        <td<?= $Page->date_of_birth->cellAttributes() ?>>
<span id="">
<span<?= $Page->date_of_birth->viewAttributes() ?>>
<?= $Page->date_of_birth->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->gender->Visible) { // gender ?>
        <td<?= $Page->gender->cellAttributes() ?>>
<span id="">
<span<?= $Page->gender->viewAttributes() ?>>
<?= $Page->gender->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->guardian_name->Visible) { // guardian_name ?>
        <td<?= $Page->guardian_name->cellAttributes() ?>>
<span id="">
<span<?= $Page->guardian_name->viewAttributes() ?>>
<?= $Page->guardian_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->guardian_contact->Visible) { // guardian_contact ?>
        <td<?= $Page->guardian_contact->cellAttributes() ?>>
<span id="">
<span<?= $Page->guardian_contact->viewAttributes() ?>>
<?= $Page->guardian_contact->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->address->Visible) { // address ?>
        <td<?= $Page->address->cellAttributes() ?>>
<span id="">
<span<?= $Page->address->viewAttributes() ?>>
<?= $Page->address->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <td<?= $Page->entry_date->cellAttributes() ?>>
<span id="">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <td<?= $Page->last_modified->cellAttributes() ?>>
<span id="">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <td<?= $Page->entered_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <td<?= $Page->modified_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
    </tr>
<?php
    $Page->Recordset->moveNext();
}
$Page->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div class="ew-buttons ew-desktop-buttons">
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?= $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
