<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbImmunisationDelete = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_immunisation: currentTable } });
var currentPageID = ew.PAGE_ID = "delete";
var currentForm;
var ftb_immunisationdelete;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_immunisationdelete")
        .setPageId("delete")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_immunisationdelete" id="ftb_immunisationdelete" class="ew-form ew-delete-form" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_immunisation">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($Page->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?= HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid <?= $Page->TableGridClass ?>">
<div class="card-body ew-grid-middle-panel <?= $Page->TableContainerClass ?>" style="<?= $Page->TableContainerStyle ?>">
<table class="<?= $Page->TableClass ?>">
    <thead>
    <tr class="ew-table-header">
<?php if ($Page->id->Visible) { // id ?>
        <th class="<?= $Page->id->headerCellClass() ?>"><span id="elh_tb_immunisation_id" class="tb_immunisation_id"><?= $Page->id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->vaccination_date->Visible) { // vaccination_date ?>
        <th class="<?= $Page->vaccination_date->headerCellClass() ?>"><span id="elh_tb_immunisation_vaccination_date" class="tb_immunisation_vaccination_date"><?= $Page->vaccination_date->caption() ?></span></th>
<?php } ?>
<?php if ($Page->child_id->Visible) { // child_id ?>
        <th class="<?= $Page->child_id->headerCellClass() ?>"><span id="elh_tb_immunisation_child_id" class="tb_immunisation_child_id"><?= $Page->child_id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->vaccine_id->Visible) { // vaccine_id ?>
        <th class="<?= $Page->vaccine_id->headerCellClass() ?>"><span id="elh_tb_immunisation_vaccine_id" class="tb_immunisation_vaccine_id"><?= $Page->vaccine_id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->dose_cycle->Visible) { // dose_cycle ?>
        <th class="<?= $Page->dose_cycle->headerCellClass() ?>"><span id="elh_tb_immunisation_dose_cycle" class="tb_immunisation_dose_cycle"><?= $Page->dose_cycle->caption() ?></span></th>
<?php } ?>
<?php if ($Page->next_vaccination_date->Visible) { // next_vaccination_date ?>
        <th class="<?= $Page->next_vaccination_date->headerCellClass() ?>"><span id="elh_tb_immunisation_next_vaccination_date" class="tb_immunisation_next_vaccination_date"><?= $Page->next_vaccination_date->caption() ?></span></th>
<?php } ?>
<?php if ($Page->administered_by->Visible) { // administered_by ?>
        <th class="<?= $Page->administered_by->headerCellClass() ?>"><span id="elh_tb_immunisation_administered_by" class="tb_immunisation_administered_by"><?= $Page->administered_by->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <th class="<?= $Page->entry_date->headerCellClass() ?>"><span id="elh_tb_immunisation_entry_date" class="tb_immunisation_entry_date"><?= $Page->entry_date->caption() ?></span></th>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <th class="<?= $Page->last_modified->headerCellClass() ?>"><span id="elh_tb_immunisation_last_modified" class="tb_immunisation_last_modified"><?= $Page->last_modified->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <th class="<?= $Page->entered_by->headerCellClass() ?>"><span id="elh_tb_immunisation_entered_by" class="tb_immunisation_entered_by"><?= $Page->entered_by->caption() ?></span></th>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <th class="<?= $Page->modified_by->headerCellClass() ?>"><span id="elh_tb_immunisation_modified_by" class="tb_immunisation_modified_by"><?= $Page->modified_by->caption() ?></span></th>
<?php } ?>
    </tr>
    </thead>
    <tbody>
<?php
$Page->RecordCount = 0;
$i = 0;
while (!$Page->Recordset->EOF) {
    $Page->RecordCount++;
    $Page->RowCount++;

    // Set row properties
    $Page->resetAttributes();
    $Page->RowType = ROWTYPE_VIEW; // View

    // Get the field contents
    $Page->loadRowValues($Page->Recordset);

    // Render row
    $Page->renderRow();
?>
    <tr <?= $Page->rowAttributes() ?>>
<?php if ($Page->id->Visible) { // id ?>
        <td<?= $Page->id->cellAttributes() ?>>
<span id="">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->vaccination_date->Visible) { // vaccination_date ?>
        <td<?= $Page->vaccination_date->cellAttributes() ?>>
<span id="">
<span<?= $Page->vaccination_date->viewAttributes() ?>>
<?= $Page->vaccination_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->child_id->Visible) { // child_id ?>
        <td<?= $Page->child_id->cellAttributes() ?>>
<span id="">
<span<?= $Page->child_id->viewAttributes() ?>>
<?= $Page->child_id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->vaccine_id->Visible) { // vaccine_id ?>
        <td<?= $Page->vaccine_id->cellAttributes() ?>>
<span id="">
<span<?= $Page->vaccine_id->viewAttributes() ?>>
<?= $Page->vaccine_id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->dose_cycle->Visible) { // dose_cycle ?>
        <td<?= $Page->dose_cycle->cellAttributes() ?>>
<span id="">
<span<?= $Page->dose_cycle->viewAttributes() ?>>
<?= $Page->dose_cycle->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->next_vaccination_date->Visible) { // next_vaccination_date ?>
        <td<?= $Page->next_vaccination_date->cellAttributes() ?>>
<span id="">
<span<?= $Page->next_vaccination_date->viewAttributes() ?>>
<?= $Page->next_vaccination_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->administered_by->Visible) { // administered_by ?>
        <td<?= $Page->administered_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->administered_by->viewAttributes() ?>>
<?= $Page->administered_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <td<?= $Page->entry_date->cellAttributes() ?>>
<span id="">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <td<?= $Page->last_modified->cellAttributes() ?>>
<span id="">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <td<?= $Page->entered_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <td<?= $Page->modified_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
    </tr>
<?php
    $Page->Recordset->moveNext();
}
$Page->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div class="ew-buttons ew-desktop-buttons">
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?= $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
