<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbImmunisationSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_immunisation: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var ftb_immunisationsearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_immunisationsearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["id", [ew.Validators.integer], fields.id.isInvalid],
            ["y_id", [ew.Validators.between], false],
            ["vaccination_date", [ew.Validators.datetime(fields.vaccination_date.clientFormatPattern)], fields.vaccination_date.isInvalid],
            ["y_vaccination_date", [ew.Validators.between], false],
            ["child_id", [], fields.child_id.isInvalid],
            ["y_child_id", [ew.Validators.between], false],
            ["vaccine_id", [], fields.vaccine_id.isInvalid],
            ["y_vaccine_id", [ew.Validators.between], false],
            ["dose_cycle", [], fields.dose_cycle.isInvalid],
            ["y_dose_cycle", [ew.Validators.between], false],
            ["next_vaccination_date", [ew.Validators.datetime(fields.next_vaccination_date.clientFormatPattern)], fields.next_vaccination_date.isInvalid],
            ["y_next_vaccination_date", [ew.Validators.between], false],
            ["administered_by", [], fields.administered_by.isInvalid],
            ["y_administered_by", [ew.Validators.between], false],
            ["remarks", [], fields.remarks.isInvalid],
            ["y_remarks", [ew.Validators.between], false]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setQueryBuilderLists({
            "child_id": <?= $Page->child_id->toClientList($Page) ?>,
            "vaccine_id": <?= $Page->vaccine_id->toClientList($Page) ?>,
            "dose_cycle": <?= $Page->dose_cycle->toClientList($Page) ?>,
            "administered_by": <?= $Page->administered_by->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_immunisationsearch" id="ftb_immunisationsearch" class="<?= $Page->FormClassName ?>" action="<?= HtmlEncode(GetUrl("tbimmunisationlist")) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_immunisation">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<input type="hidden" name="rules" value="<?= HtmlEncode($Page->getSessionRules()) ?>">
<template id="tpx_tb_immunisation_id" class="tb_immunisationsearch"><span id="el_tb_immunisation_id" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->id->getInputTextType() ?>" name="x_id" id="x_id" data-table="tb_immunisation" data-field="x_id" value="<?= $Page->id->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_immunisation_vaccination_date" class="tb_immunisationsearch"><span id="el_tb_immunisation_vaccination_date" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->vaccination_date->getInputTextType() ?>" name="x_vaccination_date" id="x_vaccination_date" data-table="tb_immunisation" data-field="x_vaccination_date" value="<?= $Page->vaccination_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->vaccination_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccination_date->formatPattern()) ?>"<?= $Page->vaccination_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->vaccination_date->getErrorMessage(false) ?></div>
<?php if (!$Page->vaccination_date->ReadOnly && !$Page->vaccination_date->Disabled && !isset($Page->vaccination_date->EditAttrs["readonly"]) && !isset($Page->vaccination_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_immunisationsearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_immunisationsearch", "x_vaccination_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_immunisation_child_id" class="tb_immunisationsearch"><span id="el_tb_immunisation_child_id" class="ew-search-field ew-search-field-single">
<?php
if (IsRTL()) {
    $Page->child_id->EditAttrs["dir"] = "rtl";
}
?>
<span id="as_x_child_id" class="ew-auto-suggest">
    <input type="<?= $Page->child_id->getInputTextType() ?>" class="form-control" name="sv_x_child_id" id="sv_x_child_id" value="<?= RemoveHtml($Page->child_id->EditValue) ?>" autocomplete="off" placeholder="<?= HtmlEncode($Page->child_id->getPlaceHolder()) ?>" data-placeholder="<?= HtmlEncode($Page->child_id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->child_id->formatPattern()) ?>"<?= $Page->child_id->editAttributes() ?>>
</span>
<selection-list hidden class="form-control" data-table="tb_immunisation" data-field="x_child_id" data-input="sv_x_child_id" data-value-separator="<?= $Page->child_id->displayValueSeparatorAttribute() ?>" name="x_child_id" id="x_child_id" value="<?= HtmlEncode($Page->child_id->AdvancedSearch->SearchValue) ?>"></selection-list>
<div class="invalid-feedback"><?= $Page->child_id->getErrorMessage(false) ?></div>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    ftb_immunisationsearch.createAutoSuggest(Object.assign({"id":"x_child_id","forceSelect":false}, { lookupAllDisplayFields: <?= $Page->child_id->Lookup->LookupAllDisplayFields ? "true" : "false" ?> }, ew.vars.tables.tb_immunisation.fields.child_id.autoSuggestOptions));
});
</script>
<?= $Page->child_id->Lookup->getParamTag($Page, "p_x_child_id") ?>
</span></template>
<template id="tpx_tb_immunisation_vaccine_id" class="tb_immunisationsearch"><span id="el_tb_immunisation_vaccine_id" class="ew-search-field ew-search-field-single">
<?php
if (IsRTL()) {
    $Page->vaccine_id->EditAttrs["dir"] = "rtl";
}
?>
<span id="as_x_vaccine_id" class="ew-auto-suggest">
    <input type="<?= $Page->vaccine_id->getInputTextType() ?>" class="form-control" name="sv_x_vaccine_id" id="sv_x_vaccine_id" value="<?= RemoveHtml($Page->vaccine_id->EditValue) ?>" autocomplete="off" placeholder="<?= HtmlEncode($Page->vaccine_id->getPlaceHolder()) ?>" data-placeholder="<?= HtmlEncode($Page->vaccine_id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_id->formatPattern()) ?>"<?= $Page->vaccine_id->editAttributes() ?>>
</span>
<selection-list hidden class="form-control" data-table="tb_immunisation" data-field="x_vaccine_id" data-input="sv_x_vaccine_id" data-value-separator="<?= $Page->vaccine_id->displayValueSeparatorAttribute() ?>" name="x_vaccine_id" id="x_vaccine_id" value="<?= HtmlEncode($Page->vaccine_id->AdvancedSearch->SearchValue) ?>"></selection-list>
<div class="invalid-feedback"><?= $Page->vaccine_id->getErrorMessage(false) ?></div>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    ftb_immunisationsearch.createAutoSuggest(Object.assign({"id":"x_vaccine_id","forceSelect":false}, { lookupAllDisplayFields: <?= $Page->vaccine_id->Lookup->LookupAllDisplayFields ? "true" : "false" ?> }, ew.vars.tables.tb_immunisation.fields.vaccine_id.autoSuggestOptions));
});
</script>
<?= $Page->vaccine_id->Lookup->getParamTag($Page, "p_x_vaccine_id") ?>
</span></template>
<template id="tpx_tb_immunisation_dose_cycle" class="tb_immunisationsearch"><span id="el_tb_immunisation_dose_cycle" class="ew-search-field ew-search-field-single">
    <select
        id="x_dose_cycle"
        name="x_dose_cycle"
        class="form-select ew-select<?= $Page->dose_cycle->isInvalidClass() ?>"
        <?php if (!$Page->dose_cycle->IsNativeSelect) { ?>
        data-select2-id="ftb_immunisationsearch_x_dose_cycle"
        <?php } ?>
        data-table="tb_immunisation"
        data-field="x_dose_cycle"
        data-value-separator="<?= $Page->dose_cycle->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->dose_cycle->getPlaceHolder()) ?>"
        <?= $Page->dose_cycle->editAttributes() ?>>
        <?= $Page->dose_cycle->selectOptionListHtml("x_dose_cycle") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->dose_cycle->getErrorMessage(false) ?></div>
<?php if (!$Page->dose_cycle->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    var options = { name: "x_dose_cycle", selectId: "ftb_immunisationsearch_x_dose_cycle" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_immunisationsearch.lists.dose_cycle?.lookupOptions.length) {
        options.data = { id: "x_dose_cycle", form: "ftb_immunisationsearch" };
    } else {
        options.ajax = { id: "x_dose_cycle", form: "ftb_immunisationsearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_immunisation.fields.dose_cycle.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_immunisation_next_vaccination_date" class="tb_immunisationsearch"><span id="el_tb_immunisation_next_vaccination_date" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->next_vaccination_date->getInputTextType() ?>" name="x_next_vaccination_date" id="x_next_vaccination_date" data-table="tb_immunisation" data-field="x_next_vaccination_date" value="<?= $Page->next_vaccination_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->next_vaccination_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->next_vaccination_date->formatPattern()) ?>"<?= $Page->next_vaccination_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->next_vaccination_date->getErrorMessage(false) ?></div>
<?php if (!$Page->next_vaccination_date->ReadOnly && !$Page->next_vaccination_date->Disabled && !isset($Page->next_vaccination_date->EditAttrs["readonly"]) && !isset($Page->next_vaccination_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_immunisationsearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_immunisationsearch", "x_next_vaccination_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_immunisation_administered_by" class="tb_immunisationsearch"><span id="el_tb_immunisation_administered_by" class="ew-search-field ew-search-field-single">
    <select
        id="x_administered_by"
        name="x_administered_by"
        class="form-select ew-select<?= $Page->administered_by->isInvalidClass() ?>"
        <?php if (!$Page->administered_by->IsNativeSelect) { ?>
        data-select2-id="ftb_immunisationsearch_x_administered_by"
        <?php } ?>
        data-table="tb_immunisation"
        data-field="x_administered_by"
        data-value-separator="<?= $Page->administered_by->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->administered_by->getPlaceHolder()) ?>"
        <?= $Page->administered_by->editAttributes() ?>>
        <?= $Page->administered_by->selectOptionListHtml("x_administered_by") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->administered_by->getErrorMessage(false) ?></div>
<?= $Page->administered_by->Lookup->getParamTag($Page, "p_x_administered_by") ?>
<?php if (!$Page->administered_by->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    var options = { name: "x_administered_by", selectId: "ftb_immunisationsearch_x_administered_by" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_immunisationsearch.lists.administered_by?.lookupOptions.length) {
        options.data = { id: "x_administered_by", form: "ftb_immunisationsearch" };
    } else {
        options.ajax = { id: "x_administered_by", form: "ftb_immunisationsearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_immunisation.fields.administered_by.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_immunisation_remarks" class="tb_immunisationsearch"><span id="el_tb_immunisation_remarks" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->remarks->getInputTextType() ?>" name="x_remarks" id="x_remarks" data-table="tb_immunisation" data-field="x_remarks" value="<?= $Page->remarks->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->remarks->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->remarks->formatPattern()) ?>"<?= $Page->remarks->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->remarks->getErrorMessage(false) ?></div>
</span></template>
<div id="tb_immunisation_query_builder" class="query-builder mb-3"></div>
<div class="btn-group mb-3 query-btn-group"></div>
<button type="button" id="btn-view-rules" class="btn btn-primary d-none disabled" title="<?= HtmlEncode($Language->phrase("View", true)) ?>"><i class="fa-solid fa-eye ew-icon"></i></button>
<button type="button" id="btn-clear-rules" class="btn btn-primary d-none disabled" title="<?= HtmlEncode($Language->phrase("Clear", true)) ?>"><i class="fa-solid fa-xmark ew-icon"></i></button>
<script>
// Filter builder
loadjs.ready(["wrapper", "head"], () => {
    let filters = [
            {
                id: "id",
                type: "integer",
                label: currentTable.fields.id.caption,
                operators: currentTable.fields.id.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                validation: ew.getQueryBuilderFilterValidation(ftb_immunisationsearch.fields.id.validators),
                data: {
                    format: currentTable.fields.id.clientFormatPattern
                }
            },
            {
                id: "vaccination_date",
                type: "datetime",
                label: currentTable.fields.vaccination_date.caption,
                operators: currentTable.fields.vaccination_date.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_immunisationsearch.fields.vaccination_date.validators),
                data: {
                    format: currentTable.fields.vaccination_date.clientFormatPattern
                }
            },
            {
                id: "child_id",
                type: "string",
                label: currentTable.fields.child_id.caption,
                operators: currentTable.fields.child_id.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_immunisationsearch.fields.child_id.validators),
                data: {
                    format: currentTable.fields.child_id.clientFormatPattern
                }
            },
            {
                id: "vaccine_id",
                type: "string",
                label: currentTable.fields.vaccine_id.caption,
                operators: currentTable.fields.vaccine_id.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_immunisationsearch.fields.vaccine_id.validators),
                data: {
                    format: currentTable.fields.vaccine_id.clientFormatPattern
                }
            },
            {
                id: "dose_cycle",
                type: "string",
                label: currentTable.fields.dose_cycle.caption,
                operators: currentTable.fields.dose_cycle.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_immunisationsearch.fields.dose_cycle.validators),
                data: {
                    format: currentTable.fields.dose_cycle.clientFormatPattern
                }
            },
            {
                id: "next_vaccination_date",
                type: "datetime",
                label: currentTable.fields.next_vaccination_date.caption,
                operators: currentTable.fields.next_vaccination_date.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_immunisationsearch.fields.next_vaccination_date.validators),
                data: {
                    format: currentTable.fields.next_vaccination_date.clientFormatPattern
                }
            },
            {
                id: "administered_by",
                type: "integer",
                label: currentTable.fields.administered_by.caption,
                operators: currentTable.fields.administered_by.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_immunisationsearch.fields.administered_by.validators),
                data: {
                    format: currentTable.fields.administered_by.clientFormatPattern
                }
            },
            {
                id: "remarks",
                type: "string",
                label: currentTable.fields.remarks.caption,
                operators: currentTable.fields.remarks.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_immunisationsearch.fields.remarks.validators),
                data: {
                    format: currentTable.fields.remarks.clientFormatPattern
                }
            },
        ],
        $ = jQuery,
        $qb = $("#tb_immunisation_query_builder"),
        args = {},
        rules = ew.parseJson($("#ftb_immunisationsearch input[name=rules]").val()),
        queryBuilderOptions = Object.assign({}, ew.queryBuilderOptions),
        allowViewRules = queryBuilderOptions.allowViewRules,
        allowClearRules = queryBuilderOptions.allowClearRules,
        hasRules = group => Array.isArray(group?.rules) && group.rules.length > 0,
        getRules = () => $qb.queryBuilder("getRules", { skip_empty: true }),
        getSql = () => $qb.queryBuilder("getSQL", false, false, rules)?.sql;
    delete queryBuilderOptions.allowViewRules;
    delete queryBuilderOptions.allowClearRules;
    args.options = ew.deepAssign({
        plugins: Object.assign({}, ew.queryBuilderPlugins),
        lang: ew.language.phrase("querybuilderjs"),
        select_placeholder: ew.language.phrase("PleaseSelect"),
        inputs_separator: `<div class="d-inline-flex ms-2 me-2">${ew.language.phrase("AND")}</div>`, // For "between"
        filters,
        rules
    }, queryBuilderOptions);
    $qb.trigger("querybuilder", [args]);
    $qb.queryBuilder(args.options).on("rulesChanged.queryBuilder", () => {
        let rules = getRules();
        !ew.DEBUG || console.log(rules, getSql());
        $("#btn-reset, #btn-action, #btn-clear-rules, #btn-view-rules").toggleClass("disabled", !rules);
    }).on("afterCreateRuleInput.queryBuilder", function(e, rule) {
        let select = rule.$el.find(".rule-value-container").find("selection-list, select")[0];
        if (select) { // Selection list
            let id = select.dataset.field.replace("^x_", ""),
                form = ew.forms.get(select);
            form.updateList(select, undefined, undefined, true); // Update immediately
        }
    });
    $("#ftb_immunisationsearch").on("beforesubmit", function () {
        this.rules.value = JSON.stringify(getRules());
    });
    $("#btn-reset").toggleClass("d-none", false).on("click", () => {
        hasRules(rules) ? $qb.queryBuilder("setRules", rules) : $qb.queryBuilder("reset");
        return false;
    });
    $("#btn-action").toggleClass("d-none", false);
    if (allowClearRules) {
        $("#btn-clear-rules").appendTo(".query-btn-group").removeClass("d-none").on("click", () => $qb.queryBuilder("reset"));
    }
    if (allowViewRules) {
        $("#btn-view-rules").appendTo(".query-btn-group").removeClass("d-none").on("click", () => {
            let rules = getRules();
            if (hasRules(rules)) {
                let sql = getSql();
                ew.alert(sql ? '<pre class="text-start fs-6">' + sql + '</pre>' : '', "dark");
                !ew.DEBUG || console.log(rules, sql);
            } else {
                ew.alert(ew.language.phrase("EmptyLabel"));
            }
        });
    }
    if (hasRules(rules)) { // Enable buttons if rules exist initially
        $("#btn-reset, #btn-action, #btn-clear-rules, #btn-view-rules").removeClass("disabled");
    }
});
</script>
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn d-none disabled" name="btn-action" id="btn-action" type="submit" form="ftb_immunisationsearch" formaction="<?= HtmlEncode(GetUrl("tbimmunisationlist")) ?>" data-ajax="<?= $Page->UseAjaxActions ? "true" : "false" ?>"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_immunisationsearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn d-none disabled" name="btn-reset" id="btn-reset" type="button" form="ftb_immunisationsearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_immunisation");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
