<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbSystemUserSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_system_user: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var ftb_system_usersearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_system_usersearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["id", [ew.Validators.integer], fields.id.isInvalid],
            ["y_id", [ew.Validators.between], false],
            ["_username", [], fields._username.isInvalid],
            ["y__username", [ew.Validators.between], false],
            ["user_email", [], fields.user_email.isInvalid],
            ["y_user_email", [ew.Validators.between], false],
            ["activation_state", [], fields.activation_state.isInvalid],
            ["y_activation_state", [ew.Validators.between], false],
            ["user_role_id", [], fields.user_role_id.isInvalid],
            ["y_user_role_id", [ew.Validators.between], false]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "activation_state": <?= $Page->activation_state->toClientList($Page) ?>,
            "user_role_id": <?= $Page->user_role_id->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_system_usersearch" id="ftb_system_usersearch" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_system_user">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<div class="ew-search-div"><!-- page* -->
<?php if ($Page->id->Visible) { // id ?>
    <div id="r_id" class="row"<?= $Page->id->rowAttributes() ?>>
        <label for="x_id" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_system_user_id"><?= $Page->id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_id" id="z_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_system_user_id" class="ew-search-field">
<input type="<?= $Page->id->getInputTextType() ?>" name="x_id" id="x_id" data-table="tb_system_user" data-field="x_id" value="<?= $Page->id->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_system_user_id" class="ew-search-field2 d-none">
<input type="<?= $Page->id->getInputTextType() ?>" name="y_id" id="y_id" data-table="tb_system_user" data-field="x_id" value="<?= $Page->id->EditValue2 ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->_username->Visible) { // username ?>
    <div id="r__username" class="row"<?= $Page->_username->rowAttributes() ?>>
        <label for="x__username" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_system_user__username"><?= $Page->_username->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->_username->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z__username" id="z__username" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->_username->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->_username->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_system_user__username" class="ew-search-field">
<input type="<?= $Page->_username->getInputTextType() ?>" name="x__username" id="x__username" data-table="tb_system_user" data-field="x__username" value="<?= $Page->_username->EditValue ?>" maxlength="50" placeholder="<?= HtmlEncode($Page->_username->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->_username->formatPattern()) ?>"<?= $Page->_username->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->_username->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_system_user__username" class="ew-search-field2 d-none">
<input type="<?= $Page->_username->getInputTextType() ?>" name="y__username" id="y__username" data-table="tb_system_user" data-field="x__username" value="<?= $Page->_username->EditValue2 ?>" maxlength="50" placeholder="<?= HtmlEncode($Page->_username->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->_username->formatPattern()) ?>"<?= $Page->_username->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->_username->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->user_email->Visible) { // user_email ?>
    <div id="r_user_email" class="row"<?= $Page->user_email->rowAttributes() ?>>
        <label for="x_user_email" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_system_user_user_email"><?= $Page->user_email->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->user_email->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_user_email" id="z_user_email" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->user_email->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->user_email->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_system_user_user_email" class="ew-search-field">
<input type="<?= $Page->user_email->getInputTextType() ?>" name="x_user_email" id="x_user_email" data-table="tb_system_user" data-field="x_user_email" value="<?= $Page->user_email->EditValue ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->user_email->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->user_email->formatPattern()) ?>"<?= $Page->user_email->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->user_email->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_system_user_user_email" class="ew-search-field2 d-none">
<input type="<?= $Page->user_email->getInputTextType() ?>" name="y_user_email" id="y_user_email" data-table="tb_system_user" data-field="x_user_email" value="<?= $Page->user_email->EditValue2 ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->user_email->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->user_email->formatPattern()) ?>"<?= $Page->user_email->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->user_email->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->activation_state->Visible) { // activation_state ?>
    <div id="r_activation_state" class="row"<?= $Page->activation_state->rowAttributes() ?>>
        <label class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_system_user_activation_state"><?= $Page->activation_state->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->activation_state->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_activation_state" id="z_activation_state" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->activation_state->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->activation_state->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_system_user_activation_state" class="ew-search-field">
<template id="tp_x_activation_state">
    <div class="form-check">
        <input type="radio" class="form-check-input" data-table="tb_system_user" data-field="x_activation_state" name="x_activation_state" id="x_activation_state"<?= $Page->activation_state->editAttributes() ?>>
        <label class="form-check-label"></label>
    </div>
</template>
<div id="dsl_x_activation_state" class="ew-item-list"></div>
<selection-list hidden
    id="x_activation_state"
    name="x_activation_state"
    value="<?= HtmlEncode($Page->activation_state->AdvancedSearch->SearchValue) ?>"
    data-type="select-one"
    data-template="tp_x_activation_state"
    data-target="dsl_x_activation_state"
    data-repeatcolumn="5"
    class="form-control<?= $Page->activation_state->isInvalidClass() ?>"
    data-table="tb_system_user"
    data-field="x_activation_state"
    data-value-separator="<?= $Page->activation_state->displayValueSeparatorAttribute() ?>"
    <?= $Page->activation_state->editAttributes() ?>></selection-list>
<div class="invalid-feedback"><?= $Page->activation_state->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_system_user_activation_state" class="ew-search-field2 d-none">
<template id="tp_y_activation_state">
    <div class="form-check">
        <input type="radio" class="form-check-input" data-table="tb_system_user" data-field="x_activation_state" name="y_activation_state" id="y_activation_state"<?= $Page->activation_state->editAttributes() ?>>
        <label class="form-check-label"></label>
    </div>
</template>
<div id="dsl_y_activation_state" class="ew-item-list"></div>
<selection-list hidden
    id="y_activation_state"
    name="y_activation_state"
    value="<?= HtmlEncode($Page->activation_state->AdvancedSearch->SearchValue2) ?>"
    data-type="select-one"
    data-template="tp_y_activation_state"
    data-target="dsl_y_activation_state"
    data-repeatcolumn="5"
    class="form-control<?= $Page->activation_state->isInvalidClass() ?>"
    data-table="tb_system_user"
    data-field="x_activation_state"
    data-value-separator="<?= $Page->activation_state->displayValueSeparatorAttribute() ?>"
    <?= $Page->activation_state->editAttributes() ?>></selection-list>
<div class="invalid-feedback"><?= $Page->activation_state->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->user_role_id->Visible) { // user_role_id ?>
    <div id="r_user_role_id" class="row"<?= $Page->user_role_id->rowAttributes() ?>>
        <label for="x_user_role_id" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_system_user_user_role_id"><?= $Page->user_role_id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->user_role_id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_user_role_id" id="z_user_role_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->user_role_id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->user_role_id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_system_user_user_role_id" class="ew-search-field">
<?php if (!$Security->isAdmin() && $Security->isLoggedIn()) { // Non system admin ?>
<span class="form-control-plaintext"><?= $Page->user_role_id->getDisplayValue($Page->user_role_id->EditValue) ?></span>
<?php } else { ?>
    <select
        id="x_user_role_id"
        name="x_user_role_id"
        class="form-select ew-select<?= $Page->user_role_id->isInvalidClass() ?>"
        <?php if (!$Page->user_role_id->IsNativeSelect) { ?>
        data-select2-id="ftb_system_usersearch_x_user_role_id"
        <?php } ?>
        data-table="tb_system_user"
        data-field="x_user_role_id"
        data-value-separator="<?= $Page->user_role_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->user_role_id->getPlaceHolder()) ?>"
        <?= $Page->user_role_id->editAttributes() ?>>
        <?= $Page->user_role_id->selectOptionListHtml("x_user_role_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->user_role_id->getErrorMessage(false) ?></div>
<?= $Page->user_role_id->Lookup->getParamTag($Page, "p_x_user_role_id") ?>
<?php if (!$Page->user_role_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_system_usersearch", function() {
    var options = { name: "x_user_role_id", selectId: "ftb_system_usersearch_x_user_role_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_system_usersearch.lists.user_role_id?.lookupOptions.length) {
        options.data = { id: "x_user_role_id", form: "ftb_system_usersearch" };
    } else {
        options.ajax = { id: "x_user_role_id", form: "ftb_system_usersearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_system_user.fields.user_role_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
<?php } ?>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_system_user_user_role_id" class="ew-search-field2 d-none">
<?php if (!$Security->isAdmin() && $Security->isLoggedIn()) { // Non system admin ?>
<span class="form-control-plaintext"><?= $Page->user_role_id->getDisplayValue($Page->user_role_id->EditValue2) ?></span>
<?php } else { ?>
    <select
        id="y_user_role_id"
        name="y_user_role_id"
        class="form-select ew-select<?= $Page->user_role_id->isInvalidClass() ?>"
        <?php if (!$Page->user_role_id->IsNativeSelect) { ?>
        data-select2-id="ftb_system_usersearch_y_user_role_id"
        <?php } ?>
        data-table="tb_system_user"
        data-field="x_user_role_id"
        data-value-separator="<?= $Page->user_role_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->user_role_id->getPlaceHolder()) ?>"
        <?= $Page->user_role_id->editAttributes() ?>>
        <?= $Page->user_role_id->selectOptionListHtml("y_user_role_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->user_role_id->getErrorMessage(false) ?></div>
<?= $Page->user_role_id->Lookup->getParamTag($Page, "p_y_user_role_id") ?>
<?php if (!$Page->user_role_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_system_usersearch", function() {
    var options = { name: "y_user_role_id", selectId: "ftb_system_usersearch_y_user_role_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_system_usersearch.lists.user_role_id?.lookupOptions.length) {
        options.data = { id: "y_user_role_id", form: "ftb_system_usersearch" };
    } else {
        options.ajax = { id: "y_user_role_id", form: "ftb_system_usersearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_system_user.fields.user_role_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_system_usersearch"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_system_usersearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" form="ftb_system_usersearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_system_user");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
