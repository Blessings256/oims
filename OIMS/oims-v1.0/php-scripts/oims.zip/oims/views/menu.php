<?php

namespace PHPMaker2023\OIMS;

// Menu Language
if ($Language && function_exists(PROJECT_NAMESPACE . "Config") && $Language->LanguageFolder == Config("LANGUAGE_FOLDER")) {
    $MenuRelativePath = "";
    $MenuLanguage = &$Language;
} else { // Compat reports
    $LANGUAGE_FOLDER = "../lang/";
    $MenuRelativePath = "../";
    $MenuLanguage = Container("language");
}

// Navbar menu
$topMenu = new Menu("navbar", true, true);
$topMenu->addMenuItem(19, "mi_tb_immunisation", $MenuLanguage->MenuPhrase("19", "MenuText"), $MenuRelativePath . "tbimmunisationlist", -1, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_immunisation'), false, false, "", "", true, false);
$topMenu->addMenuItem(30, "mci_Master_Data", $MenuLanguage->MenuPhrase("30", "MenuText"), "", -1, "", IsLoggedIn(), false, true, "", "", true, false);
$topMenu->addMenuItem(5, "mi_tb_child", $MenuLanguage->MenuPhrase("5", "MenuText"), $MenuRelativePath . "tbchildlist", 30, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_child'), false, false, "", "", true, false);
$topMenu->addMenuItem(17, "mi_tb_vaccine", $MenuLanguage->MenuPhrase("17", "MenuText"), $MenuRelativePath . "tbvaccinelist", 30, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_vaccine'), false, false, "", "", true, false);
$topMenu->addMenuItem(18, "mi_tb_employee", $MenuLanguage->MenuPhrase("18", "MenuText"), $MenuRelativePath . "tbemployeelist", 30, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_employee'), false, false, "", "", true, false);
$topMenu->addMenuItem(13, "mci_Lookups", $MenuLanguage->MenuPhrase("13", "MenuText"), "", -1, "", IsLoggedIn(), false, true, "", "", true, false);
$topMenu->addMenuItem(7, "mi_tb_administration_site", $MenuLanguage->MenuPhrase("7", "MenuText"), $MenuRelativePath . "tbadministrationsitelist", 13, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_administration_site'), false, false, "", "", true, false);
$topMenu->addMenuItem(8, "mi_tb_administration_mode", $MenuLanguage->MenuPhrase("8", "MenuText"), $MenuRelativePath . "tbadministrationmodelist", 13, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_administration_mode'), false, false, "", "", true, false);
$topMenu->addMenuItem(16, "mi_tb_vaccine_form", $MenuLanguage->MenuPhrase("16", "MenuText"), $MenuRelativePath . "tbvaccineformlist", 13, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_vaccine_form'), false, false, "", "", true, false);
$topMenu->addMenuItem(15, "mi_tb_unit_of_measure", $MenuLanguage->MenuPhrase("15", "MenuText"), $MenuRelativePath . "tbunitofmeasurelist", 13, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_unit_of_measure'), false, false, "", "", true, false);
$topMenu->addMenuItem(14, "mci_System_Security", $MenuLanguage->MenuPhrase("14", "MenuText"), "", -1, "", IsLoggedIn(), false, true, "", "", true, false);
$topMenu->addMenuItem(6, "mi_tb_system_user", $MenuLanguage->MenuPhrase("6", "MenuText"), $MenuRelativePath . "tbsystemuserlist", 14, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_system_user'), false, false, "", "", true, false);
$topMenu->addMenuItem(3, "mi_tb_user_role", $MenuLanguage->MenuPhrase("3", "MenuText"), $MenuRelativePath . "tbuserrolelist", 14, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_user_role'), false, false, "", "", true, false);
$topMenu->addMenuItem(4, "mi_tb_user_role_permission", $MenuLanguage->MenuPhrase("4", "MenuText"), $MenuRelativePath . "tbuserrolepermissionlist", 14, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_user_role_permission'), false, false, "", "", true, false);
echo $topMenu->toScript();

// Sidebar menu
$sideMenu = new Menu("menu", true, false);
$sideMenu->addMenuItem(19, "mi_tb_immunisation", $MenuLanguage->MenuPhrase("19", "MenuText"), $MenuRelativePath . "tbimmunisationlist", -1, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_immunisation'), false, false, "", "", true, true);
$sideMenu->addMenuItem(30, "mci_Master_Data", $MenuLanguage->MenuPhrase("30", "MenuText"), "", -1, "", IsLoggedIn(), false, true, "", "", true, true);
$sideMenu->addMenuItem(5, "mi_tb_child", $MenuLanguage->MenuPhrase("5", "MenuText"), $MenuRelativePath . "tbchildlist", 30, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_child'), false, false, "", "", true, true);
$sideMenu->addMenuItem(17, "mi_tb_vaccine", $MenuLanguage->MenuPhrase("17", "MenuText"), $MenuRelativePath . "tbvaccinelist", 30, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_vaccine'), false, false, "", "", true, true);
$sideMenu->addMenuItem(18, "mi_tb_employee", $MenuLanguage->MenuPhrase("18", "MenuText"), $MenuRelativePath . "tbemployeelist", 30, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_employee'), false, false, "", "", true, true);
$sideMenu->addMenuItem(13, "mci_Lookups", $MenuLanguage->MenuPhrase("13", "MenuText"), "", -1, "", IsLoggedIn(), false, true, "", "", true, true);
$sideMenu->addMenuItem(7, "mi_tb_administration_site", $MenuLanguage->MenuPhrase("7", "MenuText"), $MenuRelativePath . "tbadministrationsitelist", 13, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_administration_site'), false, false, "", "", true, true);
$sideMenu->addMenuItem(8, "mi_tb_administration_mode", $MenuLanguage->MenuPhrase("8", "MenuText"), $MenuRelativePath . "tbadministrationmodelist", 13, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_administration_mode'), false, false, "", "", true, true);
$sideMenu->addMenuItem(16, "mi_tb_vaccine_form", $MenuLanguage->MenuPhrase("16", "MenuText"), $MenuRelativePath . "tbvaccineformlist", 13, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_vaccine_form'), false, false, "", "", true, true);
$sideMenu->addMenuItem(15, "mi_tb_unit_of_measure", $MenuLanguage->MenuPhrase("15", "MenuText"), $MenuRelativePath . "tbunitofmeasurelist", 13, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_unit_of_measure'), false, false, "", "", true, true);
$sideMenu->addMenuItem(14, "mci_System_Security", $MenuLanguage->MenuPhrase("14", "MenuText"), "", -1, "", IsLoggedIn(), false, true, "", "", true, true);
$sideMenu->addMenuItem(6, "mi_tb_system_user", $MenuLanguage->MenuPhrase("6", "MenuText"), $MenuRelativePath . "tbsystemuserlist", 14, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_system_user'), false, false, "", "", true, true);
$sideMenu->addMenuItem(3, "mi_tb_user_role", $MenuLanguage->MenuPhrase("3", "MenuText"), $MenuRelativePath . "tbuserrolelist", 14, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_user_role'), false, false, "", "", true, true);
$sideMenu->addMenuItem(4, "mi_tb_user_role_permission", $MenuLanguage->MenuPhrase("4", "MenuText"), $MenuRelativePath . "tbuserrolepermissionlist", 14, "", AllowListMenu('{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_user_role_permission'), false, false, "", "", true, true);
echo $sideMenu->toScript();
