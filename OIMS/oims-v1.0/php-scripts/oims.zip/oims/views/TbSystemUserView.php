<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbSystemUserView = &$Page;
?>
<?php if (!$Page->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $Page->ExportOptions->render("body") ?>
<?php $Page->OtherOptions->render("body") ?>
</div>
<?php } ?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="view">
<form name="ftb_system_userview" id="ftb_system_userview" class="ew-form ew-view-form overlay-wrapper" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (!$Page->isExport()) { ?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_system_user: currentTable } });
var currentPageID = ew.PAGE_ID = "view";
var currentForm;
var ftb_system_userview;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_system_userview")
        .setPageId("view")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php } ?>
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_system_user">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<table class="<?= $Page->TableClass ?>">
<?php if ($Page->id->Visible) { // id ?>
    <tr id="r_id"<?= $Page->id->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_system_user_id"><?= $Page->id->caption() ?></span></td>
        <td data-name="id"<?= $Page->id->cellAttributes() ?>>
<span id="el_tb_system_user_id">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->_username->Visible) { // username ?>
    <tr id="r__username"<?= $Page->_username->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_system_user__username"><?= $Page->_username->caption() ?></span></td>
        <td data-name="_username"<?= $Page->_username->cellAttributes() ?>>
<span id="el_tb_system_user__username">
<span<?= $Page->_username->viewAttributes() ?>>
<?= $Page->_username->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->user_email->Visible) { // user_email ?>
    <tr id="r_user_email"<?= $Page->user_email->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_system_user_user_email"><?= $Page->user_email->caption() ?></span></td>
        <td data-name="user_email"<?= $Page->user_email->cellAttributes() ?>>
<span id="el_tb_system_user_user_email">
<span<?= $Page->user_email->viewAttributes() ?>>
<?= $Page->user_email->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->activation_state->Visible) { // activation_state ?>
    <tr id="r_activation_state"<?= $Page->activation_state->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_system_user_activation_state"><?= $Page->activation_state->caption() ?></span></td>
        <td data-name="activation_state"<?= $Page->activation_state->cellAttributes() ?>>
<span id="el_tb_system_user_activation_state">
<span<?= $Page->activation_state->viewAttributes() ?>>
<?= $Page->activation_state->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->user_role_id->Visible) { // user_role_id ?>
    <tr id="r_user_role_id"<?= $Page->user_role_id->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_system_user_user_role_id"><?= $Page->user_role_id->caption() ?></span></td>
        <td data-name="user_role_id"<?= $Page->user_role_id->cellAttributes() ?>>
<span id="el_tb_system_user_user_role_id">
<span<?= $Page->user_role_id->viewAttributes() ?>>
<?= $Page->user_role_id->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
    <tr id="r_entry_date"<?= $Page->entry_date->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_system_user_entry_date"><?= $Page->entry_date->caption() ?></span></td>
        <td data-name="entry_date"<?= $Page->entry_date->cellAttributes() ?>>
<span id="el_tb_system_user_entry_date">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
    <tr id="r_last_modified"<?= $Page->last_modified->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_system_user_last_modified"><?= $Page->last_modified->caption() ?></span></td>
        <td data-name="last_modified"<?= $Page->last_modified->cellAttributes() ?>>
<span id="el_tb_system_user_last_modified">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
</table>
</form>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<?php if (!$Page->isExport()) { ?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
<?php } ?>
