<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbSystemUserEdit = &$Page;
?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="edit">
<form name="ftb_system_useredit" id="ftb_system_useredit" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_system_user: currentTable } });
var currentPageID = ew.PAGE_ID = "edit";
var currentForm;
var ftb_system_useredit;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_system_useredit")
        .setPageId("edit")

        // Add fields
        .setFields([
            ["id", [fields.id.visible && fields.id.required ? ew.Validators.required(fields.id.caption) : null], fields.id.isInvalid],
            ["_username", [fields._username.visible && fields._username.required ? ew.Validators.required(fields._username.caption) : null], fields._username.isInvalid],
            ["user_password", [fields.user_password.visible && fields.user_password.required ? ew.Validators.required(fields.user_password.caption) : null], fields.user_password.isInvalid],
            ["user_email", [fields.user_email.visible && fields.user_email.required ? ew.Validators.required(fields.user_email.caption) : null], fields.user_email.isInvalid],
            ["activation_state", [fields.activation_state.visible && fields.activation_state.required ? ew.Validators.required(fields.activation_state.caption) : null], fields.activation_state.isInvalid],
            ["user_role_id", [fields.user_role_id.visible && fields.user_role_id.required ? ew.Validators.required(fields.user_role_id.caption) : null], fields.user_role_id.isInvalid],
            ["entry_date", [fields.entry_date.visible && fields.entry_date.required ? ew.Validators.required(fields.entry_date.caption) : null], fields.entry_date.isInvalid],
            ["last_modified", [fields.last_modified.visible && fields.last_modified.required ? ew.Validators.required(fields.last_modified.caption) : null], fields.last_modified.isInvalid]
        ])

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "activation_state": <?= $Page->activation_state->toClientList($Page) ?>,
            "user_role_id": <?= $Page->user_role_id->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_system_user">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<?php if (IsJsonResponse()) { ?>
<input type="hidden" name="json" value="1">
<?php } ?>
<input type="hidden" name="<?= $Page->OldKeyName ?>" value="<?= $Page->OldKey ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($Page->id->Visible) { // id ?>
    <div id="r_id"<?= $Page->id->rowAttributes() ?>>
        <label id="elh_tb_system_user_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->id->caption() ?><?= $Page->id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->id->cellAttributes() ?>>
<span id="el_tb_system_user_id">
<span<?= $Page->id->viewAttributes() ?>>
<input type="text" readonly class="form-control-plaintext" value="<?= HtmlEncode(RemoveHtml($Page->id->getDisplayValue($Page->id->EditValue))) ?>"></span>
<input type="hidden" data-table="tb_system_user" data-field="x_id" data-hidden="1" name="x_id" id="x_id" value="<?= HtmlEncode($Page->id->CurrentValue) ?>">
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->_username->Visible) { // username ?>
    <div id="r__username"<?= $Page->_username->rowAttributes() ?>>
        <label id="elh_tb_system_user__username" for="x__username" class="<?= $Page->LeftColumnClass ?>"><?= $Page->_username->caption() ?><?= $Page->_username->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->_username->cellAttributes() ?>>
<span id="el_tb_system_user__username">
<input type="<?= $Page->_username->getInputTextType() ?>" name="x__username" id="x__username" data-table="tb_system_user" data-field="x__username" value="<?= $Page->_username->EditValue ?>" maxlength="50" placeholder="<?= HtmlEncode($Page->_username->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->_username->formatPattern()) ?>"<?= $Page->_username->editAttributes() ?> aria-describedby="x__username_help">
<?= $Page->_username->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->_username->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->user_password->Visible) { // user_password ?>
    <div id="r_user_password"<?= $Page->user_password->rowAttributes() ?>>
        <label id="elh_tb_system_user_user_password" for="x_user_password" class="<?= $Page->LeftColumnClass ?>"><?= $Page->user_password->caption() ?><?= $Page->user_password->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->user_password->cellAttributes() ?>>
<span id="el_tb_system_user_user_password">
<div class="input-group" id="ig_user_password">
    <input type="password" autocomplete="new-password" data-table="tb_system_user" data-field="x_user_password" name="x_user_password" id="x_user_password" value="<?= $Page->user_password->EditValue ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->user_password->getPlaceHolder()) ?>"<?= $Page->user_password->editAttributes() ?> aria-describedby="x_user_password_help">
    <button type="button" class="btn btn-default ew-toggle-password" data-ew-action="password"><i class="fa-solid fa-eye"></i></button>
    <button type="button" class="btn btn-default ew-password-generator rounded-end" title="<?= HtmlTitle($Language->phrase("GeneratePassword")) ?>" data-password-field="x_user_password" data-password-confirm="c_user_password"><?= $Language->phrase("GeneratePassword") ?></button>
</div>
<?= $Page->user_password->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->user_password->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->user_email->Visible) { // user_email ?>
    <div id="r_user_email"<?= $Page->user_email->rowAttributes() ?>>
        <label id="elh_tb_system_user_user_email" for="x_user_email" class="<?= $Page->LeftColumnClass ?>"><?= $Page->user_email->caption() ?><?= $Page->user_email->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->user_email->cellAttributes() ?>>
<span id="el_tb_system_user_user_email">
<input type="<?= $Page->user_email->getInputTextType() ?>" name="x_user_email" id="x_user_email" data-table="tb_system_user" data-field="x_user_email" value="<?= $Page->user_email->EditValue ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->user_email->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->user_email->formatPattern()) ?>"<?= $Page->user_email->editAttributes() ?> aria-describedby="x_user_email_help">
<?= $Page->user_email->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->user_email->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->activation_state->Visible) { // activation_state ?>
    <div id="r_activation_state"<?= $Page->activation_state->rowAttributes() ?>>
        <label id="elh_tb_system_user_activation_state" class="<?= $Page->LeftColumnClass ?>"><?= $Page->activation_state->caption() ?><?= $Page->activation_state->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->activation_state->cellAttributes() ?>>
<span id="el_tb_system_user_activation_state">
<template id="tp_x_activation_state">
    <div class="form-check">
        <input type="radio" class="form-check-input" data-table="tb_system_user" data-field="x_activation_state" name="x_activation_state" id="x_activation_state"<?= $Page->activation_state->editAttributes() ?>>
        <label class="form-check-label"></label>
    </div>
</template>
<div id="dsl_x_activation_state" class="ew-item-list"></div>
<selection-list hidden
    id="x_activation_state"
    name="x_activation_state"
    value="<?= HtmlEncode($Page->activation_state->CurrentValue) ?>"
    data-type="select-one"
    data-template="tp_x_activation_state"
    data-target="dsl_x_activation_state"
    data-repeatcolumn="5"
    class="form-control<?= $Page->activation_state->isInvalidClass() ?>"
    data-table="tb_system_user"
    data-field="x_activation_state"
    data-value-separator="<?= $Page->activation_state->displayValueSeparatorAttribute() ?>"
    <?= $Page->activation_state->editAttributes() ?>></selection-list>
<?= $Page->activation_state->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->activation_state->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->user_role_id->Visible) { // user_role_id ?>
    <div id="r_user_role_id"<?= $Page->user_role_id->rowAttributes() ?>>
        <label id="elh_tb_system_user_user_role_id" for="x_user_role_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->user_role_id->caption() ?><?= $Page->user_role_id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->user_role_id->cellAttributes() ?>>
<?php if (!$Security->isAdmin() && $Security->isLoggedIn()) { // Non system admin ?>
<span id="el_tb_system_user_user_role_id">
<span class="form-control-plaintext"><?= $Page->user_role_id->getDisplayValue($Page->user_role_id->EditValue) ?></span>
</span>
<?php } else { ?>
<span id="el_tb_system_user_user_role_id">
    <select
        id="x_user_role_id"
        name="x_user_role_id"
        class="form-select ew-select<?= $Page->user_role_id->isInvalidClass() ?>"
        <?php if (!$Page->user_role_id->IsNativeSelect) { ?>
        data-select2-id="ftb_system_useredit_x_user_role_id"
        <?php } ?>
        data-table="tb_system_user"
        data-field="x_user_role_id"
        data-value-separator="<?= $Page->user_role_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->user_role_id->getPlaceHolder()) ?>"
        <?= $Page->user_role_id->editAttributes() ?>>
        <?= $Page->user_role_id->selectOptionListHtml("x_user_role_id") ?>
    </select>
    <?= $Page->user_role_id->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->user_role_id->getErrorMessage() ?></div>
<?= $Page->user_role_id->Lookup->getParamTag($Page, "p_x_user_role_id") ?>
<?php if (!$Page->user_role_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_system_useredit", function() {
    var options = { name: "x_user_role_id", selectId: "ftb_system_useredit_x_user_role_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_system_useredit.lists.user_role_id?.lookupOptions.length) {
        options.data = { id: "x_user_role_id", form: "ftb_system_useredit" };
    } else {
        options.ajax = { id: "x_user_role_id", form: "ftb_system_useredit", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_system_user.fields.user_role_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
<?php } ?>
</div></div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_system_useredit"><?= $Language->phrase("SaveBtn") ?></button>
<?php if (IsJsonResponse()) { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-bs-dismiss="modal"><?= $Language->phrase("CancelBtn") ?></button>
<?php } else { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_system_useredit" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
<?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_system_user");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
