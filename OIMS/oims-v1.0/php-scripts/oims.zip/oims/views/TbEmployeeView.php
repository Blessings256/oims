<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbEmployeeView = &$Page;
?>
<?php if (!$Page->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $Page->ExportOptions->render("body") ?>
<?php $Page->OtherOptions->render("body") ?>
</div>
<?php } ?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="view">
<form name="ftb_employeeview" id="ftb_employeeview" class="ew-form ew-view-form overlay-wrapper" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (!$Page->isExport()) { ?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_employee: currentTable } });
var currentPageID = ew.PAGE_ID = "view";
var currentForm;
var ftb_employeeview;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_employeeview")
        .setPageId("view")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php } ?>
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_employee">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<table class="<?= $Page->TableClass ?>">
<?php if ($Page->id->Visible) { // id ?>
    <tr id="r_id"<?= $Page->id->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_id"><?= $Page->id->caption() ?></span></td>
        <td data-name="id"<?= $Page->id->cellAttributes() ?>>
<span id="el_tb_employee_id">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->employee_number->Visible) { // employee_number ?>
    <tr id="r_employee_number"<?= $Page->employee_number->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_employee_number"><?= $Page->employee_number->caption() ?></span></td>
        <td data-name="employee_number"<?= $Page->employee_number->cellAttributes() ?>>
<span id="el_tb_employee_employee_number">
<span<?= $Page->employee_number->viewAttributes() ?>>
<?= $Page->employee_number->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->first_name->Visible) { // first_name ?>
    <tr id="r_first_name"<?= $Page->first_name->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_first_name"><?= $Page->first_name->caption() ?></span></td>
        <td data-name="first_name"<?= $Page->first_name->cellAttributes() ?>>
<span id="el_tb_employee_first_name">
<span<?= $Page->first_name->viewAttributes() ?>>
<?= $Page->first_name->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->last_name->Visible) { // last_name ?>
    <tr id="r_last_name"<?= $Page->last_name->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_last_name"><?= $Page->last_name->caption() ?></span></td>
        <td data-name="last_name"<?= $Page->last_name->cellAttributes() ?>>
<span id="el_tb_employee_last_name">
<span<?= $Page->last_name->viewAttributes() ?>>
<?= $Page->last_name->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->other_name->Visible) { // other_name ?>
    <tr id="r_other_name"<?= $Page->other_name->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_other_name"><?= $Page->other_name->caption() ?></span></td>
        <td data-name="other_name"<?= $Page->other_name->cellAttributes() ?>>
<span id="el_tb_employee_other_name">
<span<?= $Page->other_name->viewAttributes() ?>>
<?= $Page->other_name->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->job_tile->Visible) { // job_tile ?>
    <tr id="r_job_tile"<?= $Page->job_tile->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_job_tile"><?= $Page->job_tile->caption() ?></span></td>
        <td data-name="job_tile"<?= $Page->job_tile->cellAttributes() ?>>
<span id="el_tb_employee_job_tile">
<span<?= $Page->job_tile->viewAttributes() ?>>
<?= $Page->job_tile->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->pri_phone_no->Visible) { // pri_phone_no ?>
    <tr id="r_pri_phone_no"<?= $Page->pri_phone_no->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_pri_phone_no"><?= $Page->pri_phone_no->caption() ?></span></td>
        <td data-name="pri_phone_no"<?= $Page->pri_phone_no->cellAttributes() ?>>
<span id="el_tb_employee_pri_phone_no">
<span<?= $Page->pri_phone_no->viewAttributes() ?>>
<?= $Page->pri_phone_no->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->alt_phone_no->Visible) { // alt_phone_no ?>
    <tr id="r_alt_phone_no"<?= $Page->alt_phone_no->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_alt_phone_no"><?= $Page->alt_phone_no->caption() ?></span></td>
        <td data-name="alt_phone_no"<?= $Page->alt_phone_no->cellAttributes() ?>>
<span id="el_tb_employee_alt_phone_no">
<span<?= $Page->alt_phone_no->viewAttributes() ?>>
<?= $Page->alt_phone_no->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->personal_email->Visible) { // personal_email ?>
    <tr id="r_personal_email"<?= $Page->personal_email->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_personal_email"><?= $Page->personal_email->caption() ?></span></td>
        <td data-name="personal_email"<?= $Page->personal_email->cellAttributes() ?>>
<span id="el_tb_employee_personal_email">
<span<?= $Page->personal_email->viewAttributes() ?>>
<?= $Page->personal_email->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->official_email->Visible) { // official_email ?>
    <tr id="r_official_email"<?= $Page->official_email->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_official_email"><?= $Page->official_email->caption() ?></span></td>
        <td data-name="official_email"<?= $Page->official_email->cellAttributes() ?>>
<span id="el_tb_employee_official_email">
<span<?= $Page->official_email->viewAttributes() ?>>
<?= $Page->official_email->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->department->Visible) { // department ?>
    <tr id="r_department"<?= $Page->department->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_department"><?= $Page->department->caption() ?></span></td>
        <td data-name="department"<?= $Page->department->cellAttributes() ?>>
<span id="el_tb_employee_department">
<span<?= $Page->department->viewAttributes() ?>>
<?= $Page->department->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->hire_date->Visible) { // hire_date ?>
    <tr id="r_hire_date"<?= $Page->hire_date->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_hire_date"><?= $Page->hire_date->caption() ?></span></td>
        <td data-name="hire_date"<?= $Page->hire_date->cellAttributes() ?>>
<span id="el_tb_employee_hire_date">
<span<?= $Page->hire_date->viewAttributes() ?>>
<?= $Page->hire_date->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->current_status->Visible) { // current_status ?>
    <tr id="r_current_status"<?= $Page->current_status->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_current_status"><?= $Page->current_status->caption() ?></span></td>
        <td data-name="current_status"<?= $Page->current_status->cellAttributes() ?>>
<span id="el_tb_employee_current_status">
<span<?= $Page->current_status->viewAttributes() ?>>
<?= $Page->current_status->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->tin_number->Visible) { // tin_number ?>
    <tr id="r_tin_number"<?= $Page->tin_number->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_tin_number"><?= $Page->tin_number->caption() ?></span></td>
        <td data-name="tin_number"<?= $Page->tin_number->cellAttributes() ?>>
<span id="el_tb_employee_tin_number">
<span<?= $Page->tin_number->viewAttributes() ?>>
<?= $Page->tin_number->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->nssf_number->Visible) { // nssf_number ?>
    <tr id="r_nssf_number"<?= $Page->nssf_number->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_nssf_number"><?= $Page->nssf_number->caption() ?></span></td>
        <td data-name="nssf_number"<?= $Page->nssf_number->cellAttributes() ?>>
<span id="el_tb_employee_nssf_number">
<span<?= $Page->nssf_number->viewAttributes() ?>>
<?= $Page->nssf_number->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->salary_amount->Visible) { // salary_amount ?>
    <tr id="r_salary_amount"<?= $Page->salary_amount->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_salary_amount"><?= $Page->salary_amount->caption() ?></span></td>
        <td data-name="salary_amount"<?= $Page->salary_amount->cellAttributes() ?>>
<span id="el_tb_employee_salary_amount">
<span<?= $Page->salary_amount->viewAttributes() ?>>
<?= $Page->salary_amount->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->employement_type->Visible) { // employement_type ?>
    <tr id="r_employement_type"<?= $Page->employement_type->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_employement_type"><?= $Page->employement_type->caption() ?></span></td>
        <td data-name="employement_type"<?= $Page->employement_type->cellAttributes() ?>>
<span id="el_tb_employee_employement_type">
<span<?= $Page->employement_type->viewAttributes() ?>>
<?= $Page->employement_type->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->work_schedule->Visible) { // work_schedule ?>
    <tr id="r_work_schedule"<?= $Page->work_schedule->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_work_schedule"><?= $Page->work_schedule->caption() ?></span></td>
        <td data-name="work_schedule"<?= $Page->work_schedule->cellAttributes() ?>>
<span id="el_tb_employee_work_schedule">
<span<?= $Page->work_schedule->viewAttributes() ?>>
<?= $Page->work_schedule->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->sex->Visible) { // sex ?>
    <tr id="r_sex"<?= $Page->sex->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_sex"><?= $Page->sex->caption() ?></span></td>
        <td data-name="sex"<?= $Page->sex->cellAttributes() ?>>
<span id="el_tb_employee_sex">
<span<?= $Page->sex->viewAttributes() ?>>
<?= $Page->sex->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
    <tr id="r_entry_date"<?= $Page->entry_date->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_entry_date"><?= $Page->entry_date->caption() ?></span></td>
        <td data-name="entry_date"<?= $Page->entry_date->cellAttributes() ?>>
<span id="el_tb_employee_entry_date">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
    <tr id="r_last_modified"<?= $Page->last_modified->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_last_modified"><?= $Page->last_modified->caption() ?></span></td>
        <td data-name="last_modified"<?= $Page->last_modified->cellAttributes() ?>>
<span id="el_tb_employee_last_modified">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
    <tr id="r_entered_by"<?= $Page->entered_by->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_entered_by"><?= $Page->entered_by->caption() ?></span></td>
        <td data-name="entered_by"<?= $Page->entered_by->cellAttributes() ?>>
<span id="el_tb_employee_entered_by">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
    <tr id="r_modified_by"<?= $Page->modified_by->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_employee_modified_by"><?= $Page->modified_by->caption() ?></span></td>
        <td data-name="modified_by"<?= $Page->modified_by->cellAttributes() ?>>
<span id="el_tb_employee_modified_by">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
</table>
</form>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<?php if (!$Page->isExport()) { ?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
<?php } ?>
