<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbImmunisationSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_immunisation: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var ftb_immunisationsearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_immunisationsearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["id", [ew.Validators.integer], fields.id.isInvalid],
            ["y_id", [ew.Validators.between], false],
            ["vaccination_date", [ew.Validators.datetime(fields.vaccination_date.clientFormatPattern)], fields.vaccination_date.isInvalid],
            ["y_vaccination_date", [ew.Validators.between], false],
            ["child_id", [], fields.child_id.isInvalid],
            ["y_child_id", [ew.Validators.between], false],
            ["vaccine_id", [], fields.vaccine_id.isInvalid],
            ["y_vaccine_id", [ew.Validators.between], false],
            ["dose_cycle", [], fields.dose_cycle.isInvalid],
            ["y_dose_cycle", [ew.Validators.between], false],
            ["next_vaccination_date", [ew.Validators.datetime(fields.next_vaccination_date.clientFormatPattern)], fields.next_vaccination_date.isInvalid],
            ["y_next_vaccination_date", [ew.Validators.between], false],
            ["administered_by", [], fields.administered_by.isInvalid],
            ["y_administered_by", [ew.Validators.between], false],
            ["remarks", [], fields.remarks.isInvalid],
            ["y_remarks", [ew.Validators.between], false]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "child_id": <?= $Page->child_id->toClientList($Page) ?>,
            "vaccine_id": <?= $Page->vaccine_id->toClientList($Page) ?>,
            "dose_cycle": <?= $Page->dose_cycle->toClientList($Page) ?>,
            "administered_by": <?= $Page->administered_by->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_immunisationsearch" id="ftb_immunisationsearch" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_immunisation">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<div class="ew-search-div"><!-- page* -->
<?php if ($Page->id->Visible) { // id ?>
    <div id="r_id" class="row"<?= $Page->id->rowAttributes() ?>>
        <label for="x_id" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_immunisation_id"><?= $Page->id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_id" id="z_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_immunisation_id" class="ew-search-field">
<input type="<?= $Page->id->getInputTextType() ?>" name="x_id" id="x_id" data-table="tb_immunisation" data-field="x_id" value="<?= $Page->id->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_immunisation_id" class="ew-search-field2 d-none">
<input type="<?= $Page->id->getInputTextType() ?>" name="y_id" id="y_id" data-table="tb_immunisation" data-field="x_id" value="<?= $Page->id->EditValue2 ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->vaccination_date->Visible) { // vaccination_date ?>
    <div id="r_vaccination_date" class="row"<?= $Page->vaccination_date->rowAttributes() ?>>
        <label for="x_vaccination_date" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_immunisation_vaccination_date"><?= $Page->vaccination_date->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->vaccination_date->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_vaccination_date" id="z_vaccination_date" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->vaccination_date->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->vaccination_date->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_immunisation_vaccination_date" class="ew-search-field">
<input type="<?= $Page->vaccination_date->getInputTextType() ?>" name="x_vaccination_date" id="x_vaccination_date" data-table="tb_immunisation" data-field="x_vaccination_date" value="<?= $Page->vaccination_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->vaccination_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccination_date->formatPattern()) ?>"<?= $Page->vaccination_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->vaccination_date->getErrorMessage(false) ?></div>
<?php if (!$Page->vaccination_date->ReadOnly && !$Page->vaccination_date->Disabled && !isset($Page->vaccination_date->EditAttrs["readonly"]) && !isset($Page->vaccination_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_immunisationsearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_immunisationsearch", "x_vaccination_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_immunisation_vaccination_date" class="ew-search-field2 d-none">
<input type="<?= $Page->vaccination_date->getInputTextType() ?>" name="y_vaccination_date" id="y_vaccination_date" data-table="tb_immunisation" data-field="x_vaccination_date" value="<?= $Page->vaccination_date->EditValue2 ?>" placeholder="<?= HtmlEncode($Page->vaccination_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccination_date->formatPattern()) ?>"<?= $Page->vaccination_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->vaccination_date->getErrorMessage(false) ?></div>
<?php if (!$Page->vaccination_date->ReadOnly && !$Page->vaccination_date->Disabled && !isset($Page->vaccination_date->EditAttrs["readonly"]) && !isset($Page->vaccination_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_immunisationsearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_immunisationsearch", "y_vaccination_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->child_id->Visible) { // child_id ?>
    <div id="r_child_id" class="row"<?= $Page->child_id->rowAttributes() ?>>
        <label class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_immunisation_child_id"><?= $Page->child_id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->child_id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_child_id" id="z_child_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->child_id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->child_id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_immunisation_child_id" class="ew-search-field">
<?php
if (IsRTL()) {
    $Page->child_id->EditAttrs["dir"] = "rtl";
}
?>
<span id="as_x_child_id" class="ew-auto-suggest">
    <input type="<?= $Page->child_id->getInputTextType() ?>" class="form-control" name="sv_x_child_id" id="sv_x_child_id" value="<?= RemoveHtml($Page->child_id->EditValue) ?>" autocomplete="off" placeholder="<?= HtmlEncode($Page->child_id->getPlaceHolder()) ?>" data-placeholder="<?= HtmlEncode($Page->child_id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->child_id->formatPattern()) ?>"<?= $Page->child_id->editAttributes() ?>>
</span>
<selection-list hidden class="form-control" data-table="tb_immunisation" data-field="x_child_id" data-input="sv_x_child_id" data-value-separator="<?= $Page->child_id->displayValueSeparatorAttribute() ?>" name="x_child_id" id="x_child_id" value="<?= HtmlEncode($Page->child_id->AdvancedSearch->SearchValue) ?>"></selection-list>
<div class="invalid-feedback"><?= $Page->child_id->getErrorMessage(false) ?></div>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    ftb_immunisationsearch.createAutoSuggest(Object.assign({"id":"x_child_id","forceSelect":false}, { lookupAllDisplayFields: <?= $Page->child_id->Lookup->LookupAllDisplayFields ? "true" : "false" ?> }, ew.vars.tables.tb_immunisation.fields.child_id.autoSuggestOptions));
});
</script>
<?= $Page->child_id->Lookup->getParamTag($Page, "p_x_child_id") ?>
</span>
                    <span class="ew-search-cond">
<div class="form-check"><input class="form-check-input" type="radio" id="v_child_id_1" name="v_child_id" value="AND"<?= ($Page->child_id->AdvancedSearch->SearchCondition != "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_child_id_1"><?= $Language->phrase("AND") ?></label></div>
<div class="form-check"><input class="form-check-input" type="radio" id="v_child_id_2" name="v_child_id" value="OR"<?= ($Page->child_id->AdvancedSearch->SearchCondition == "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_child_id_2"><?= $Language->phrase("OR") ?></label></div></span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span class="ew-search-operator2">
<?= $Language->phrase("=") ?>
<input type="hidden" name="w_child_id" id="w_child_id" value="=">
</span>
                    <span id="el2_tb_immunisation_child_id" class="ew-search-field2">
<?php
if (IsRTL()) {
    $Page->child_id->EditAttrs["dir"] = "rtl";
}
?>
<span id="as_y_child_id" class="ew-auto-suggest">
    <input type="<?= $Page->child_id->getInputTextType() ?>" class="form-control" name="sv_y_child_id" id="sv_y_child_id" value="<?= RemoveHtml($Page->child_id->EditValue2) ?>" autocomplete="off" placeholder="<?= HtmlEncode($Page->child_id->getPlaceHolder()) ?>" data-placeholder="<?= HtmlEncode($Page->child_id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->child_id->formatPattern()) ?>"<?= $Page->child_id->editAttributes() ?>>
</span>
<selection-list hidden class="form-control" data-table="tb_immunisation" data-field="x_child_id" data-input="sv_y_child_id" data-value-separator="<?= $Page->child_id->displayValueSeparatorAttribute() ?>" name="y_child_id" id="y_child_id" value="<?= HtmlEncode($Page->child_id->AdvancedSearch->SearchValue2) ?>"></selection-list>
<div class="invalid-feedback"><?= $Page->child_id->getErrorMessage(false) ?></div>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    ftb_immunisationsearch.createAutoSuggest(Object.assign({"id":"y_child_id","forceSelect":false}, { lookupAllDisplayFields: <?= $Page->child_id->Lookup->LookupAllDisplayFields ? "true" : "false" ?> }, ew.vars.tables.tb_immunisation.fields.child_id.autoSuggestOptions));
});
</script>
<?= $Page->child_id->Lookup->getParamTag($Page, "p_y_child_id") ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->vaccine_id->Visible) { // vaccine_id ?>
    <div id="r_vaccine_id" class="row"<?= $Page->vaccine_id->rowAttributes() ?>>
        <label class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_immunisation_vaccine_id"><?= $Page->vaccine_id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->vaccine_id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_vaccine_id" id="z_vaccine_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->vaccine_id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->vaccine_id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_immunisation_vaccine_id" class="ew-search-field">
<?php
if (IsRTL()) {
    $Page->vaccine_id->EditAttrs["dir"] = "rtl";
}
?>
<span id="as_x_vaccine_id" class="ew-auto-suggest">
    <input type="<?= $Page->vaccine_id->getInputTextType() ?>" class="form-control" name="sv_x_vaccine_id" id="sv_x_vaccine_id" value="<?= RemoveHtml($Page->vaccine_id->EditValue) ?>" autocomplete="off" placeholder="<?= HtmlEncode($Page->vaccine_id->getPlaceHolder()) ?>" data-placeholder="<?= HtmlEncode($Page->vaccine_id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_id->formatPattern()) ?>"<?= $Page->vaccine_id->editAttributes() ?>>
</span>
<selection-list hidden class="form-control" data-table="tb_immunisation" data-field="x_vaccine_id" data-input="sv_x_vaccine_id" data-value-separator="<?= $Page->vaccine_id->displayValueSeparatorAttribute() ?>" name="x_vaccine_id" id="x_vaccine_id" value="<?= HtmlEncode($Page->vaccine_id->AdvancedSearch->SearchValue) ?>"></selection-list>
<div class="invalid-feedback"><?= $Page->vaccine_id->getErrorMessage(false) ?></div>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    ftb_immunisationsearch.createAutoSuggest(Object.assign({"id":"x_vaccine_id","forceSelect":false}, { lookupAllDisplayFields: <?= $Page->vaccine_id->Lookup->LookupAllDisplayFields ? "true" : "false" ?> }, ew.vars.tables.tb_immunisation.fields.vaccine_id.autoSuggestOptions));
});
</script>
<?= $Page->vaccine_id->Lookup->getParamTag($Page, "p_x_vaccine_id") ?>
</span>
                    <span class="ew-search-cond">
<div class="form-check"><input class="form-check-input" type="radio" id="v_vaccine_id_1" name="v_vaccine_id" value="AND"<?= ($Page->vaccine_id->AdvancedSearch->SearchCondition != "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_vaccine_id_1"><?= $Language->phrase("AND") ?></label></div>
<div class="form-check"><input class="form-check-input" type="radio" id="v_vaccine_id_2" name="v_vaccine_id" value="OR"<?= ($Page->vaccine_id->AdvancedSearch->SearchCondition == "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_vaccine_id_2"><?= $Language->phrase("OR") ?></label></div></span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span class="ew-search-operator2">
<?= $Language->phrase("=") ?>
<input type="hidden" name="w_vaccine_id" id="w_vaccine_id" value="=">
</span>
                    <span id="el2_tb_immunisation_vaccine_id" class="ew-search-field2">
<?php
if (IsRTL()) {
    $Page->vaccine_id->EditAttrs["dir"] = "rtl";
}
?>
<span id="as_y_vaccine_id" class="ew-auto-suggest">
    <input type="<?= $Page->vaccine_id->getInputTextType() ?>" class="form-control" name="sv_y_vaccine_id" id="sv_y_vaccine_id" value="<?= RemoveHtml($Page->vaccine_id->EditValue2) ?>" autocomplete="off" placeholder="<?= HtmlEncode($Page->vaccine_id->getPlaceHolder()) ?>" data-placeholder="<?= HtmlEncode($Page->vaccine_id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_id->formatPattern()) ?>"<?= $Page->vaccine_id->editAttributes() ?>>
</span>
<selection-list hidden class="form-control" data-table="tb_immunisation" data-field="x_vaccine_id" data-input="sv_y_vaccine_id" data-value-separator="<?= $Page->vaccine_id->displayValueSeparatorAttribute() ?>" name="y_vaccine_id" id="y_vaccine_id" value="<?= HtmlEncode($Page->vaccine_id->AdvancedSearch->SearchValue2) ?>"></selection-list>
<div class="invalid-feedback"><?= $Page->vaccine_id->getErrorMessage(false) ?></div>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    ftb_immunisationsearch.createAutoSuggest(Object.assign({"id":"y_vaccine_id","forceSelect":false}, { lookupAllDisplayFields: <?= $Page->vaccine_id->Lookup->LookupAllDisplayFields ? "true" : "false" ?> }, ew.vars.tables.tb_immunisation.fields.vaccine_id.autoSuggestOptions));
});
</script>
<?= $Page->vaccine_id->Lookup->getParamTag($Page, "p_y_vaccine_id") ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->dose_cycle->Visible) { // dose_cycle ?>
    <div id="r_dose_cycle" class="row"<?= $Page->dose_cycle->rowAttributes() ?>>
        <label for="x_dose_cycle" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_immunisation_dose_cycle"><?= $Page->dose_cycle->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->dose_cycle->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_dose_cycle" id="z_dose_cycle" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->dose_cycle->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->dose_cycle->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_immunisation_dose_cycle" class="ew-search-field">
    <select
        id="x_dose_cycle"
        name="x_dose_cycle"
        class="form-select ew-select<?= $Page->dose_cycle->isInvalidClass() ?>"
        <?php if (!$Page->dose_cycle->IsNativeSelect) { ?>
        data-select2-id="ftb_immunisationsearch_x_dose_cycle"
        <?php } ?>
        data-table="tb_immunisation"
        data-field="x_dose_cycle"
        data-value-separator="<?= $Page->dose_cycle->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->dose_cycle->getPlaceHolder()) ?>"
        <?= $Page->dose_cycle->editAttributes() ?>>
        <?= $Page->dose_cycle->selectOptionListHtml("x_dose_cycle") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->dose_cycle->getErrorMessage(false) ?></div>
<?php if (!$Page->dose_cycle->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    var options = { name: "x_dose_cycle", selectId: "ftb_immunisationsearch_x_dose_cycle" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_immunisationsearch.lists.dose_cycle?.lookupOptions.length) {
        options.data = { id: "x_dose_cycle", form: "ftb_immunisationsearch" };
    } else {
        options.ajax = { id: "x_dose_cycle", form: "ftb_immunisationsearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_immunisation.fields.dose_cycle.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_immunisation_dose_cycle" class="ew-search-field2 d-none">
    <select
        id="y_dose_cycle"
        name="y_dose_cycle"
        class="form-select ew-select<?= $Page->dose_cycle->isInvalidClass() ?>"
        <?php if (!$Page->dose_cycle->IsNativeSelect) { ?>
        data-select2-id="ftb_immunisationsearch_y_dose_cycle"
        <?php } ?>
        data-table="tb_immunisation"
        data-field="x_dose_cycle"
        data-value-separator="<?= $Page->dose_cycle->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->dose_cycle->getPlaceHolder()) ?>"
        <?= $Page->dose_cycle->editAttributes() ?>>
        <?= $Page->dose_cycle->selectOptionListHtml("y_dose_cycle") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->dose_cycle->getErrorMessage(false) ?></div>
<?php if (!$Page->dose_cycle->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    var options = { name: "y_dose_cycle", selectId: "ftb_immunisationsearch_y_dose_cycle" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_immunisationsearch.lists.dose_cycle?.lookupOptions.length) {
        options.data = { id: "y_dose_cycle", form: "ftb_immunisationsearch" };
    } else {
        options.ajax = { id: "y_dose_cycle", form: "ftb_immunisationsearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_immunisation.fields.dose_cycle.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->next_vaccination_date->Visible) { // next_vaccination_date ?>
    <div id="r_next_vaccination_date" class="row"<?= $Page->next_vaccination_date->rowAttributes() ?>>
        <label for="x_next_vaccination_date" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_immunisation_next_vaccination_date"><?= $Page->next_vaccination_date->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->next_vaccination_date->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_next_vaccination_date" id="z_next_vaccination_date" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->next_vaccination_date->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->next_vaccination_date->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_immunisation_next_vaccination_date" class="ew-search-field">
<input type="<?= $Page->next_vaccination_date->getInputTextType() ?>" name="x_next_vaccination_date" id="x_next_vaccination_date" data-table="tb_immunisation" data-field="x_next_vaccination_date" value="<?= $Page->next_vaccination_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->next_vaccination_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->next_vaccination_date->formatPattern()) ?>"<?= $Page->next_vaccination_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->next_vaccination_date->getErrorMessage(false) ?></div>
<?php if (!$Page->next_vaccination_date->ReadOnly && !$Page->next_vaccination_date->Disabled && !isset($Page->next_vaccination_date->EditAttrs["readonly"]) && !isset($Page->next_vaccination_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_immunisationsearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_immunisationsearch", "x_next_vaccination_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_immunisation_next_vaccination_date" class="ew-search-field2 d-none">
<input type="<?= $Page->next_vaccination_date->getInputTextType() ?>" name="y_next_vaccination_date" id="y_next_vaccination_date" data-table="tb_immunisation" data-field="x_next_vaccination_date" value="<?= $Page->next_vaccination_date->EditValue2 ?>" placeholder="<?= HtmlEncode($Page->next_vaccination_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->next_vaccination_date->formatPattern()) ?>"<?= $Page->next_vaccination_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->next_vaccination_date->getErrorMessage(false) ?></div>
<?php if (!$Page->next_vaccination_date->ReadOnly && !$Page->next_vaccination_date->Disabled && !isset($Page->next_vaccination_date->EditAttrs["readonly"]) && !isset($Page->next_vaccination_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_immunisationsearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_immunisationsearch", "y_next_vaccination_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->administered_by->Visible) { // administered_by ?>
    <div id="r_administered_by" class="row"<?= $Page->administered_by->rowAttributes() ?>>
        <label for="x_administered_by" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_immunisation_administered_by"><?= $Page->administered_by->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->administered_by->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_administered_by" id="z_administered_by" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->administered_by->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->administered_by->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_immunisation_administered_by" class="ew-search-field">
    <select
        id="x_administered_by"
        name="x_administered_by"
        class="form-select ew-select<?= $Page->administered_by->isInvalidClass() ?>"
        <?php if (!$Page->administered_by->IsNativeSelect) { ?>
        data-select2-id="ftb_immunisationsearch_x_administered_by"
        <?php } ?>
        data-table="tb_immunisation"
        data-field="x_administered_by"
        data-value-separator="<?= $Page->administered_by->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->administered_by->getPlaceHolder()) ?>"
        <?= $Page->administered_by->editAttributes() ?>>
        <?= $Page->administered_by->selectOptionListHtml("x_administered_by") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->administered_by->getErrorMessage(false) ?></div>
<?= $Page->administered_by->Lookup->getParamTag($Page, "p_x_administered_by") ?>
<?php if (!$Page->administered_by->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    var options = { name: "x_administered_by", selectId: "ftb_immunisationsearch_x_administered_by" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_immunisationsearch.lists.administered_by?.lookupOptions.length) {
        options.data = { id: "x_administered_by", form: "ftb_immunisationsearch" };
    } else {
        options.ajax = { id: "x_administered_by", form: "ftb_immunisationsearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_immunisation.fields.administered_by.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-cond">
<div class="form-check"><input class="form-check-input" type="radio" id="v_administered_by_1" name="v_administered_by" value="AND"<?= ($Page->administered_by->AdvancedSearch->SearchCondition != "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_administered_by_1"><?= $Language->phrase("AND") ?></label></div>
<div class="form-check"><input class="form-check-input" type="radio" id="v_administered_by_2" name="v_administered_by" value="OR"<?= ($Page->administered_by->AdvancedSearch->SearchCondition == "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_administered_by_2"><?= $Language->phrase("OR") ?></label></div></span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span class="ew-search-operator2">
<?= $Language->phrase("=") ?>
<input type="hidden" name="w_administered_by" id="w_administered_by" value="=">
</span>
                    <span id="el2_tb_immunisation_administered_by" class="ew-search-field2">
    <select
        id="y_administered_by"
        name="y_administered_by"
        class="form-select ew-select<?= $Page->administered_by->isInvalidClass() ?>"
        <?php if (!$Page->administered_by->IsNativeSelect) { ?>
        data-select2-id="ftb_immunisationsearch_y_administered_by"
        <?php } ?>
        data-table="tb_immunisation"
        data-field="x_administered_by"
        data-value-separator="<?= $Page->administered_by->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->administered_by->getPlaceHolder()) ?>"
        <?= $Page->administered_by->editAttributes() ?>>
        <?= $Page->administered_by->selectOptionListHtml("y_administered_by") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->administered_by->getErrorMessage(false) ?></div>
<?= $Page->administered_by->Lookup->getParamTag($Page, "p_y_administered_by") ?>
<?php if (!$Page->administered_by->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_immunisationsearch", function() {
    var options = { name: "y_administered_by", selectId: "ftb_immunisationsearch_y_administered_by" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_immunisationsearch.lists.administered_by?.lookupOptions.length) {
        options.data = { id: "y_administered_by", form: "ftb_immunisationsearch" };
    } else {
        options.ajax = { id: "y_administered_by", form: "ftb_immunisationsearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_immunisation.fields.administered_by.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->remarks->Visible) { // remarks ?>
    <div id="r_remarks" class="row"<?= $Page->remarks->rowAttributes() ?>>
        <label for="x_remarks" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_immunisation_remarks"><?= $Page->remarks->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->remarks->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_remarks" id="z_remarks" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->remarks->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->remarks->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_immunisation_remarks" class="ew-search-field">
<input type="<?= $Page->remarks->getInputTextType() ?>" name="x_remarks" id="x_remarks" data-table="tb_immunisation" data-field="x_remarks" value="<?= $Page->remarks->EditValue ?>" size="35" placeholder="<?= HtmlEncode($Page->remarks->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->remarks->formatPattern()) ?>"<?= $Page->remarks->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->remarks->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_immunisation_remarks" class="ew-search-field2 d-none">
<input type="<?= $Page->remarks->getInputTextType() ?>" name="y_remarks" id="y_remarks" data-table="tb_immunisation" data-field="x_remarks" value="<?= $Page->remarks->EditValue2 ?>" size="35" placeholder="<?= HtmlEncode($Page->remarks->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->remarks->formatPattern()) ?>"<?= $Page->remarks->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->remarks->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_immunisationsearch"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_immunisationsearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" form="ftb_immunisationsearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_immunisation");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
