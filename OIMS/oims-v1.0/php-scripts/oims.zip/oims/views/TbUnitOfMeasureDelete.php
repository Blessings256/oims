<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbUnitOfMeasureDelete = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_unit_of_measure: currentTable } });
var currentPageID = ew.PAGE_ID = "delete";
var currentForm;
var ftb_unit_of_measuredelete;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_unit_of_measuredelete")
        .setPageId("delete")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_unit_of_measuredelete" id="ftb_unit_of_measuredelete" class="ew-form ew-delete-form" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_unit_of_measure">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($Page->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?= HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid <?= $Page->TableGridClass ?>">
<div class="card-body ew-grid-middle-panel <?= $Page->TableContainerClass ?>" style="<?= $Page->TableContainerStyle ?>">
<table class="<?= $Page->TableClass ?>">
    <thead>
    <tr class="ew-table-header">
<?php if ($Page->id->Visible) { // id ?>
        <th class="<?= $Page->id->headerCellClass() ?>"><span id="elh_tb_unit_of_measure_id" class="tb_unit_of_measure_id"><?= $Page->id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->uom_full_name->Visible) { // uom_full_name ?>
        <th class="<?= $Page->uom_full_name->headerCellClass() ?>"><span id="elh_tb_unit_of_measure_uom_full_name" class="tb_unit_of_measure_uom_full_name"><?= $Page->uom_full_name->caption() ?></span></th>
<?php } ?>
<?php if ($Page->short_form->Visible) { // short_form ?>
        <th class="<?= $Page->short_form->headerCellClass() ?>"><span id="elh_tb_unit_of_measure_short_form" class="tb_unit_of_measure_short_form"><?= $Page->short_form->caption() ?></span></th>
<?php } ?>
<?php if ($Page->description->Visible) { // description ?>
        <th class="<?= $Page->description->headerCellClass() ?>"><span id="elh_tb_unit_of_measure_description" class="tb_unit_of_measure_description"><?= $Page->description->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <th class="<?= $Page->entry_date->headerCellClass() ?>"><span id="elh_tb_unit_of_measure_entry_date" class="tb_unit_of_measure_entry_date"><?= $Page->entry_date->caption() ?></span></th>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <th class="<?= $Page->last_modified->headerCellClass() ?>"><span id="elh_tb_unit_of_measure_last_modified" class="tb_unit_of_measure_last_modified"><?= $Page->last_modified->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <th class="<?= $Page->entered_by->headerCellClass() ?>"><span id="elh_tb_unit_of_measure_entered_by" class="tb_unit_of_measure_entered_by"><?= $Page->entered_by->caption() ?></span></th>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <th class="<?= $Page->modified_by->headerCellClass() ?>"><span id="elh_tb_unit_of_measure_modified_by" class="tb_unit_of_measure_modified_by"><?= $Page->modified_by->caption() ?></span></th>
<?php } ?>
    </tr>
    </thead>
    <tbody>
<?php
$Page->RecordCount = 0;
$i = 0;
while (!$Page->Recordset->EOF) {
    $Page->RecordCount++;
    $Page->RowCount++;

    // Set row properties
    $Page->resetAttributes();
    $Page->RowType = ROWTYPE_VIEW; // View

    // Get the field contents
    $Page->loadRowValues($Page->Recordset);

    // Render row
    $Page->renderRow();
?>
    <tr <?= $Page->rowAttributes() ?>>
<?php if ($Page->id->Visible) { // id ?>
        <td<?= $Page->id->cellAttributes() ?>>
<span id="">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->uom_full_name->Visible) { // uom_full_name ?>
        <td<?= $Page->uom_full_name->cellAttributes() ?>>
<span id="">
<span<?= $Page->uom_full_name->viewAttributes() ?>>
<?= $Page->uom_full_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->short_form->Visible) { // short_form ?>
        <td<?= $Page->short_form->cellAttributes() ?>>
<span id="">
<span<?= $Page->short_form->viewAttributes() ?>>
<?= $Page->short_form->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->description->Visible) { // description ?>
        <td<?= $Page->description->cellAttributes() ?>>
<span id="">
<span<?= $Page->description->viewAttributes() ?>>
<?= $Page->description->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <td<?= $Page->entry_date->cellAttributes() ?>>
<span id="">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <td<?= $Page->last_modified->cellAttributes() ?>>
<span id="">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <td<?= $Page->entered_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <td<?= $Page->modified_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
    </tr>
<?php
    $Page->Recordset->moveNext();
}
$Page->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div class="ew-buttons ew-desktop-buttons">
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?= $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
