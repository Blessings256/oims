<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbVaccineAdd = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_vaccine: currentTable } });
var currentPageID = ew.PAGE_ID = "add";
var currentForm;
var ftb_vaccineadd;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_vaccineadd")
        .setPageId("add")

        // Add fields
        .setFields([
            ["vaccine_name", [fields.vaccine_name.visible && fields.vaccine_name.required ? ew.Validators.required(fields.vaccine_name.caption) : null], fields.vaccine_name.isInvalid],
            ["vaccine_code", [fields.vaccine_code.visible && fields.vaccine_code.required ? ew.Validators.required(fields.vaccine_code.caption) : null], fields.vaccine_code.isInvalid],
            ["dose_required", [fields.dose_required.visible && fields.dose_required.required ? ew.Validators.required(fields.dose_required.caption) : null, ew.Validators.float], fields.dose_required.isInvalid],
            ["dose_required_uom", [fields.dose_required_uom.visible && fields.dose_required_uom.required ? ew.Validators.required(fields.dose_required_uom.caption) : null], fields.dose_required_uom.isInvalid],
            ["admin_mode_id", [fields.admin_mode_id.visible && fields.admin_mode_id.required ? ew.Validators.required(fields.admin_mode_id.caption) : null], fields.admin_mode_id.isInvalid],
            ["admin_site_id", [fields.admin_site_id.visible && fields.admin_site_id.required ? ew.Validators.required(fields.admin_site_id.caption) : null], fields.admin_site_id.isInvalid],
            ["vaccine_form_id", [fields.vaccine_form_id.visible && fields.vaccine_form_id.required ? ew.Validators.required(fields.vaccine_form_id.caption) : null], fields.vaccine_form_id.isInvalid],
            ["expiry_date", [fields.expiry_date.visible && fields.expiry_date.required ? ew.Validators.required(fields.expiry_date.caption) : null, ew.Validators.datetime(fields.expiry_date.clientFormatPattern)], fields.expiry_date.isInvalid],
            ["target_group", [fields.target_group.visible && fields.target_group.required ? ew.Validators.required(fields.target_group.caption) : null], fields.target_group.isInvalid],
            ["storage_condition", [fields.storage_condition.visible && fields.storage_condition.required ? ew.Validators.required(fields.storage_condition.caption) : null], fields.storage_condition.isInvalid],
            ["description", [fields.description.visible && fields.description.required ? ew.Validators.required(fields.description.caption) : null], fields.description.isInvalid],
            ["entry_date", [fields.entry_date.visible && fields.entry_date.required ? ew.Validators.required(fields.entry_date.caption) : null], fields.entry_date.isInvalid],
            ["last_modified", [fields.last_modified.visible && fields.last_modified.required ? ew.Validators.required(fields.last_modified.caption) : null], fields.last_modified.isInvalid],
            ["entered_by", [fields.entered_by.visible && fields.entered_by.required ? ew.Validators.required(fields.entered_by.caption) : null], fields.entered_by.isInvalid],
            ["modified_by", [fields.modified_by.visible && fields.modified_by.required ? ew.Validators.required(fields.modified_by.caption) : null], fields.modified_by.isInvalid]
        ])

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "dose_required_uom": <?= $Page->dose_required_uom->toClientList($Page) ?>,
            "admin_mode_id": <?= $Page->admin_mode_id->toClientList($Page) ?>,
            "admin_site_id": <?= $Page->admin_site_id->toClientList($Page) ?>,
            "vaccine_form_id": <?= $Page->vaccine_form_id->toClientList($Page) ?>,
            "target_group": <?= $Page->target_group->toClientList($Page) ?>,
            "entered_by": <?= $Page->entered_by->toClientList($Page) ?>,
            "modified_by": <?= $Page->modified_by->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_vaccineadd" id="ftb_vaccineadd" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_vaccine">
<input type="hidden" name="action" id="action" value="insert">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<?php if (IsJsonResponse()) { ?>
<input type="hidden" name="json" value="1">
<?php } ?>
<input type="hidden" name="<?= $Page->OldKeyName ?>" value="<?= $Page->OldKey ?>">
<div class="ew-add-div"><!-- page* -->
<?php if ($Page->vaccine_name->Visible) { // vaccine_name ?>
    <div id="r_vaccine_name"<?= $Page->vaccine_name->rowAttributes() ?>>
        <label id="elh_tb_vaccine_vaccine_name" for="x_vaccine_name" class="<?= $Page->LeftColumnClass ?>"><?= $Page->vaccine_name->caption() ?><?= $Page->vaccine_name->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->vaccine_name->cellAttributes() ?>>
<span id="el_tb_vaccine_vaccine_name">
<input type="<?= $Page->vaccine_name->getInputTextType() ?>" name="x_vaccine_name" id="x_vaccine_name" data-table="tb_vaccine" data-field="x_vaccine_name" value="<?= $Page->vaccine_name->EditValue ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->vaccine_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_name->formatPattern()) ?>"<?= $Page->vaccine_name->editAttributes() ?> aria-describedby="x_vaccine_name_help">
<?= $Page->vaccine_name->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->vaccine_name->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->vaccine_code->Visible) { // vaccine_code ?>
    <div id="r_vaccine_code"<?= $Page->vaccine_code->rowAttributes() ?>>
        <label id="elh_tb_vaccine_vaccine_code" for="x_vaccine_code" class="<?= $Page->LeftColumnClass ?>"><?= $Page->vaccine_code->caption() ?><?= $Page->vaccine_code->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->vaccine_code->cellAttributes() ?>>
<span id="el_tb_vaccine_vaccine_code">
<input type="<?= $Page->vaccine_code->getInputTextType() ?>" name="x_vaccine_code" id="x_vaccine_code" data-table="tb_vaccine" data-field="x_vaccine_code" value="<?= $Page->vaccine_code->EditValue ?>" maxlength="10" placeholder="<?= HtmlEncode($Page->vaccine_code->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_code->formatPattern()) ?>"<?= $Page->vaccine_code->editAttributes() ?> aria-describedby="x_vaccine_code_help">
<?= $Page->vaccine_code->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->vaccine_code->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->dose_required->Visible) { // dose_required ?>
    <div id="r_dose_required"<?= $Page->dose_required->rowAttributes() ?>>
        <label id="elh_tb_vaccine_dose_required" for="x_dose_required" class="<?= $Page->LeftColumnClass ?>"><?= $Page->dose_required->caption() ?><?= $Page->dose_required->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->dose_required->cellAttributes() ?>>
<span id="el_tb_vaccine_dose_required">
<input type="<?= $Page->dose_required->getInputTextType() ?>" name="x_dose_required" id="x_dose_required" data-table="tb_vaccine" data-field="x_dose_required" value="<?= $Page->dose_required->EditValue ?>" placeholder="<?= HtmlEncode($Page->dose_required->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->dose_required->formatPattern()) ?>"<?= $Page->dose_required->editAttributes() ?> aria-describedby="x_dose_required_help">
<?= $Page->dose_required->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->dose_required->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->dose_required_uom->Visible) { // dose_required_uom ?>
    <div id="r_dose_required_uom"<?= $Page->dose_required_uom->rowAttributes() ?>>
        <label id="elh_tb_vaccine_dose_required_uom" for="x_dose_required_uom" class="<?= $Page->LeftColumnClass ?>"><?= $Page->dose_required_uom->caption() ?><?= $Page->dose_required_uom->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->dose_required_uom->cellAttributes() ?>>
<span id="el_tb_vaccine_dose_required_uom">
    <select
        id="x_dose_required_uom"
        name="x_dose_required_uom"
        class="form-select ew-select<?= $Page->dose_required_uom->isInvalidClass() ?>"
        <?php if (!$Page->dose_required_uom->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccineadd_x_dose_required_uom"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_dose_required_uom"
        data-value-separator="<?= $Page->dose_required_uom->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->dose_required_uom->getPlaceHolder()) ?>"
        <?= $Page->dose_required_uom->editAttributes() ?>>
        <?= $Page->dose_required_uom->selectOptionListHtml("x_dose_required_uom") ?>
    </select>
    <?= $Page->dose_required_uom->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->dose_required_uom->getErrorMessage() ?></div>
<?= $Page->dose_required_uom->Lookup->getParamTag($Page, "p_x_dose_required_uom") ?>
<?php if (!$Page->dose_required_uom->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccineadd", function() {
    var options = { name: "x_dose_required_uom", selectId: "ftb_vaccineadd_x_dose_required_uom" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccineadd.lists.dose_required_uom?.lookupOptions.length) {
        options.data = { id: "x_dose_required_uom", form: "ftb_vaccineadd" };
    } else {
        options.ajax = { id: "x_dose_required_uom", form: "ftb_vaccineadd", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.dose_required_uom.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->admin_mode_id->Visible) { // admin_mode_id ?>
    <div id="r_admin_mode_id"<?= $Page->admin_mode_id->rowAttributes() ?>>
        <label id="elh_tb_vaccine_admin_mode_id" for="x_admin_mode_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->admin_mode_id->caption() ?><?= $Page->admin_mode_id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->admin_mode_id->cellAttributes() ?>>
<span id="el_tb_vaccine_admin_mode_id">
    <select
        id="x_admin_mode_id"
        name="x_admin_mode_id"
        class="form-select ew-select<?= $Page->admin_mode_id->isInvalidClass() ?>"
        <?php if (!$Page->admin_mode_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccineadd_x_admin_mode_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_admin_mode_id"
        data-value-separator="<?= $Page->admin_mode_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->admin_mode_id->getPlaceHolder()) ?>"
        <?= $Page->admin_mode_id->editAttributes() ?>>
        <?= $Page->admin_mode_id->selectOptionListHtml("x_admin_mode_id") ?>
    </select>
    <?= $Page->admin_mode_id->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->admin_mode_id->getErrorMessage() ?></div>
<?= $Page->admin_mode_id->Lookup->getParamTag($Page, "p_x_admin_mode_id") ?>
<?php if (!$Page->admin_mode_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccineadd", function() {
    var options = { name: "x_admin_mode_id", selectId: "ftb_vaccineadd_x_admin_mode_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccineadd.lists.admin_mode_id?.lookupOptions.length) {
        options.data = { id: "x_admin_mode_id", form: "ftb_vaccineadd" };
    } else {
        options.ajax = { id: "x_admin_mode_id", form: "ftb_vaccineadd", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.admin_mode_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->admin_site_id->Visible) { // admin_site_id ?>
    <div id="r_admin_site_id"<?= $Page->admin_site_id->rowAttributes() ?>>
        <label id="elh_tb_vaccine_admin_site_id" for="x_admin_site_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->admin_site_id->caption() ?><?= $Page->admin_site_id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->admin_site_id->cellAttributes() ?>>
<span id="el_tb_vaccine_admin_site_id">
    <select
        id="x_admin_site_id"
        name="x_admin_site_id"
        class="form-select ew-select<?= $Page->admin_site_id->isInvalidClass() ?>"
        <?php if (!$Page->admin_site_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccineadd_x_admin_site_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_admin_site_id"
        data-value-separator="<?= $Page->admin_site_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->admin_site_id->getPlaceHolder()) ?>"
        <?= $Page->admin_site_id->editAttributes() ?>>
        <?= $Page->admin_site_id->selectOptionListHtml("x_admin_site_id") ?>
    </select>
    <?= $Page->admin_site_id->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->admin_site_id->getErrorMessage() ?></div>
<?= $Page->admin_site_id->Lookup->getParamTag($Page, "p_x_admin_site_id") ?>
<?php if (!$Page->admin_site_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccineadd", function() {
    var options = { name: "x_admin_site_id", selectId: "ftb_vaccineadd_x_admin_site_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccineadd.lists.admin_site_id?.lookupOptions.length) {
        options.data = { id: "x_admin_site_id", form: "ftb_vaccineadd" };
    } else {
        options.ajax = { id: "x_admin_site_id", form: "ftb_vaccineadd", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.admin_site_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->vaccine_form_id->Visible) { // vaccine_form_id ?>
    <div id="r_vaccine_form_id"<?= $Page->vaccine_form_id->rowAttributes() ?>>
        <label id="elh_tb_vaccine_vaccine_form_id" for="x_vaccine_form_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->vaccine_form_id->caption() ?><?= $Page->vaccine_form_id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->vaccine_form_id->cellAttributes() ?>>
<span id="el_tb_vaccine_vaccine_form_id">
    <select
        id="x_vaccine_form_id"
        name="x_vaccine_form_id"
        class="form-select ew-select<?= $Page->vaccine_form_id->isInvalidClass() ?>"
        <?php if (!$Page->vaccine_form_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccineadd_x_vaccine_form_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_vaccine_form_id"
        data-value-separator="<?= $Page->vaccine_form_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->vaccine_form_id->getPlaceHolder()) ?>"
        <?= $Page->vaccine_form_id->editAttributes() ?>>
        <?= $Page->vaccine_form_id->selectOptionListHtml("x_vaccine_form_id") ?>
    </select>
    <?= $Page->vaccine_form_id->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->vaccine_form_id->getErrorMessage() ?></div>
<?= $Page->vaccine_form_id->Lookup->getParamTag($Page, "p_x_vaccine_form_id") ?>
<?php if (!$Page->vaccine_form_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccineadd", function() {
    var options = { name: "x_vaccine_form_id", selectId: "ftb_vaccineadd_x_vaccine_form_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccineadd.lists.vaccine_form_id?.lookupOptions.length) {
        options.data = { id: "x_vaccine_form_id", form: "ftb_vaccineadd" };
    } else {
        options.ajax = { id: "x_vaccine_form_id", form: "ftb_vaccineadd", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.vaccine_form_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->expiry_date->Visible) { // expiry_date ?>
    <div id="r_expiry_date"<?= $Page->expiry_date->rowAttributes() ?>>
        <label id="elh_tb_vaccine_expiry_date" for="x_expiry_date" class="<?= $Page->LeftColumnClass ?>"><?= $Page->expiry_date->caption() ?><?= $Page->expiry_date->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->expiry_date->cellAttributes() ?>>
<span id="el_tb_vaccine_expiry_date">
<input type="<?= $Page->expiry_date->getInputTextType() ?>" name="x_expiry_date" id="x_expiry_date" data-table="tb_vaccine" data-field="x_expiry_date" value="<?= $Page->expiry_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->expiry_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->expiry_date->formatPattern()) ?>"<?= $Page->expiry_date->editAttributes() ?> aria-describedby="x_expiry_date_help">
<?= $Page->expiry_date->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->expiry_date->getErrorMessage() ?></div>
<?php if (!$Page->expiry_date->ReadOnly && !$Page->expiry_date->Disabled && !isset($Page->expiry_date->EditAttrs["readonly"]) && !isset($Page->expiry_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_vaccineadd", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_vaccineadd", "x_expiry_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->target_group->Visible) { // target_group ?>
    <div id="r_target_group"<?= $Page->target_group->rowAttributes() ?>>
        <label id="elh_tb_vaccine_target_group" for="x_target_group" class="<?= $Page->LeftColumnClass ?>"><?= $Page->target_group->caption() ?><?= $Page->target_group->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->target_group->cellAttributes() ?>>
<span id="el_tb_vaccine_target_group">
    <select
        id="x_target_group"
        name="x_target_group"
        class="form-select ew-select<?= $Page->target_group->isInvalidClass() ?>"
        <?php if (!$Page->target_group->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccineadd_x_target_group"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_target_group"
        data-value-separator="<?= $Page->target_group->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->target_group->getPlaceHolder()) ?>"
        <?= $Page->target_group->editAttributes() ?>>
        <?= $Page->target_group->selectOptionListHtml("x_target_group") ?>
    </select>
    <?= $Page->target_group->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->target_group->getErrorMessage() ?></div>
<?php if (!$Page->target_group->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccineadd", function() {
    var options = { name: "x_target_group", selectId: "ftb_vaccineadd_x_target_group" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccineadd.lists.target_group?.lookupOptions.length) {
        options.data = { id: "x_target_group", form: "ftb_vaccineadd" };
    } else {
        options.ajax = { id: "x_target_group", form: "ftb_vaccineadd", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.target_group.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->storage_condition->Visible) { // storage_condition ?>
    <div id="r_storage_condition"<?= $Page->storage_condition->rowAttributes() ?>>
        <label id="elh_tb_vaccine_storage_condition" for="x_storage_condition" class="<?= $Page->LeftColumnClass ?>"><?= $Page->storage_condition->caption() ?><?= $Page->storage_condition->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->storage_condition->cellAttributes() ?>>
<span id="el_tb_vaccine_storage_condition">
<input type="<?= $Page->storage_condition->getInputTextType() ?>" name="x_storage_condition" id="x_storage_condition" data-table="tb_vaccine" data-field="x_storage_condition" value="<?= $Page->storage_condition->EditValue ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->storage_condition->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->storage_condition->formatPattern()) ?>"<?= $Page->storage_condition->editAttributes() ?> aria-describedby="x_storage_condition_help">
<?= $Page->storage_condition->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->storage_condition->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->description->Visible) { // description ?>
    <div id="r_description"<?= $Page->description->rowAttributes() ?>>
        <label id="elh_tb_vaccine_description" for="x_description" class="<?= $Page->LeftColumnClass ?>"><?= $Page->description->caption() ?><?= $Page->description->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->description->cellAttributes() ?>>
<span id="el_tb_vaccine_description">
<textarea data-table="tb_vaccine" data-field="x_description" name="x_description" id="x_description" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->description->getPlaceHolder()) ?>"<?= $Page->description->editAttributes() ?> aria-describedby="x_description_help"><?= $Page->description->EditValue ?></textarea>
<?= $Page->description->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->description->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_vaccineadd"><?= $Language->phrase("AddBtn") ?></button>
<?php if (IsJsonResponse()) { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-bs-dismiss="modal"><?= $Language->phrase("CancelBtn") ?></button>
<?php } else { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_vaccineadd" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
<?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_vaccine");
});
</script>
<script>
loadjs.ready("load", function () {
    // Startup script
    // Write your table-specific startup script here, no need to add script tags.
    // Write your table-specific startup script here, no need to add script tags.
    $('.form-control[type="tel"]').addClass('form-control-sm w-100');
    $('.form-control[type="text"]').addClass('form-control-sm w-100');
    $('.form-control[type="email"]').addClass('form-control-sm w-100');
    $('.form-control.tt-input[type="text"]').addClass('form-control-sm w-100');
    $('[class="form-select ew-select"]').addClass('form-select-sm w-100')
    $('[class="custom-select ew-custom-select"]').addClass('w-100').removeClass('ew-custom-select');
});
</script>
