<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbAdministrationSiteList = &$Page;
?>
<?php if (!$Page->isExport()) { ?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_administration_site: currentTable } });
var currentPageID = ew.PAGE_ID = "list";
var currentForm;
var <?= $Page->FormName ?>;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("<?= $Page->FormName ?>")
        .setPageId("list")
        .setSubmitWithFetch(<?= $Page->UseAjaxActions ? "true" : "false" ?>)
        .setFormKeyCountName("<?= $Page->FormKeyCountName ?>")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php } ?>
<?php if (!$Page->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($Page->TotalRecords > 0 && $Page->ExportOptions->visible()) { ?>
<?php $Page->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($Page->ImportOptions->visible()) { ?>
<?php $Page->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($Page->SearchOptions->visible()) { ?>
<?php $Page->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($Page->FilterOptions->visible()) { ?>
<?php $Page->FilterOptions->render("body") ?>
<?php } ?>
</div>
<?php } ?>
<?php if (!$Page->IsModal) { ?>
<form name="ftb_administration_sitesrch" id="ftb_administration_sitesrch" class="ew-form ew-ext-search-form" action="<?= CurrentPageUrl(false) ?>" novalidate autocomplete="off">
<div id="ftb_administration_sitesrch_search_panel" class="mb-2 mb-sm-0 <?= $Page->SearchPanelClass ?>"><!-- .ew-search-panel -->
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_administration_site: currentTable } });
var currentForm;
var ftb_administration_sitesrch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_administration_sitesrch")
        .setPageId("list")
<?php if ($Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Dynamic selection lists
        .setLists({
        })

        // Filters
        .setFilterList(<?= $Page->getFilterList() ?>)
        .build();
    window[form.id] = form;
    currentSearchForm = form;
    loadjs.done(form.id);
});
</script>
<input type="hidden" name="cmd" value="search">
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="list<?= ($Page->TotalRecords == 0 && !$Page->isAdd()) ? " ew-no-record" : "" ?>">
<div id="ew-list">
<?php if ($Page->TotalRecords > 0 || $Page->CurrentAction) { ?>
<div class="card ew-card ew-grid<?= $Page->isAddOrEdit() ? " ew-grid-add-edit" : "" ?> <?= $Page->TableGridClass ?>">
<?php if (!$Page->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$Page->isGridAdd() && !($Page->isGridEdit() && $Page->ModalGridEdit) && !$Page->isMultiEdit()) { ?>
<?= $Page->Pager->render() ?>
<?php } ?>
<div class="ew-list-other-options">
<?php $Page->OtherOptions->render("body") ?>
</div>
</div>
<?php } ?>
<form name="<?= $Page->FormName ?>" id="<?= $Page->FormName ?>" class="ew-form ew-list-form" action="<?= $Page->PageAction ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_administration_site">
<?php if ($Page->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<div id="gmp_tb_administration_site" class="card-body ew-grid-middle-panel <?= $Page->TableContainerClass ?>" style="<?= $Page->TableContainerStyle ?>">
<?php if ($Page->TotalRecords > 0 || $Page->isGridEdit() || $Page->isMultiEdit()) { ?>
<table id="tbl_tb_administration_sitelist" class="<?= $Page->TableClass ?>"><!-- .ew-table -->
<thead>
    <tr class="ew-table-header">
<?php
// Header row
$Page->RowType = ROWTYPE_HEADER;

// Render list options
$Page->renderListOptions();

// Render list options (header, left)
$Page->ListOptions->render("header", "left");
?>
<?php if ($Page->id->Visible) { // id ?>
        <th data-name="id" class="<?= $Page->id->headerCellClass() ?>"><div id="elh_tb_administration_site_id" class="tb_administration_site_id"><?= $Page->renderFieldHeader($Page->id) ?></div></th>
<?php } ?>
<?php if ($Page->site_name->Visible) { // site_name ?>
        <th data-name="site_name" class="<?= $Page->site_name->headerCellClass() ?>"><div id="elh_tb_administration_site_site_name" class="tb_administration_site_site_name"><?= $Page->renderFieldHeader($Page->site_name) ?></div></th>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <th data-name="entry_date" class="<?= $Page->entry_date->headerCellClass() ?>"><div id="elh_tb_administration_site_entry_date" class="tb_administration_site_entry_date"><?= $Page->renderFieldHeader($Page->entry_date) ?></div></th>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <th data-name="last_modified" class="<?= $Page->last_modified->headerCellClass() ?>"><div id="elh_tb_administration_site_last_modified" class="tb_administration_site_last_modified"><?= $Page->renderFieldHeader($Page->last_modified) ?></div></th>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <th data-name="entered_by" class="<?= $Page->entered_by->headerCellClass() ?>"><div id="elh_tb_administration_site_entered_by" class="tb_administration_site_entered_by"><?= $Page->renderFieldHeader($Page->entered_by) ?></div></th>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <th data-name="modified_by" class="<?= $Page->modified_by->headerCellClass() ?>"><div id="elh_tb_administration_site_modified_by" class="tb_administration_site_modified_by"><?= $Page->renderFieldHeader($Page->modified_by) ?></div></th>
<?php } ?>
<?php
// Render list options (header, right)
$Page->ListOptions->render("header", "right");
?>
    </tr>
</thead>
<tbody data-page="<?= $Page->getPageNumber() ?>">
<?php
$Page->setupGrid();
while ($Page->RecordCount < $Page->StopRecord || $Page->RowIndex === '$rowindex$') {
    $Page->RecordCount++;
    if ($Page->RecordCount >= $Page->StartRecord) {
        $Page->setupRow();
?>
    <tr <?= $Page->rowAttributes() ?>>
<?php
// Render list options (body, left)
$Page->ListOptions->render("body", "left", $Page->RowCount);
?>
    <?php if ($Page->id->Visible) { // id ?>
        <td data-name="id"<?= $Page->id->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_administration_site_id" class="el_tb_administration_site_id">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->site_name->Visible) { // site_name ?>
        <td data-name="site_name"<?= $Page->site_name->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_administration_site_site_name" class="el_tb_administration_site_site_name">
<span<?= $Page->site_name->viewAttributes() ?>>
<?= $Page->site_name->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->entry_date->Visible) { // entry_date ?>
        <td data-name="entry_date"<?= $Page->entry_date->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_administration_site_entry_date" class="el_tb_administration_site_entry_date">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->last_modified->Visible) { // last_modified ?>
        <td data-name="last_modified"<?= $Page->last_modified->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_administration_site_last_modified" class="el_tb_administration_site_last_modified">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->entered_by->Visible) { // entered_by ?>
        <td data-name="entered_by"<?= $Page->entered_by->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_administration_site_entered_by" class="el_tb_administration_site_entered_by">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->modified_by->Visible) { // modified_by ?>
        <td data-name="modified_by"<?= $Page->modified_by->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_administration_site_modified_by" class="el_tb_administration_site_modified_by">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
<?php
// Render list options (body, right)
$Page->ListOptions->render("body", "right", $Page->RowCount);
?>
    </tr>
<?php if ($Page->RowType == ROWTYPE_VIEW) { ?>
<?php
    // Render row
    $Page->RowType = ROWTYPE_PREVIEW_FIELD; // Preview field
    $Page->resetAttributes();
    $Page->renderRow();
    $Page->renderListOptions();
?>
    <tr <?= $Page->rowAttributes() ?>>
        <td data-name="description" colspan="<?= $Page->ListOptions->visibleCount() + $Page->visibleFieldCount() ?>"<?= $Page->description->cellAttributes() ?>><p class="ew-preview-field" style="display: none">
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_administration_site_description" class="el_tb_administration_site_description">
<span<?= $Page->description->viewAttributes() ?>>
<?= $Page->description->getViewValue() ?></span>
</span>
</p></td>
    </tr>
<?php } ?>
<?php
    }
    if (
        $Page->Recordset &&
        !$Page->Recordset->EOF &&
        $Page->RowIndex !== '$rowindex$' &&
        (!$Page->isGridAdd() || $Page->CurrentMode == "copy") &&
        (!(($Page->isCopy() || $Page->isAdd()) && $Page->RowIndex == 0))
    ) {
        $Page->Recordset->moveNext();
    }
    // Reset for template row
    if ($Page->RowIndex === '$rowindex$') {
        $Page->RowIndex = 0;
    }
    // Reset inline add/copy row
    if (($Page->isCopy() || $Page->isAdd()) && $Page->RowIndex == 0) {
        $Page->RowIndex = 1;
    }
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$Page->CurrentAction && !$Page->UseAjaxActions) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php
// Close recordset
if ($Page->Recordset) {
    $Page->Recordset->close();
}
?>
<?php if (!$Page->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$Page->isGridAdd() && !($Page->isGridEdit() && $Page->ModalGridEdit) && !$Page->isMultiEdit()) { ?>
<?= $Page->Pager->render() ?>
<?php } ?>
<div class="ew-list-other-options">
<?php $Page->OtherOptions->render("body", "bottom") ?>
</div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } else { ?>
<div class="ew-list-other-options">
<?php $Page->OtherOptions->render("body") ?>
</div>
<?php } ?>
</div>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<?php if (!$Page->isExport()) { ?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_administration_site");
});
</script>
<script>
loadjs.ready("load", function () {
    // Startup script
    // Write your table-specific startup script here, no need to add script tags.
    <?php
    	$current_table = CurrentPage()->TableName;

        // Convert underscores to dashes
        $new_current_table = str_replace('_', '-', $current_table);

        /* pass to javascript */
    	echo "var current_table = \"".$current_table."\";"; 
    	echo "var new_current_table = \"".$new_current_table."\";"; 
    ?>

    //Set Width to cover full page
    $('[class="card ew-card ew-grid '+new_current_table+'"]').css("width", "100%");

    //For Aggregate Fields/Columns
    $('[class="ew-aggregate"]').css({"font-weight":"bold", "color":"rgb(23, 125, 78)"});
    $('[class="ew-aggregate-value"]').css({"font-weight":"bold", "color":"rgb(23, 125, 78)"});
    $('[class="ew-aggregate"]').addClass("d-block");
    $('[class="ew-aggregate-value"]').addClass("d-block");

    //Limit Field sizes to the smallest width
    $('[class="ew-list-option-header"]').css("width", "1%");
    $('[data-name="checkbox"]').css("width", "1%");
    $('[data-name="view"]').css("width", "1%");
    $('[data-name="edit"]').css("width", "1%");
    $('[data-name="copy"]').css("width", "1%");
    $('[data-name="id"]').css("width", "1%");
    $('[id="tbl_'+current_table+'list"]').css({"min-width":"100%", "border":"1px solid #cccccc"});
    $('[class="alert alert-warning alert-dismissible ew-warning"]').addClass("py-1 px-2");
    $('[class="alert alert-success alert-dismissible ew-success"]').addClass("py-1 px-2");

    // Optionally, ensure the text is "New Order" in case it's missing
    $('a.ew-add').append('&nbsp;Add&nbsp;New&nbsp;Record');

    // Find the anchor tag by its class and update the class to btn-success
    $('a.ew-add').removeClass('btn-default').addClass('btn-success');
    $('button.ew-multi-delete').removeClass('btn-default').addClass('btn-danger');
    $('button.ew-multi-delete').append('&nbsp;Delete&nbsp;Record(s)');
});
</script>
<?php } ?>
