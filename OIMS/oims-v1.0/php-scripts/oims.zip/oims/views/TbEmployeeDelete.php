<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbEmployeeDelete = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_employee: currentTable } });
var currentPageID = ew.PAGE_ID = "delete";
var currentForm;
var ftb_employeedelete;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_employeedelete")
        .setPageId("delete")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_employeedelete" id="ftb_employeedelete" class="ew-form ew-delete-form" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_employee">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($Page->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?= HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid <?= $Page->TableGridClass ?>">
<div class="card-body ew-grid-middle-panel <?= $Page->TableContainerClass ?>" style="<?= $Page->TableContainerStyle ?>">
<table class="<?= $Page->TableClass ?>">
    <thead>
    <tr class="ew-table-header">
<?php if ($Page->id->Visible) { // id ?>
        <th class="<?= $Page->id->headerCellClass() ?>"><span id="elh_tb_employee_id" class="tb_employee_id"><?= $Page->id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->employee_number->Visible) { // employee_number ?>
        <th class="<?= $Page->employee_number->headerCellClass() ?>"><span id="elh_tb_employee_employee_number" class="tb_employee_employee_number"><?= $Page->employee_number->caption() ?></span></th>
<?php } ?>
<?php if ($Page->first_name->Visible) { // first_name ?>
        <th class="<?= $Page->first_name->headerCellClass() ?>"><span id="elh_tb_employee_first_name" class="tb_employee_first_name"><?= $Page->first_name->caption() ?></span></th>
<?php } ?>
<?php if ($Page->last_name->Visible) { // last_name ?>
        <th class="<?= $Page->last_name->headerCellClass() ?>"><span id="elh_tb_employee_last_name" class="tb_employee_last_name"><?= $Page->last_name->caption() ?></span></th>
<?php } ?>
<?php if ($Page->other_name->Visible) { // other_name ?>
        <th class="<?= $Page->other_name->headerCellClass() ?>"><span id="elh_tb_employee_other_name" class="tb_employee_other_name"><?= $Page->other_name->caption() ?></span></th>
<?php } ?>
<?php if ($Page->job_tile->Visible) { // job_tile ?>
        <th class="<?= $Page->job_tile->headerCellClass() ?>"><span id="elh_tb_employee_job_tile" class="tb_employee_job_tile"><?= $Page->job_tile->caption() ?></span></th>
<?php } ?>
<?php if ($Page->pri_phone_no->Visible) { // pri_phone_no ?>
        <th class="<?= $Page->pri_phone_no->headerCellClass() ?>"><span id="elh_tb_employee_pri_phone_no" class="tb_employee_pri_phone_no"><?= $Page->pri_phone_no->caption() ?></span></th>
<?php } ?>
<?php if ($Page->alt_phone_no->Visible) { // alt_phone_no ?>
        <th class="<?= $Page->alt_phone_no->headerCellClass() ?>"><span id="elh_tb_employee_alt_phone_no" class="tb_employee_alt_phone_no"><?= $Page->alt_phone_no->caption() ?></span></th>
<?php } ?>
<?php if ($Page->personal_email->Visible) { // personal_email ?>
        <th class="<?= $Page->personal_email->headerCellClass() ?>"><span id="elh_tb_employee_personal_email" class="tb_employee_personal_email"><?= $Page->personal_email->caption() ?></span></th>
<?php } ?>
<?php if ($Page->official_email->Visible) { // official_email ?>
        <th class="<?= $Page->official_email->headerCellClass() ?>"><span id="elh_tb_employee_official_email" class="tb_employee_official_email"><?= $Page->official_email->caption() ?></span></th>
<?php } ?>
<?php if ($Page->department->Visible) { // department ?>
        <th class="<?= $Page->department->headerCellClass() ?>"><span id="elh_tb_employee_department" class="tb_employee_department"><?= $Page->department->caption() ?></span></th>
<?php } ?>
<?php if ($Page->hire_date->Visible) { // hire_date ?>
        <th class="<?= $Page->hire_date->headerCellClass() ?>"><span id="elh_tb_employee_hire_date" class="tb_employee_hire_date"><?= $Page->hire_date->caption() ?></span></th>
<?php } ?>
<?php if ($Page->current_status->Visible) { // current_status ?>
        <th class="<?= $Page->current_status->headerCellClass() ?>"><span id="elh_tb_employee_current_status" class="tb_employee_current_status"><?= $Page->current_status->caption() ?></span></th>
<?php } ?>
<?php if ($Page->tin_number->Visible) { // tin_number ?>
        <th class="<?= $Page->tin_number->headerCellClass() ?>"><span id="elh_tb_employee_tin_number" class="tb_employee_tin_number"><?= $Page->tin_number->caption() ?></span></th>
<?php } ?>
<?php if ($Page->nssf_number->Visible) { // nssf_number ?>
        <th class="<?= $Page->nssf_number->headerCellClass() ?>"><span id="elh_tb_employee_nssf_number" class="tb_employee_nssf_number"><?= $Page->nssf_number->caption() ?></span></th>
<?php } ?>
<?php if ($Page->salary_amount->Visible) { // salary_amount ?>
        <th class="<?= $Page->salary_amount->headerCellClass() ?>"><span id="elh_tb_employee_salary_amount" class="tb_employee_salary_amount"><?= $Page->salary_amount->caption() ?></span></th>
<?php } ?>
<?php if ($Page->employement_type->Visible) { // employement_type ?>
        <th class="<?= $Page->employement_type->headerCellClass() ?>"><span id="elh_tb_employee_employement_type" class="tb_employee_employement_type"><?= $Page->employement_type->caption() ?></span></th>
<?php } ?>
<?php if ($Page->work_schedule->Visible) { // work_schedule ?>
        <th class="<?= $Page->work_schedule->headerCellClass() ?>"><span id="elh_tb_employee_work_schedule" class="tb_employee_work_schedule"><?= $Page->work_schedule->caption() ?></span></th>
<?php } ?>
<?php if ($Page->sex->Visible) { // sex ?>
        <th class="<?= $Page->sex->headerCellClass() ?>"><span id="elh_tb_employee_sex" class="tb_employee_sex"><?= $Page->sex->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <th class="<?= $Page->entry_date->headerCellClass() ?>"><span id="elh_tb_employee_entry_date" class="tb_employee_entry_date"><?= $Page->entry_date->caption() ?></span></th>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <th class="<?= $Page->last_modified->headerCellClass() ?>"><span id="elh_tb_employee_last_modified" class="tb_employee_last_modified"><?= $Page->last_modified->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <th class="<?= $Page->entered_by->headerCellClass() ?>"><span id="elh_tb_employee_entered_by" class="tb_employee_entered_by"><?= $Page->entered_by->caption() ?></span></th>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <th class="<?= $Page->modified_by->headerCellClass() ?>"><span id="elh_tb_employee_modified_by" class="tb_employee_modified_by"><?= $Page->modified_by->caption() ?></span></th>
<?php } ?>
    </tr>
    </thead>
    <tbody>
<?php
$Page->RecordCount = 0;
$i = 0;
while (!$Page->Recordset->EOF) {
    $Page->RecordCount++;
    $Page->RowCount++;

    // Set row properties
    $Page->resetAttributes();
    $Page->RowType = ROWTYPE_VIEW; // View

    // Get the field contents
    $Page->loadRowValues($Page->Recordset);

    // Render row
    $Page->renderRow();
?>
    <tr <?= $Page->rowAttributes() ?>>
<?php if ($Page->id->Visible) { // id ?>
        <td<?= $Page->id->cellAttributes() ?>>
<span id="">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->employee_number->Visible) { // employee_number ?>
        <td<?= $Page->employee_number->cellAttributes() ?>>
<span id="">
<span<?= $Page->employee_number->viewAttributes() ?>>
<?= $Page->employee_number->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->first_name->Visible) { // first_name ?>
        <td<?= $Page->first_name->cellAttributes() ?>>
<span id="">
<span<?= $Page->first_name->viewAttributes() ?>>
<?= $Page->first_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->last_name->Visible) { // last_name ?>
        <td<?= $Page->last_name->cellAttributes() ?>>
<span id="">
<span<?= $Page->last_name->viewAttributes() ?>>
<?= $Page->last_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->other_name->Visible) { // other_name ?>
        <td<?= $Page->other_name->cellAttributes() ?>>
<span id="">
<span<?= $Page->other_name->viewAttributes() ?>>
<?= $Page->other_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->job_tile->Visible) { // job_tile ?>
        <td<?= $Page->job_tile->cellAttributes() ?>>
<span id="">
<span<?= $Page->job_tile->viewAttributes() ?>>
<?= $Page->job_tile->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->pri_phone_no->Visible) { // pri_phone_no ?>
        <td<?= $Page->pri_phone_no->cellAttributes() ?>>
<span id="">
<span<?= $Page->pri_phone_no->viewAttributes() ?>>
<?= $Page->pri_phone_no->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->alt_phone_no->Visible) { // alt_phone_no ?>
        <td<?= $Page->alt_phone_no->cellAttributes() ?>>
<span id="">
<span<?= $Page->alt_phone_no->viewAttributes() ?>>
<?= $Page->alt_phone_no->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->personal_email->Visible) { // personal_email ?>
        <td<?= $Page->personal_email->cellAttributes() ?>>
<span id="">
<span<?= $Page->personal_email->viewAttributes() ?>>
<?= $Page->personal_email->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->official_email->Visible) { // official_email ?>
        <td<?= $Page->official_email->cellAttributes() ?>>
<span id="">
<span<?= $Page->official_email->viewAttributes() ?>>
<?= $Page->official_email->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->department->Visible) { // department ?>
        <td<?= $Page->department->cellAttributes() ?>>
<span id="">
<span<?= $Page->department->viewAttributes() ?>>
<?= $Page->department->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->hire_date->Visible) { // hire_date ?>
        <td<?= $Page->hire_date->cellAttributes() ?>>
<span id="">
<span<?= $Page->hire_date->viewAttributes() ?>>
<?= $Page->hire_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->current_status->Visible) { // current_status ?>
        <td<?= $Page->current_status->cellAttributes() ?>>
<span id="">
<span<?= $Page->current_status->viewAttributes() ?>>
<?= $Page->current_status->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->tin_number->Visible) { // tin_number ?>
        <td<?= $Page->tin_number->cellAttributes() ?>>
<span id="">
<span<?= $Page->tin_number->viewAttributes() ?>>
<?= $Page->tin_number->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->nssf_number->Visible) { // nssf_number ?>
        <td<?= $Page->nssf_number->cellAttributes() ?>>
<span id="">
<span<?= $Page->nssf_number->viewAttributes() ?>>
<?= $Page->nssf_number->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->salary_amount->Visible) { // salary_amount ?>
        <td<?= $Page->salary_amount->cellAttributes() ?>>
<span id="">
<span<?= $Page->salary_amount->viewAttributes() ?>>
<?= $Page->salary_amount->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->employement_type->Visible) { // employement_type ?>
        <td<?= $Page->employement_type->cellAttributes() ?>>
<span id="">
<span<?= $Page->employement_type->viewAttributes() ?>>
<?= $Page->employement_type->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->work_schedule->Visible) { // work_schedule ?>
        <td<?= $Page->work_schedule->cellAttributes() ?>>
<span id="">
<span<?= $Page->work_schedule->viewAttributes() ?>>
<?= $Page->work_schedule->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->sex->Visible) { // sex ?>
        <td<?= $Page->sex->cellAttributes() ?>>
<span id="">
<span<?= $Page->sex->viewAttributes() ?>>
<?= $Page->sex->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <td<?= $Page->entry_date->cellAttributes() ?>>
<span id="">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <td<?= $Page->last_modified->cellAttributes() ?>>
<span id="">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <td<?= $Page->entered_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <td<?= $Page->modified_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
    </tr>
<?php
    $Page->Recordset->moveNext();
}
$Page->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div class="ew-buttons ew-desktop-buttons">
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?= $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
