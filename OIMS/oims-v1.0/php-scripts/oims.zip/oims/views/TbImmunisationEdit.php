<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbImmunisationEdit = &$Page;
?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="edit">
<form name="ftb_immunisationedit" id="ftb_immunisationedit" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_immunisation: currentTable } });
var currentPageID = ew.PAGE_ID = "edit";
var currentForm;
var ftb_immunisationedit;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_immunisationedit")
        .setPageId("edit")

        // Add fields
        .setFields([
            ["id", [fields.id.visible && fields.id.required ? ew.Validators.required(fields.id.caption) : null], fields.id.isInvalid],
            ["vaccination_date", [fields.vaccination_date.visible && fields.vaccination_date.required ? ew.Validators.required(fields.vaccination_date.caption) : null, ew.Validators.datetime(fields.vaccination_date.clientFormatPattern)], fields.vaccination_date.isInvalid],
            ["child_id", [fields.child_id.visible && fields.child_id.required ? ew.Validators.required(fields.child_id.caption) : null], fields.child_id.isInvalid],
            ["vaccine_id", [fields.vaccine_id.visible && fields.vaccine_id.required ? ew.Validators.required(fields.vaccine_id.caption) : null], fields.vaccine_id.isInvalid],
            ["dose_cycle", [fields.dose_cycle.visible && fields.dose_cycle.required ? ew.Validators.required(fields.dose_cycle.caption) : null], fields.dose_cycle.isInvalid],
            ["next_vaccination_date", [fields.next_vaccination_date.visible && fields.next_vaccination_date.required ? ew.Validators.required(fields.next_vaccination_date.caption) : null, ew.Validators.datetime(fields.next_vaccination_date.clientFormatPattern)], fields.next_vaccination_date.isInvalid],
            ["administered_by", [fields.administered_by.visible && fields.administered_by.required ? ew.Validators.required(fields.administered_by.caption) : null], fields.administered_by.isInvalid],
            ["remarks", [fields.remarks.visible && fields.remarks.required ? ew.Validators.required(fields.remarks.caption) : null], fields.remarks.isInvalid],
            ["entry_date", [fields.entry_date.visible && fields.entry_date.required ? ew.Validators.required(fields.entry_date.caption) : null], fields.entry_date.isInvalid],
            ["last_modified", [fields.last_modified.visible && fields.last_modified.required ? ew.Validators.required(fields.last_modified.caption) : null], fields.last_modified.isInvalid],
            ["entered_by", [fields.entered_by.visible && fields.entered_by.required ? ew.Validators.required(fields.entered_by.caption) : null], fields.entered_by.isInvalid],
            ["modified_by", [fields.modified_by.visible && fields.modified_by.required ? ew.Validators.required(fields.modified_by.caption) : null], fields.modified_by.isInvalid]
        ])

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "child_id": <?= $Page->child_id->toClientList($Page) ?>,
            "vaccine_id": <?= $Page->vaccine_id->toClientList($Page) ?>,
            "dose_cycle": <?= $Page->dose_cycle->toClientList($Page) ?>,
            "administered_by": <?= $Page->administered_by->toClientList($Page) ?>,
            "entered_by": <?= $Page->entered_by->toClientList($Page) ?>,
            "modified_by": <?= $Page->modified_by->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_immunisation">
<input type="hidden" name="action" id="action" value="update">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<?php if (IsJsonResponse()) { ?>
<input type="hidden" name="json" value="1">
<?php } ?>
<input type="hidden" name="<?= $Page->OldKeyName ?>" value="<?= $Page->OldKey ?>">
<div class="ew-edit-div"><!-- page* -->
<?php if ($Page->id->Visible) { // id ?>
    <div id="r_id"<?= $Page->id->rowAttributes() ?>>
        <label id="elh_tb_immunisation_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->id->caption() ?><?= $Page->id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->id->cellAttributes() ?>>
<span id="el_tb_immunisation_id">
<span<?= $Page->id->viewAttributes() ?>>
<input type="text" readonly class="form-control-plaintext" value="<?= HtmlEncode(RemoveHtml($Page->id->getDisplayValue($Page->id->EditValue))) ?>"></span>
<input type="hidden" data-table="tb_immunisation" data-field="x_id" data-hidden="1" name="x_id" id="x_id" value="<?= HtmlEncode($Page->id->CurrentValue) ?>">
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->vaccination_date->Visible) { // vaccination_date ?>
    <div id="r_vaccination_date"<?= $Page->vaccination_date->rowAttributes() ?>>
        <label id="elh_tb_immunisation_vaccination_date" for="x_vaccination_date" class="<?= $Page->LeftColumnClass ?>"><?= $Page->vaccination_date->caption() ?><?= $Page->vaccination_date->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->vaccination_date->cellAttributes() ?>>
<span id="el_tb_immunisation_vaccination_date">
<input type="<?= $Page->vaccination_date->getInputTextType() ?>" name="x_vaccination_date" id="x_vaccination_date" data-table="tb_immunisation" data-field="x_vaccination_date" value="<?= $Page->vaccination_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->vaccination_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccination_date->formatPattern()) ?>"<?= $Page->vaccination_date->editAttributes() ?> aria-describedby="x_vaccination_date_help">
<?= $Page->vaccination_date->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->vaccination_date->getErrorMessage() ?></div>
<?php if (!$Page->vaccination_date->ReadOnly && !$Page->vaccination_date->Disabled && !isset($Page->vaccination_date->EditAttrs["readonly"]) && !isset($Page->vaccination_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_immunisationedit", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_immunisationedit", "x_vaccination_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->child_id->Visible) { // child_id ?>
    <div id="r_child_id"<?= $Page->child_id->rowAttributes() ?>>
        <label id="elh_tb_immunisation_child_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->child_id->caption() ?><?= $Page->child_id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->child_id->cellAttributes() ?>>
<span id="el_tb_immunisation_child_id">
<?php
if (IsRTL()) {
    $Page->child_id->EditAttrs["dir"] = "rtl";
}
?>
<span id="as_x_child_id" class="ew-auto-suggest">
    <input type="<?= $Page->child_id->getInputTextType() ?>" class="form-control" name="sv_x_child_id" id="sv_x_child_id" value="<?= RemoveHtml($Page->child_id->EditValue) ?>" autocomplete="off" placeholder="<?= HtmlEncode($Page->child_id->getPlaceHolder()) ?>" data-placeholder="<?= HtmlEncode($Page->child_id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->child_id->formatPattern()) ?>"<?= $Page->child_id->editAttributes() ?> aria-describedby="x_child_id_help">
</span>
<selection-list hidden class="form-control" data-table="tb_immunisation" data-field="x_child_id" data-input="sv_x_child_id" data-value-separator="<?= $Page->child_id->displayValueSeparatorAttribute() ?>" name="x_child_id" id="x_child_id" value="<?= HtmlEncode($Page->child_id->CurrentValue) ?>"></selection-list>
<?= $Page->child_id->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->child_id->getErrorMessage() ?></div>
<script>
loadjs.ready("ftb_immunisationedit", function() {
    ftb_immunisationedit.createAutoSuggest(Object.assign({"id":"x_child_id","forceSelect":true}, { lookupAllDisplayFields: <?= $Page->child_id->Lookup->LookupAllDisplayFields ? "true" : "false" ?> }, ew.vars.tables.tb_immunisation.fields.child_id.autoSuggestOptions));
});
</script>
<?= $Page->child_id->Lookup->getParamTag($Page, "p_x_child_id") ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->vaccine_id->Visible) { // vaccine_id ?>
    <div id="r_vaccine_id"<?= $Page->vaccine_id->rowAttributes() ?>>
        <label id="elh_tb_immunisation_vaccine_id" class="<?= $Page->LeftColumnClass ?>"><?= $Page->vaccine_id->caption() ?><?= $Page->vaccine_id->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->vaccine_id->cellAttributes() ?>>
<span id="el_tb_immunisation_vaccine_id">
<?php
if (IsRTL()) {
    $Page->vaccine_id->EditAttrs["dir"] = "rtl";
}
?>
<span id="as_x_vaccine_id" class="ew-auto-suggest">
    <input type="<?= $Page->vaccine_id->getInputTextType() ?>" class="form-control" name="sv_x_vaccine_id" id="sv_x_vaccine_id" value="<?= RemoveHtml($Page->vaccine_id->EditValue) ?>" autocomplete="off" placeholder="<?= HtmlEncode($Page->vaccine_id->getPlaceHolder()) ?>" data-placeholder="<?= HtmlEncode($Page->vaccine_id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_id->formatPattern()) ?>"<?= $Page->vaccine_id->editAttributes() ?> aria-describedby="x_vaccine_id_help">
</span>
<selection-list hidden class="form-control" data-table="tb_immunisation" data-field="x_vaccine_id" data-input="sv_x_vaccine_id" data-value-separator="<?= $Page->vaccine_id->displayValueSeparatorAttribute() ?>" name="x_vaccine_id" id="x_vaccine_id" value="<?= HtmlEncode($Page->vaccine_id->CurrentValue) ?>"></selection-list>
<?= $Page->vaccine_id->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->vaccine_id->getErrorMessage() ?></div>
<script>
loadjs.ready("ftb_immunisationedit", function() {
    ftb_immunisationedit.createAutoSuggest(Object.assign({"id":"x_vaccine_id","forceSelect":true}, { lookupAllDisplayFields: <?= $Page->vaccine_id->Lookup->LookupAllDisplayFields ? "true" : "false" ?> }, ew.vars.tables.tb_immunisation.fields.vaccine_id.autoSuggestOptions));
});
</script>
<?= $Page->vaccine_id->Lookup->getParamTag($Page, "p_x_vaccine_id") ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->dose_cycle->Visible) { // dose_cycle ?>
    <div id="r_dose_cycle"<?= $Page->dose_cycle->rowAttributes() ?>>
        <label id="elh_tb_immunisation_dose_cycle" for="x_dose_cycle" class="<?= $Page->LeftColumnClass ?>"><?= $Page->dose_cycle->caption() ?><?= $Page->dose_cycle->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->dose_cycle->cellAttributes() ?>>
<span id="el_tb_immunisation_dose_cycle">
    <select
        id="x_dose_cycle"
        name="x_dose_cycle"
        class="form-select ew-select<?= $Page->dose_cycle->isInvalidClass() ?>"
        <?php if (!$Page->dose_cycle->IsNativeSelect) { ?>
        data-select2-id="ftb_immunisationedit_x_dose_cycle"
        <?php } ?>
        data-table="tb_immunisation"
        data-field="x_dose_cycle"
        data-value-separator="<?= $Page->dose_cycle->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->dose_cycle->getPlaceHolder()) ?>"
        <?= $Page->dose_cycle->editAttributes() ?>>
        <?= $Page->dose_cycle->selectOptionListHtml("x_dose_cycle") ?>
    </select>
    <?= $Page->dose_cycle->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->dose_cycle->getErrorMessage() ?></div>
<?php if (!$Page->dose_cycle->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_immunisationedit", function() {
    var options = { name: "x_dose_cycle", selectId: "ftb_immunisationedit_x_dose_cycle" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_immunisationedit.lists.dose_cycle?.lookupOptions.length) {
        options.data = { id: "x_dose_cycle", form: "ftb_immunisationedit" };
    } else {
        options.ajax = { id: "x_dose_cycle", form: "ftb_immunisationedit", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_immunisation.fields.dose_cycle.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->next_vaccination_date->Visible) { // next_vaccination_date ?>
    <div id="r_next_vaccination_date"<?= $Page->next_vaccination_date->rowAttributes() ?>>
        <label id="elh_tb_immunisation_next_vaccination_date" for="x_next_vaccination_date" class="<?= $Page->LeftColumnClass ?>"><?= $Page->next_vaccination_date->caption() ?><?= $Page->next_vaccination_date->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->next_vaccination_date->cellAttributes() ?>>
<span id="el_tb_immunisation_next_vaccination_date">
<input type="<?= $Page->next_vaccination_date->getInputTextType() ?>" name="x_next_vaccination_date" id="x_next_vaccination_date" data-table="tb_immunisation" data-field="x_next_vaccination_date" value="<?= $Page->next_vaccination_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->next_vaccination_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->next_vaccination_date->formatPattern()) ?>"<?= $Page->next_vaccination_date->editAttributes() ?> aria-describedby="x_next_vaccination_date_help">
<?= $Page->next_vaccination_date->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->next_vaccination_date->getErrorMessage() ?></div>
<?php if (!$Page->next_vaccination_date->ReadOnly && !$Page->next_vaccination_date->Disabled && !isset($Page->next_vaccination_date->EditAttrs["readonly"]) && !isset($Page->next_vaccination_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_immunisationedit", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_immunisationedit", "x_next_vaccination_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->administered_by->Visible) { // administered_by ?>
    <div id="r_administered_by"<?= $Page->administered_by->rowAttributes() ?>>
        <label id="elh_tb_immunisation_administered_by" for="x_administered_by" class="<?= $Page->LeftColumnClass ?>"><?= $Page->administered_by->caption() ?><?= $Page->administered_by->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->administered_by->cellAttributes() ?>>
<span id="el_tb_immunisation_administered_by">
    <select
        id="x_administered_by"
        name="x_administered_by"
        class="form-select ew-select<?= $Page->administered_by->isInvalidClass() ?>"
        <?php if (!$Page->administered_by->IsNativeSelect) { ?>
        data-select2-id="ftb_immunisationedit_x_administered_by"
        <?php } ?>
        data-table="tb_immunisation"
        data-field="x_administered_by"
        data-value-separator="<?= $Page->administered_by->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->administered_by->getPlaceHolder()) ?>"
        <?= $Page->administered_by->editAttributes() ?>>
        <?= $Page->administered_by->selectOptionListHtml("x_administered_by") ?>
    </select>
    <?= $Page->administered_by->getCustomMessage() ?>
    <div class="invalid-feedback"><?= $Page->administered_by->getErrorMessage() ?></div>
<?= $Page->administered_by->Lookup->getParamTag($Page, "p_x_administered_by") ?>
<?php if (!$Page->administered_by->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_immunisationedit", function() {
    var options = { name: "x_administered_by", selectId: "ftb_immunisationedit_x_administered_by" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_immunisationedit.lists.administered_by?.lookupOptions.length) {
        options.data = { id: "x_administered_by", form: "ftb_immunisationedit" };
    } else {
        options.ajax = { id: "x_administered_by", form: "ftb_immunisationedit", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_immunisation.fields.administered_by.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
</div></div>
    </div>
<?php } ?>
<?php if ($Page->remarks->Visible) { // remarks ?>
    <div id="r_remarks"<?= $Page->remarks->rowAttributes() ?>>
        <label id="elh_tb_immunisation_remarks" for="x_remarks" class="<?= $Page->LeftColumnClass ?>"><?= $Page->remarks->caption() ?><?= $Page->remarks->Required ? $Language->phrase("FieldRequiredIndicator") : "" ?></label>
        <div class="<?= $Page->RightColumnClass ?>"><div<?= $Page->remarks->cellAttributes() ?>>
<span id="el_tb_immunisation_remarks">
<textarea data-table="tb_immunisation" data-field="x_remarks" name="x_remarks" id="x_remarks" cols="35" rows="4" placeholder="<?= HtmlEncode($Page->remarks->getPlaceHolder()) ?>"<?= $Page->remarks->editAttributes() ?> aria-describedby="x_remarks_help"><?= $Page->remarks->EditValue ?></textarea>
<?= $Page->remarks->getCustomMessage() ?>
<div class="invalid-feedback"><?= $Page->remarks->getErrorMessage() ?></div>
</span>
</div></div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_immunisationedit"><?= $Language->phrase("SaveBtn") ?></button>
<?php if (IsJsonResponse()) { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-bs-dismiss="modal"><?= $Language->phrase("CancelBtn") ?></button>
<?php } else { ?>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_immunisationedit" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
<?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_immunisation");
});
</script>
<script>
loadjs.ready("load", function () {
    // Startup script
    // Write your table-specific startup script here, no need to add script tags.
    $('[class="form-control-plaintext"]').attr("size","0");
    $('[class="form-control-plaintext"]').removeClass('form-control-plaintext').addClass('form-control');
    $('.form-control[type="tel"]').addClass('form-control-sm w-100');
    $('.form-control[type="text"]').addClass('form-control-sm w-100');
    $('.form-control[type="email"]').addClass('form-control-sm w-100');
    $('.form-control.tt-input[type="text"]').addClass('form-control-sm w-100');
    $('[class="form-select ew-select"]').addClass('form-select-sm w-100')
    $('[class="custom-select ew-custom-select"]').addClass('w-100').removeClass('ew-custom-select');
});
</script>
