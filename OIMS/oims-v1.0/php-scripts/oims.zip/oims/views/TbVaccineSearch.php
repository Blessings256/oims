<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbVaccineSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_vaccine: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var ftb_vaccinesearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_vaccinesearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["id", [ew.Validators.integer], fields.id.isInvalid],
            ["y_id", [ew.Validators.between], false],
            ["vaccine_name", [], fields.vaccine_name.isInvalid],
            ["y_vaccine_name", [ew.Validators.between], false],
            ["vaccine_code", [], fields.vaccine_code.isInvalid],
            ["y_vaccine_code", [ew.Validators.between], false],
            ["dose_required", [ew.Validators.float], fields.dose_required.isInvalid],
            ["y_dose_required", [ew.Validators.between], false],
            ["dose_required_uom", [], fields.dose_required_uom.isInvalid],
            ["y_dose_required_uom", [ew.Validators.between], false],
            ["admin_mode_id", [], fields.admin_mode_id.isInvalid],
            ["y_admin_mode_id", [ew.Validators.between], false],
            ["admin_site_id", [], fields.admin_site_id.isInvalid],
            ["y_admin_site_id", [ew.Validators.between], false],
            ["vaccine_form_id", [], fields.vaccine_form_id.isInvalid],
            ["y_vaccine_form_id", [ew.Validators.between], false],
            ["expiry_date", [ew.Validators.datetime(fields.expiry_date.clientFormatPattern)], fields.expiry_date.isInvalid],
            ["y_expiry_date", [ew.Validators.between], false],
            ["target_group", [], fields.target_group.isInvalid],
            ["y_target_group", [ew.Validators.between], false],
            ["storage_condition", [], fields.storage_condition.isInvalid],
            ["y_storage_condition", [ew.Validators.between], false]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setLists({
            "dose_required_uom": <?= $Page->dose_required_uom->toClientList($Page) ?>,
            "admin_mode_id": <?= $Page->admin_mode_id->toClientList($Page) ?>,
            "admin_site_id": <?= $Page->admin_site_id->toClientList($Page) ?>,
            "vaccine_form_id": <?= $Page->vaccine_form_id->toClientList($Page) ?>,
            "target_group": <?= $Page->target_group->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_vaccinesearch" id="ftb_vaccinesearch" class="<?= $Page->FormClassName ?>" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_vaccine">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<div class="ew-search-div"><!-- page* -->
<?php if ($Page->id->Visible) { // id ?>
    <div id="r_id" class="row"<?= $Page->id->rowAttributes() ?>>
        <label for="x_id" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_id"><?= $Page->id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_id" id="z_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_id" class="ew-search-field">
<input type="<?= $Page->id->getInputTextType() ?>" name="x_id" id="x_id" data-table="tb_vaccine" data-field="x_id" value="<?= $Page->id->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_vaccine_id" class="ew-search-field2 d-none">
<input type="<?= $Page->id->getInputTextType() ?>" name="y_id" id="y_id" data-table="tb_vaccine" data-field="x_id" value="<?= $Page->id->EditValue2 ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->vaccine_name->Visible) { // vaccine_name ?>
    <div id="r_vaccine_name" class="row"<?= $Page->vaccine_name->rowAttributes() ?>>
        <label for="x_vaccine_name" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_vaccine_name"><?= $Page->vaccine_name->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->vaccine_name->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_vaccine_name" id="z_vaccine_name" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->vaccine_name->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->vaccine_name->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_vaccine_name" class="ew-search-field">
<input type="<?= $Page->vaccine_name->getInputTextType() ?>" name="x_vaccine_name" id="x_vaccine_name" data-table="tb_vaccine" data-field="x_vaccine_name" value="<?= $Page->vaccine_name->EditValue ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->vaccine_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_name->formatPattern()) ?>"<?= $Page->vaccine_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->vaccine_name->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_vaccine_vaccine_name" class="ew-search-field2 d-none">
<input type="<?= $Page->vaccine_name->getInputTextType() ?>" name="y_vaccine_name" id="y_vaccine_name" data-table="tb_vaccine" data-field="x_vaccine_name" value="<?= $Page->vaccine_name->EditValue2 ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->vaccine_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_name->formatPattern()) ?>"<?= $Page->vaccine_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->vaccine_name->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->vaccine_code->Visible) { // vaccine_code ?>
    <div id="r_vaccine_code" class="row"<?= $Page->vaccine_code->rowAttributes() ?>>
        <label for="x_vaccine_code" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_vaccine_code"><?= $Page->vaccine_code->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->vaccine_code->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_vaccine_code" id="z_vaccine_code" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->vaccine_code->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->vaccine_code->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_vaccine_code" class="ew-search-field">
<input type="<?= $Page->vaccine_code->getInputTextType() ?>" name="x_vaccine_code" id="x_vaccine_code" data-table="tb_vaccine" data-field="x_vaccine_code" value="<?= $Page->vaccine_code->EditValue ?>" maxlength="10" placeholder="<?= HtmlEncode($Page->vaccine_code->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_code->formatPattern()) ?>"<?= $Page->vaccine_code->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->vaccine_code->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_vaccine_vaccine_code" class="ew-search-field2 d-none">
<input type="<?= $Page->vaccine_code->getInputTextType() ?>" name="y_vaccine_code" id="y_vaccine_code" data-table="tb_vaccine" data-field="x_vaccine_code" value="<?= $Page->vaccine_code->EditValue2 ?>" maxlength="10" placeholder="<?= HtmlEncode($Page->vaccine_code->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_code->formatPattern()) ?>"<?= $Page->vaccine_code->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->vaccine_code->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->dose_required->Visible) { // dose_required ?>
    <div id="r_dose_required" class="row"<?= $Page->dose_required->rowAttributes() ?>>
        <label for="x_dose_required" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_dose_required"><?= $Page->dose_required->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->dose_required->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_dose_required" id="z_dose_required" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->dose_required->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->dose_required->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_dose_required" class="ew-search-field">
<input type="<?= $Page->dose_required->getInputTextType() ?>" name="x_dose_required" id="x_dose_required" data-table="tb_vaccine" data-field="x_dose_required" value="<?= $Page->dose_required->EditValue ?>" placeholder="<?= HtmlEncode($Page->dose_required->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->dose_required->formatPattern()) ?>"<?= $Page->dose_required->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->dose_required->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_vaccine_dose_required" class="ew-search-field2 d-none">
<input type="<?= $Page->dose_required->getInputTextType() ?>" name="y_dose_required" id="y_dose_required" data-table="tb_vaccine" data-field="x_dose_required" value="<?= $Page->dose_required->EditValue2 ?>" placeholder="<?= HtmlEncode($Page->dose_required->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->dose_required->formatPattern()) ?>"<?= $Page->dose_required->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->dose_required->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->dose_required_uom->Visible) { // dose_required_uom ?>
    <div id="r_dose_required_uom" class="row"<?= $Page->dose_required_uom->rowAttributes() ?>>
        <label for="x_dose_required_uom" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_dose_required_uom"><?= $Page->dose_required_uom->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->dose_required_uom->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_dose_required_uom" id="z_dose_required_uom" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->dose_required_uom->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->dose_required_uom->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_dose_required_uom" class="ew-search-field">
    <select
        id="x_dose_required_uom"
        name="x_dose_required_uom"
        class="form-select ew-select<?= $Page->dose_required_uom->isInvalidClass() ?>"
        <?php if (!$Page->dose_required_uom->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_dose_required_uom"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_dose_required_uom"
        data-value-separator="<?= $Page->dose_required_uom->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->dose_required_uom->getPlaceHolder()) ?>"
        <?= $Page->dose_required_uom->editAttributes() ?>>
        <?= $Page->dose_required_uom->selectOptionListHtml("x_dose_required_uom") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->dose_required_uom->getErrorMessage(false) ?></div>
<?= $Page->dose_required_uom->Lookup->getParamTag($Page, "p_x_dose_required_uom") ?>
<?php if (!$Page->dose_required_uom->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_dose_required_uom", selectId: "ftb_vaccinesearch_x_dose_required_uom" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.dose_required_uom?.lookupOptions.length) {
        options.data = { id: "x_dose_required_uom", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_dose_required_uom", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.dose_required_uom.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-cond">
<div class="form-check"><input class="form-check-input" type="radio" id="v_dose_required_uom_1" name="v_dose_required_uom" value="AND"<?= ($Page->dose_required_uom->AdvancedSearch->SearchCondition != "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_dose_required_uom_1"><?= $Language->phrase("AND") ?></label></div>
<div class="form-check"><input class="form-check-input" type="radio" id="v_dose_required_uom_2" name="v_dose_required_uom" value="OR"<?= ($Page->dose_required_uom->AdvancedSearch->SearchCondition == "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_dose_required_uom_2"><?= $Language->phrase("OR") ?></label></div></span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span class="ew-search-operator2">
<?= $Language->phrase("=") ?>
<input type="hidden" name="w_dose_required_uom" id="w_dose_required_uom" value="=">
</span>
                    <span id="el2_tb_vaccine_dose_required_uom" class="ew-search-field2">
    <select
        id="y_dose_required_uom"
        name="y_dose_required_uom"
        class="form-select ew-select<?= $Page->dose_required_uom->isInvalidClass() ?>"
        <?php if (!$Page->dose_required_uom->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_y_dose_required_uom"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_dose_required_uom"
        data-value-separator="<?= $Page->dose_required_uom->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->dose_required_uom->getPlaceHolder()) ?>"
        <?= $Page->dose_required_uom->editAttributes() ?>>
        <?= $Page->dose_required_uom->selectOptionListHtml("y_dose_required_uom") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->dose_required_uom->getErrorMessage(false) ?></div>
<?= $Page->dose_required_uom->Lookup->getParamTag($Page, "p_y_dose_required_uom") ?>
<?php if (!$Page->dose_required_uom->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "y_dose_required_uom", selectId: "ftb_vaccinesearch_y_dose_required_uom" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.dose_required_uom?.lookupOptions.length) {
        options.data = { id: "y_dose_required_uom", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "y_dose_required_uom", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.dose_required_uom.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->admin_mode_id->Visible) { // admin_mode_id ?>
    <div id="r_admin_mode_id" class="row"<?= $Page->admin_mode_id->rowAttributes() ?>>
        <label for="x_admin_mode_id" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_admin_mode_id"><?= $Page->admin_mode_id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->admin_mode_id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_admin_mode_id" id="z_admin_mode_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->admin_mode_id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->admin_mode_id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_admin_mode_id" class="ew-search-field">
    <select
        id="x_admin_mode_id"
        name="x_admin_mode_id"
        class="form-select ew-select<?= $Page->admin_mode_id->isInvalidClass() ?>"
        <?php if (!$Page->admin_mode_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_admin_mode_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_admin_mode_id"
        data-value-separator="<?= $Page->admin_mode_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->admin_mode_id->getPlaceHolder()) ?>"
        <?= $Page->admin_mode_id->editAttributes() ?>>
        <?= $Page->admin_mode_id->selectOptionListHtml("x_admin_mode_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->admin_mode_id->getErrorMessage(false) ?></div>
<?= $Page->admin_mode_id->Lookup->getParamTag($Page, "p_x_admin_mode_id") ?>
<?php if (!$Page->admin_mode_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_admin_mode_id", selectId: "ftb_vaccinesearch_x_admin_mode_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.admin_mode_id?.lookupOptions.length) {
        options.data = { id: "x_admin_mode_id", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_admin_mode_id", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.admin_mode_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-cond">
<div class="form-check"><input class="form-check-input" type="radio" id="v_admin_mode_id_1" name="v_admin_mode_id" value="AND"<?= ($Page->admin_mode_id->AdvancedSearch->SearchCondition != "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_admin_mode_id_1"><?= $Language->phrase("AND") ?></label></div>
<div class="form-check"><input class="form-check-input" type="radio" id="v_admin_mode_id_2" name="v_admin_mode_id" value="OR"<?= ($Page->admin_mode_id->AdvancedSearch->SearchCondition == "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_admin_mode_id_2"><?= $Language->phrase("OR") ?></label></div></span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span class="ew-search-operator2">
<?= $Language->phrase("=") ?>
<input type="hidden" name="w_admin_mode_id" id="w_admin_mode_id" value="=">
</span>
                    <span id="el2_tb_vaccine_admin_mode_id" class="ew-search-field2">
    <select
        id="y_admin_mode_id"
        name="y_admin_mode_id"
        class="form-select ew-select<?= $Page->admin_mode_id->isInvalidClass() ?>"
        <?php if (!$Page->admin_mode_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_y_admin_mode_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_admin_mode_id"
        data-value-separator="<?= $Page->admin_mode_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->admin_mode_id->getPlaceHolder()) ?>"
        <?= $Page->admin_mode_id->editAttributes() ?>>
        <?= $Page->admin_mode_id->selectOptionListHtml("y_admin_mode_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->admin_mode_id->getErrorMessage(false) ?></div>
<?= $Page->admin_mode_id->Lookup->getParamTag($Page, "p_y_admin_mode_id") ?>
<?php if (!$Page->admin_mode_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "y_admin_mode_id", selectId: "ftb_vaccinesearch_y_admin_mode_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.admin_mode_id?.lookupOptions.length) {
        options.data = { id: "y_admin_mode_id", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "y_admin_mode_id", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.admin_mode_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->admin_site_id->Visible) { // admin_site_id ?>
    <div id="r_admin_site_id" class="row"<?= $Page->admin_site_id->rowAttributes() ?>>
        <label for="x_admin_site_id" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_admin_site_id"><?= $Page->admin_site_id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->admin_site_id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_admin_site_id" id="z_admin_site_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->admin_site_id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->admin_site_id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_admin_site_id" class="ew-search-field">
    <select
        id="x_admin_site_id"
        name="x_admin_site_id"
        class="form-select ew-select<?= $Page->admin_site_id->isInvalidClass() ?>"
        <?php if (!$Page->admin_site_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_admin_site_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_admin_site_id"
        data-value-separator="<?= $Page->admin_site_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->admin_site_id->getPlaceHolder()) ?>"
        <?= $Page->admin_site_id->editAttributes() ?>>
        <?= $Page->admin_site_id->selectOptionListHtml("x_admin_site_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->admin_site_id->getErrorMessage(false) ?></div>
<?= $Page->admin_site_id->Lookup->getParamTag($Page, "p_x_admin_site_id") ?>
<?php if (!$Page->admin_site_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_admin_site_id", selectId: "ftb_vaccinesearch_x_admin_site_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.admin_site_id?.lookupOptions.length) {
        options.data = { id: "x_admin_site_id", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_admin_site_id", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.admin_site_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-cond">
<div class="form-check"><input class="form-check-input" type="radio" id="v_admin_site_id_1" name="v_admin_site_id" value="AND"<?= ($Page->admin_site_id->AdvancedSearch->SearchCondition != "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_admin_site_id_1"><?= $Language->phrase("AND") ?></label></div>
<div class="form-check"><input class="form-check-input" type="radio" id="v_admin_site_id_2" name="v_admin_site_id" value="OR"<?= ($Page->admin_site_id->AdvancedSearch->SearchCondition == "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_admin_site_id_2"><?= $Language->phrase("OR") ?></label></div></span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span class="ew-search-operator2">
<?= $Language->phrase("=") ?>
<input type="hidden" name="w_admin_site_id" id="w_admin_site_id" value="=">
</span>
                    <span id="el2_tb_vaccine_admin_site_id" class="ew-search-field2">
    <select
        id="y_admin_site_id"
        name="y_admin_site_id"
        class="form-select ew-select<?= $Page->admin_site_id->isInvalidClass() ?>"
        <?php if (!$Page->admin_site_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_y_admin_site_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_admin_site_id"
        data-value-separator="<?= $Page->admin_site_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->admin_site_id->getPlaceHolder()) ?>"
        <?= $Page->admin_site_id->editAttributes() ?>>
        <?= $Page->admin_site_id->selectOptionListHtml("y_admin_site_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->admin_site_id->getErrorMessage(false) ?></div>
<?= $Page->admin_site_id->Lookup->getParamTag($Page, "p_y_admin_site_id") ?>
<?php if (!$Page->admin_site_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "y_admin_site_id", selectId: "ftb_vaccinesearch_y_admin_site_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.admin_site_id?.lookupOptions.length) {
        options.data = { id: "y_admin_site_id", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "y_admin_site_id", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.admin_site_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->vaccine_form_id->Visible) { // vaccine_form_id ?>
    <div id="r_vaccine_form_id" class="row"<?= $Page->vaccine_form_id->rowAttributes() ?>>
        <label for="x_vaccine_form_id" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_vaccine_form_id"><?= $Page->vaccine_form_id->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->vaccine_form_id->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_vaccine_form_id" id="z_vaccine_form_id" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->vaccine_form_id->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->vaccine_form_id->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_vaccine_form_id" class="ew-search-field">
    <select
        id="x_vaccine_form_id"
        name="x_vaccine_form_id"
        class="form-select ew-select<?= $Page->vaccine_form_id->isInvalidClass() ?>"
        <?php if (!$Page->vaccine_form_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_vaccine_form_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_vaccine_form_id"
        data-value-separator="<?= $Page->vaccine_form_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->vaccine_form_id->getPlaceHolder()) ?>"
        <?= $Page->vaccine_form_id->editAttributes() ?>>
        <?= $Page->vaccine_form_id->selectOptionListHtml("x_vaccine_form_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->vaccine_form_id->getErrorMessage(false) ?></div>
<?= $Page->vaccine_form_id->Lookup->getParamTag($Page, "p_x_vaccine_form_id") ?>
<?php if (!$Page->vaccine_form_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_vaccine_form_id", selectId: "ftb_vaccinesearch_x_vaccine_form_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.vaccine_form_id?.lookupOptions.length) {
        options.data = { id: "x_vaccine_form_id", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_vaccine_form_id", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.vaccine_form_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-cond">
<div class="form-check"><input class="form-check-input" type="radio" id="v_vaccine_form_id_1" name="v_vaccine_form_id" value="AND"<?= ($Page->vaccine_form_id->AdvancedSearch->SearchCondition != "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_vaccine_form_id_1"><?= $Language->phrase("AND") ?></label></div>
<div class="form-check"><input class="form-check-input" type="radio" id="v_vaccine_form_id_2" name="v_vaccine_form_id" value="OR"<?= ($Page->vaccine_form_id->AdvancedSearch->SearchCondition == "OR") ? " checked" : "" ?>><label class="form-check-label" for="v_vaccine_form_id_2"><?= $Language->phrase("OR") ?></label></div></span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span class="ew-search-operator2">
<?= $Language->phrase("=") ?>
<input type="hidden" name="w_vaccine_form_id" id="w_vaccine_form_id" value="=">
</span>
                    <span id="el2_tb_vaccine_vaccine_form_id" class="ew-search-field2">
    <select
        id="y_vaccine_form_id"
        name="y_vaccine_form_id"
        class="form-select ew-select<?= $Page->vaccine_form_id->isInvalidClass() ?>"
        <?php if (!$Page->vaccine_form_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_y_vaccine_form_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_vaccine_form_id"
        data-value-separator="<?= $Page->vaccine_form_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->vaccine_form_id->getPlaceHolder()) ?>"
        <?= $Page->vaccine_form_id->editAttributes() ?>>
        <?= $Page->vaccine_form_id->selectOptionListHtml("y_vaccine_form_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->vaccine_form_id->getErrorMessage(false) ?></div>
<?= $Page->vaccine_form_id->Lookup->getParamTag($Page, "p_y_vaccine_form_id") ?>
<?php if (!$Page->vaccine_form_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "y_vaccine_form_id", selectId: "ftb_vaccinesearch_y_vaccine_form_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.vaccine_form_id?.lookupOptions.length) {
        options.data = { id: "y_vaccine_form_id", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "y_vaccine_form_id", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.vaccine_form_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->expiry_date->Visible) { // expiry_date ?>
    <div id="r_expiry_date" class="row"<?= $Page->expiry_date->rowAttributes() ?>>
        <label for="x_expiry_date" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_expiry_date"><?= $Page->expiry_date->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->expiry_date->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_expiry_date" id="z_expiry_date" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->expiry_date->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->expiry_date->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_expiry_date" class="ew-search-field">
<input type="<?= $Page->expiry_date->getInputTextType() ?>" name="x_expiry_date" id="x_expiry_date" data-table="tb_vaccine" data-field="x_expiry_date" value="<?= $Page->expiry_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->expiry_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->expiry_date->formatPattern()) ?>"<?= $Page->expiry_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->expiry_date->getErrorMessage(false) ?></div>
<?php if (!$Page->expiry_date->ReadOnly && !$Page->expiry_date->Disabled && !isset($Page->expiry_date->EditAttrs["readonly"]) && !isset($Page->expiry_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_vaccinesearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_vaccinesearch", "x_expiry_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_vaccine_expiry_date" class="ew-search-field2 d-none">
<input type="<?= $Page->expiry_date->getInputTextType() ?>" name="y_expiry_date" id="y_expiry_date" data-table="tb_vaccine" data-field="x_expiry_date" value="<?= $Page->expiry_date->EditValue2 ?>" placeholder="<?= HtmlEncode($Page->expiry_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->expiry_date->formatPattern()) ?>"<?= $Page->expiry_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->expiry_date->getErrorMessage(false) ?></div>
<?php if (!$Page->expiry_date->ReadOnly && !$Page->expiry_date->Disabled && !isset($Page->expiry_date->EditAttrs["readonly"]) && !isset($Page->expiry_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_vaccinesearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_vaccinesearch", "y_expiry_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->target_group->Visible) { // target_group ?>
    <div id="r_target_group" class="row"<?= $Page->target_group->rowAttributes() ?>>
        <label for="x_target_group" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_target_group"><?= $Page->target_group->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->target_group->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_target_group" id="z_target_group" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->target_group->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->target_group->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_target_group" class="ew-search-field">
    <select
        id="x_target_group"
        name="x_target_group"
        class="form-select ew-select<?= $Page->target_group->isInvalidClass() ?>"
        <?php if (!$Page->target_group->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_target_group"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_target_group"
        data-value-separator="<?= $Page->target_group->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->target_group->getPlaceHolder()) ?>"
        <?= $Page->target_group->editAttributes() ?>>
        <?= $Page->target_group->selectOptionListHtml("x_target_group") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->target_group->getErrorMessage(false) ?></div>
<?php if (!$Page->target_group->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_target_group", selectId: "ftb_vaccinesearch_x_target_group" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.target_group?.lookupOptions.length) {
        options.data = { id: "x_target_group", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_target_group", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.target_group.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_vaccine_target_group" class="ew-search-field2 d-none">
    <select
        id="y_target_group"
        name="y_target_group"
        class="form-select ew-select<?= $Page->target_group->isInvalidClass() ?>"
        <?php if (!$Page->target_group->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_y_target_group"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_target_group"
        data-value-separator="<?= $Page->target_group->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->target_group->getPlaceHolder()) ?>"
        <?= $Page->target_group->editAttributes() ?>>
        <?= $Page->target_group->selectOptionListHtml("y_target_group") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->target_group->getErrorMessage(false) ?></div>
<?php if (!$Page->target_group->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "y_target_group", selectId: "ftb_vaccinesearch_y_target_group" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.target_group?.lookupOptions.length) {
        options.data = { id: "y_target_group", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "y_target_group", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.target_group.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($Page->storage_condition->Visible) { // storage_condition ?>
    <div id="r_storage_condition" class="row"<?= $Page->storage_condition->rowAttributes() ?>>
        <label for="x_storage_condition" class="<?= $Page->LeftColumnClass ?>"><span id="elh_tb_vaccine_storage_condition"><?= $Page->storage_condition->caption() ?></span>
        </label>
        <div class="<?= $Page->RightColumnClass ?>">
            <div<?= $Page->storage_condition->cellAttributes() ?>>
                <div class="d-flex align-items-start">
                    <span class="ew-search-operator">
<select name="z_storage_condition" id="z_storage_condition" class="form-select ew-operator-select" data-ew-action="search-operator">
<?php foreach ($Page->storage_condition->SearchOperators as $opr) { ?>
<option value="<?= HtmlEncode($opr) ?>"<?= $Page->storage_condition->AdvancedSearch->SearchOperator == $opr ? " selected" : "" ?>><?= $Language->phrase($opr == "=" ? "EQUAL" : $opr) ?></option>
<?php } ?>
</select>
</span>
                <span id="el_tb_vaccine_storage_condition" class="ew-search-field">
<input type="<?= $Page->storage_condition->getInputTextType() ?>" name="x_storage_condition" id="x_storage_condition" data-table="tb_vaccine" data-field="x_storage_condition" value="<?= $Page->storage_condition->EditValue ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->storage_condition->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->storage_condition->formatPattern()) ?>"<?= $Page->storage_condition->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->storage_condition->getErrorMessage(false) ?></div>
</span>
                    <span class="ew-search-and d-none"><label><?= $Language->phrase("AND") ?></label></span>
                    <span id="el2_tb_vaccine_storage_condition" class="ew-search-field2 d-none">
<input type="<?= $Page->storage_condition->getInputTextType() ?>" name="y_storage_condition" id="y_storage_condition" data-table="tb_vaccine" data-field="x_storage_condition" value="<?= $Page->storage_condition->EditValue2 ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->storage_condition->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->storage_condition->formatPattern()) ?>"<?= $Page->storage_condition->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->storage_condition->getErrorMessage(false) ?></div>
</span>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
</div><!-- /page* -->
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit" form="ftb_vaccinesearch"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_vaccinesearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn" name="btn-reset" id="btn-reset" type="button" form="ftb_vaccinesearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_vaccine");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
