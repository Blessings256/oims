<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbVaccineDelete = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_vaccine: currentTable } });
var currentPageID = ew.PAGE_ID = "delete";
var currentForm;
var ftb_vaccinedelete;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_vaccinedelete")
        .setPageId("delete")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_vaccinedelete" id="ftb_vaccinedelete" class="ew-form ew-delete-form" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_vaccine">
<input type="hidden" name="action" id="action" value="delete">
<?php foreach ($Page->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode(Config("COMPOSITE_KEY_SEPARATOR"), $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?= HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="card ew-card ew-grid <?= $Page->TableGridClass ?>">
<div class="card-body ew-grid-middle-panel <?= $Page->TableContainerClass ?>" style="<?= $Page->TableContainerStyle ?>">
<table class="<?= $Page->TableClass ?>">
    <thead>
    <tr class="ew-table-header">
<?php if ($Page->id->Visible) { // id ?>
        <th class="<?= $Page->id->headerCellClass() ?>"><span id="elh_tb_vaccine_id" class="tb_vaccine_id"><?= $Page->id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->vaccine_name->Visible) { // vaccine_name ?>
        <th class="<?= $Page->vaccine_name->headerCellClass() ?>"><span id="elh_tb_vaccine_vaccine_name" class="tb_vaccine_vaccine_name"><?= $Page->vaccine_name->caption() ?></span></th>
<?php } ?>
<?php if ($Page->vaccine_code->Visible) { // vaccine_code ?>
        <th class="<?= $Page->vaccine_code->headerCellClass() ?>"><span id="elh_tb_vaccine_vaccine_code" class="tb_vaccine_vaccine_code"><?= $Page->vaccine_code->caption() ?></span></th>
<?php } ?>
<?php if ($Page->dose_required->Visible) { // dose_required ?>
        <th class="<?= $Page->dose_required->headerCellClass() ?>"><span id="elh_tb_vaccine_dose_required" class="tb_vaccine_dose_required"><?= $Page->dose_required->caption() ?></span></th>
<?php } ?>
<?php if ($Page->dose_required_uom->Visible) { // dose_required_uom ?>
        <th class="<?= $Page->dose_required_uom->headerCellClass() ?>"><span id="elh_tb_vaccine_dose_required_uom" class="tb_vaccine_dose_required_uom"><?= $Page->dose_required_uom->caption() ?></span></th>
<?php } ?>
<?php if ($Page->admin_mode_id->Visible) { // admin_mode_id ?>
        <th class="<?= $Page->admin_mode_id->headerCellClass() ?>"><span id="elh_tb_vaccine_admin_mode_id" class="tb_vaccine_admin_mode_id"><?= $Page->admin_mode_id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->admin_site_id->Visible) { // admin_site_id ?>
        <th class="<?= $Page->admin_site_id->headerCellClass() ?>"><span id="elh_tb_vaccine_admin_site_id" class="tb_vaccine_admin_site_id"><?= $Page->admin_site_id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->vaccine_form_id->Visible) { // vaccine_form_id ?>
        <th class="<?= $Page->vaccine_form_id->headerCellClass() ?>"><span id="elh_tb_vaccine_vaccine_form_id" class="tb_vaccine_vaccine_form_id"><?= $Page->vaccine_form_id->caption() ?></span></th>
<?php } ?>
<?php if ($Page->expiry_date->Visible) { // expiry_date ?>
        <th class="<?= $Page->expiry_date->headerCellClass() ?>"><span id="elh_tb_vaccine_expiry_date" class="tb_vaccine_expiry_date"><?= $Page->expiry_date->caption() ?></span></th>
<?php } ?>
<?php if ($Page->target_group->Visible) { // target_group ?>
        <th class="<?= $Page->target_group->headerCellClass() ?>"><span id="elh_tb_vaccine_target_group" class="tb_vaccine_target_group"><?= $Page->target_group->caption() ?></span></th>
<?php } ?>
<?php if ($Page->storage_condition->Visible) { // storage_condition ?>
        <th class="<?= $Page->storage_condition->headerCellClass() ?>"><span id="elh_tb_vaccine_storage_condition" class="tb_vaccine_storage_condition"><?= $Page->storage_condition->caption() ?></span></th>
<?php } ?>
<?php if ($Page->description->Visible) { // description ?>
        <th class="<?= $Page->description->headerCellClass() ?>"><span id="elh_tb_vaccine_description" class="tb_vaccine_description"><?= $Page->description->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <th class="<?= $Page->entry_date->headerCellClass() ?>"><span id="elh_tb_vaccine_entry_date" class="tb_vaccine_entry_date"><?= $Page->entry_date->caption() ?></span></th>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <th class="<?= $Page->last_modified->headerCellClass() ?>"><span id="elh_tb_vaccine_last_modified" class="tb_vaccine_last_modified"><?= $Page->last_modified->caption() ?></span></th>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <th class="<?= $Page->entered_by->headerCellClass() ?>"><span id="elh_tb_vaccine_entered_by" class="tb_vaccine_entered_by"><?= $Page->entered_by->caption() ?></span></th>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <th class="<?= $Page->modified_by->headerCellClass() ?>"><span id="elh_tb_vaccine_modified_by" class="tb_vaccine_modified_by"><?= $Page->modified_by->caption() ?></span></th>
<?php } ?>
    </tr>
    </thead>
    <tbody>
<?php
$Page->RecordCount = 0;
$i = 0;
while (!$Page->Recordset->EOF) {
    $Page->RecordCount++;
    $Page->RowCount++;

    // Set row properties
    $Page->resetAttributes();
    $Page->RowType = ROWTYPE_VIEW; // View

    // Get the field contents
    $Page->loadRowValues($Page->Recordset);

    // Render row
    $Page->renderRow();
?>
    <tr <?= $Page->rowAttributes() ?>>
<?php if ($Page->id->Visible) { // id ?>
        <td<?= $Page->id->cellAttributes() ?>>
<span id="">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->vaccine_name->Visible) { // vaccine_name ?>
        <td<?= $Page->vaccine_name->cellAttributes() ?>>
<span id="">
<span<?= $Page->vaccine_name->viewAttributes() ?>>
<?= $Page->vaccine_name->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->vaccine_code->Visible) { // vaccine_code ?>
        <td<?= $Page->vaccine_code->cellAttributes() ?>>
<span id="">
<span<?= $Page->vaccine_code->viewAttributes() ?>>
<?= $Page->vaccine_code->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->dose_required->Visible) { // dose_required ?>
        <td<?= $Page->dose_required->cellAttributes() ?>>
<span id="">
<span<?= $Page->dose_required->viewAttributes() ?>>
<?= $Page->dose_required->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->dose_required_uom->Visible) { // dose_required_uom ?>
        <td<?= $Page->dose_required_uom->cellAttributes() ?>>
<span id="">
<span<?= $Page->dose_required_uom->viewAttributes() ?>>
<?= $Page->dose_required_uom->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->admin_mode_id->Visible) { // admin_mode_id ?>
        <td<?= $Page->admin_mode_id->cellAttributes() ?>>
<span id="">
<span<?= $Page->admin_mode_id->viewAttributes() ?>>
<?= $Page->admin_mode_id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->admin_site_id->Visible) { // admin_site_id ?>
        <td<?= $Page->admin_site_id->cellAttributes() ?>>
<span id="">
<span<?= $Page->admin_site_id->viewAttributes() ?>>
<?= $Page->admin_site_id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->vaccine_form_id->Visible) { // vaccine_form_id ?>
        <td<?= $Page->vaccine_form_id->cellAttributes() ?>>
<span id="">
<span<?= $Page->vaccine_form_id->viewAttributes() ?>>
<?= $Page->vaccine_form_id->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->expiry_date->Visible) { // expiry_date ?>
        <td<?= $Page->expiry_date->cellAttributes() ?>>
<span id="">
<span<?= $Page->expiry_date->viewAttributes() ?>>
<?= $Page->expiry_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->target_group->Visible) { // target_group ?>
        <td<?= $Page->target_group->cellAttributes() ?>>
<span id="">
<span<?= $Page->target_group->viewAttributes() ?>>
<?= $Page->target_group->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->storage_condition->Visible) { // storage_condition ?>
        <td<?= $Page->storage_condition->cellAttributes() ?>>
<span id="">
<span<?= $Page->storage_condition->viewAttributes() ?>>
<?= $Page->storage_condition->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->description->Visible) { // description ?>
        <td<?= $Page->description->cellAttributes() ?>>
<span id="">
<span<?= $Page->description->viewAttributes() ?>>
<?= $Page->description->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <td<?= $Page->entry_date->cellAttributes() ?>>
<span id="">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <td<?= $Page->last_modified->cellAttributes() ?>>
<span id="">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <td<?= $Page->entered_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <td<?= $Page->modified_by->cellAttributes() ?>>
<span id="">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
<?php } ?>
    </tr>
<?php
    $Page->Recordset->moveNext();
}
$Page->Recordset->close();
?>
</tbody>
</table>
</div>
</div>
<div class="ew-buttons ew-desktop-buttons">
<button class="btn btn-primary ew-btn" name="btn-action" id="btn-action" type="submit"><?= $Language->phrase("DeleteBtn") ?></button>
<button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" data-href="<?= HtmlEncode(GetUrl($Page->getReturnUrl())) ?>"><?= $Language->phrase("CancelBtn") ?></button>
</div>
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
