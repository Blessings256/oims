<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbAdministrationSiteView = &$Page;
?>
<?php if (!$Page->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php $Page->ExportOptions->render("body") ?>
<?php $Page->OtherOptions->render("body") ?>
</div>
<?php } ?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="view">
<form name="ftb_administration_siteview" id="ftb_administration_siteview" class="ew-form ew-view-form overlay-wrapper" action="<?= CurrentPageUrl(false) ?>" method="post" novalidate autocomplete="off">
<?php if (!$Page->isExport()) { ?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_administration_site: currentTable } });
var currentPageID = ew.PAGE_ID = "view";
var currentForm;
var ftb_administration_siteview;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("ftb_administration_siteview")
        .setPageId("view")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php } ?>
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_administration_site">
<input type="hidden" name="modal" value="<?= (int)$Page->IsModal ?>">
<table class="<?= $Page->TableClass ?>">
<?php if ($Page->id->Visible) { // id ?>
    <tr id="r_id"<?= $Page->id->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_administration_site_id"><?= $Page->id->caption() ?></span></td>
        <td data-name="id"<?= $Page->id->cellAttributes() ?>>
<span id="el_tb_administration_site_id">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->site_name->Visible) { // site_name ?>
    <tr id="r_site_name"<?= $Page->site_name->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_administration_site_site_name"><?= $Page->site_name->caption() ?></span></td>
        <td data-name="site_name"<?= $Page->site_name->cellAttributes() ?>>
<span id="el_tb_administration_site_site_name">
<span<?= $Page->site_name->viewAttributes() ?>>
<?= $Page->site_name->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->description->Visible) { // description ?>
    <tr id="r_description"<?= $Page->description->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_administration_site_description"><?= $Page->description->caption() ?></span></td>
        <td data-name="description"<?= $Page->description->cellAttributes() ?>>
<span id="el_tb_administration_site_description">
<span<?= $Page->description->viewAttributes() ?>>
<?= $Page->description->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
    <tr id="r_entry_date"<?= $Page->entry_date->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_administration_site_entry_date"><?= $Page->entry_date->caption() ?></span></td>
        <td data-name="entry_date"<?= $Page->entry_date->cellAttributes() ?>>
<span id="el_tb_administration_site_entry_date">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
    <tr id="r_last_modified"<?= $Page->last_modified->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_administration_site_last_modified"><?= $Page->last_modified->caption() ?></span></td>
        <td data-name="last_modified"<?= $Page->last_modified->cellAttributes() ?>>
<span id="el_tb_administration_site_last_modified">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
    <tr id="r_entered_by"<?= $Page->entered_by->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_administration_site_entered_by"><?= $Page->entered_by->caption() ?></span></td>
        <td data-name="entered_by"<?= $Page->entered_by->cellAttributes() ?>>
<span id="el_tb_administration_site_entered_by">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
    <tr id="r_modified_by"<?= $Page->modified_by->rowAttributes() ?>>
        <td class="<?= $Page->TableLeftColumnClass ?>"><span id="elh_tb_administration_site_modified_by"><?= $Page->modified_by->caption() ?></span></td>
        <td data-name="modified_by"<?= $Page->modified_by->cellAttributes() ?>>
<span id="el_tb_administration_site_modified_by">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
    </tr>
<?php } ?>
</table>
</form>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<?php if (!$Page->isExport()) { ?>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
<?php } ?>
