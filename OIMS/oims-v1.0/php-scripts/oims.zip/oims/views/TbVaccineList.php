<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbVaccineList = &$Page;
?>
<?php if (!$Page->isExport()) { ?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_vaccine: currentTable } });
var currentPageID = ew.PAGE_ID = "list";
var currentForm;
var <?= $Page->FormName ?>;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery;
    let fields = currentTable.fields;

    // Form object
    let form = new ew.FormBuilder()
        .setId("<?= $Page->FormName ?>")
        .setPageId("list")
        .setSubmitWithFetch(<?= $Page->UseAjaxActions ? "true" : "false" ?>)
        .setFormKeyCountName("<?= $Page->FormKeyCountName ?>")
        .build();
    window[form.id] = form;
    currentForm = form;
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php } ?>
<?php if (!$Page->isExport()) { ?>
<div class="btn-toolbar ew-toolbar">
<?php if ($Page->TotalRecords > 0 && $Page->ExportOptions->visible()) { ?>
<?php $Page->ExportOptions->render("body") ?>
<?php } ?>
<?php if ($Page->ImportOptions->visible()) { ?>
<?php $Page->ImportOptions->render("body") ?>
<?php } ?>
<?php if ($Page->SearchOptions->visible()) { ?>
<?php $Page->SearchOptions->render("body") ?>
<?php } ?>
<?php if ($Page->FilterOptions->visible()) { ?>
<?php $Page->FilterOptions->render("body") ?>
<?php } ?>
</div>
<?php } ?>
<?php if (!$Page->IsModal) { ?>
<form name="ftb_vaccinesrch" id="ftb_vaccinesrch" class="ew-form ew-ext-search-form" action="<?= CurrentPageUrl(false) ?>" novalidate autocomplete="off">
<div id="ftb_vaccinesrch_search_panel" class="mb-2 mb-sm-0 <?= $Page->SearchPanelClass ?>"><!-- .ew-search-panel -->
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_vaccine: currentTable } });
var currentForm;
var ftb_vaccinesrch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_vaccinesrch")
        .setPageId("list")
<?php if ($Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Dynamic selection lists
        .setLists({
        })

        // Filters
        .setFilterList(<?= $Page->getFilterList() ?>)
        .build();
    window[form.id] = form;
    currentSearchForm = form;
    loadjs.done(form.id);
});
</script>
<input type="hidden" name="cmd" value="search">
</div><!-- /.ew-search-panel -->
</form>
<?php } ?>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<main class="list<?= ($Page->TotalRecords == 0 && !$Page->isAdd()) ? " ew-no-record" : "" ?>">
<div id="ew-list">
<?php if ($Page->TotalRecords > 0 || $Page->CurrentAction) { ?>
<div class="card ew-card ew-grid<?= $Page->isAddOrEdit() ? " ew-grid-add-edit" : "" ?> <?= $Page->TableGridClass ?>">
<?php if (!$Page->isExport()) { ?>
<div class="card-header ew-grid-upper-panel">
<?php if (!$Page->isGridAdd() && !($Page->isGridEdit() && $Page->ModalGridEdit) && !$Page->isMultiEdit()) { ?>
<?= $Page->Pager->render() ?>
<?php } ?>
<div class="ew-list-other-options">
<?php $Page->OtherOptions->render("body") ?>
</div>
</div>
<?php } ?>
<form name="<?= $Page->FormName ?>" id="<?= $Page->FormName ?>" class="ew-form ew-list-form" action="<?= $Page->PageAction ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_vaccine">
<?php if ($Page->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<div id="gmp_tb_vaccine" class="card-body ew-grid-middle-panel <?= $Page->TableContainerClass ?>" style="<?= $Page->TableContainerStyle ?>">
<?php if ($Page->TotalRecords > 0 || $Page->isGridEdit() || $Page->isMultiEdit()) { ?>
<table id="tbl_tb_vaccinelist" class="<?= $Page->TableClass ?>"><!-- .ew-table -->
<thead>
    <tr class="ew-table-header">
<?php
// Header row
$Page->RowType = ROWTYPE_HEADER;

// Render list options
$Page->renderListOptions();

// Render list options (header, left)
$Page->ListOptions->render("header", "left");
?>
<?php if ($Page->id->Visible) { // id ?>
        <th data-name="id" class="<?= $Page->id->headerCellClass() ?>"><div id="elh_tb_vaccine_id" class="tb_vaccine_id"><?= $Page->renderFieldHeader($Page->id) ?></div></th>
<?php } ?>
<?php if ($Page->vaccine_name->Visible) { // vaccine_name ?>
        <th data-name="vaccine_name" class="<?= $Page->vaccine_name->headerCellClass() ?>"><div id="elh_tb_vaccine_vaccine_name" class="tb_vaccine_vaccine_name"><?= $Page->renderFieldHeader($Page->vaccine_name) ?></div></th>
<?php } ?>
<?php if ($Page->vaccine_code->Visible) { // vaccine_code ?>
        <th data-name="vaccine_code" class="<?= $Page->vaccine_code->headerCellClass() ?>"><div id="elh_tb_vaccine_vaccine_code" class="tb_vaccine_vaccine_code"><?= $Page->renderFieldHeader($Page->vaccine_code) ?></div></th>
<?php } ?>
<?php if ($Page->dose_required->Visible) { // dose_required ?>
        <th data-name="dose_required" class="<?= $Page->dose_required->headerCellClass() ?>"><div id="elh_tb_vaccine_dose_required" class="tb_vaccine_dose_required"><?= $Page->renderFieldHeader($Page->dose_required) ?></div></th>
<?php } ?>
<?php if ($Page->dose_required_uom->Visible) { // dose_required_uom ?>
        <th data-name="dose_required_uom" class="<?= $Page->dose_required_uom->headerCellClass() ?>"><div id="elh_tb_vaccine_dose_required_uom" class="tb_vaccine_dose_required_uom"><?= $Page->renderFieldHeader($Page->dose_required_uom) ?></div></th>
<?php } ?>
<?php if ($Page->admin_mode_id->Visible) { // admin_mode_id ?>
        <th data-name="admin_mode_id" class="<?= $Page->admin_mode_id->headerCellClass() ?>"><div id="elh_tb_vaccine_admin_mode_id" class="tb_vaccine_admin_mode_id"><?= $Page->renderFieldHeader($Page->admin_mode_id) ?></div></th>
<?php } ?>
<?php if ($Page->admin_site_id->Visible) { // admin_site_id ?>
        <th data-name="admin_site_id" class="<?= $Page->admin_site_id->headerCellClass() ?>"><div id="elh_tb_vaccine_admin_site_id" class="tb_vaccine_admin_site_id"><?= $Page->renderFieldHeader($Page->admin_site_id) ?></div></th>
<?php } ?>
<?php if ($Page->vaccine_form_id->Visible) { // vaccine_form_id ?>
        <th data-name="vaccine_form_id" class="<?= $Page->vaccine_form_id->headerCellClass() ?>"><div id="elh_tb_vaccine_vaccine_form_id" class="tb_vaccine_vaccine_form_id"><?= $Page->renderFieldHeader($Page->vaccine_form_id) ?></div></th>
<?php } ?>
<?php if ($Page->expiry_date->Visible) { // expiry_date ?>
        <th data-name="expiry_date" class="<?= $Page->expiry_date->headerCellClass() ?>"><div id="elh_tb_vaccine_expiry_date" class="tb_vaccine_expiry_date"><?= $Page->renderFieldHeader($Page->expiry_date) ?></div></th>
<?php } ?>
<?php if ($Page->target_group->Visible) { // target_group ?>
        <th data-name="target_group" class="<?= $Page->target_group->headerCellClass() ?>"><div id="elh_tb_vaccine_target_group" class="tb_vaccine_target_group"><?= $Page->renderFieldHeader($Page->target_group) ?></div></th>
<?php } ?>
<?php if ($Page->storage_condition->Visible) { // storage_condition ?>
        <th data-name="storage_condition" class="<?= $Page->storage_condition->headerCellClass() ?>"><div id="elh_tb_vaccine_storage_condition" class="tb_vaccine_storage_condition"><?= $Page->renderFieldHeader($Page->storage_condition) ?></div></th>
<?php } ?>
<?php if ($Page->entry_date->Visible) { // entry_date ?>
        <th data-name="entry_date" class="<?= $Page->entry_date->headerCellClass() ?>"><div id="elh_tb_vaccine_entry_date" class="tb_vaccine_entry_date"><?= $Page->renderFieldHeader($Page->entry_date) ?></div></th>
<?php } ?>
<?php if ($Page->last_modified->Visible) { // last_modified ?>
        <th data-name="last_modified" class="<?= $Page->last_modified->headerCellClass() ?>"><div id="elh_tb_vaccine_last_modified" class="tb_vaccine_last_modified"><?= $Page->renderFieldHeader($Page->last_modified) ?></div></th>
<?php } ?>
<?php if ($Page->entered_by->Visible) { // entered_by ?>
        <th data-name="entered_by" class="<?= $Page->entered_by->headerCellClass() ?>"><div id="elh_tb_vaccine_entered_by" class="tb_vaccine_entered_by"><?= $Page->renderFieldHeader($Page->entered_by) ?></div></th>
<?php } ?>
<?php if ($Page->modified_by->Visible) { // modified_by ?>
        <th data-name="modified_by" class="<?= $Page->modified_by->headerCellClass() ?>"><div id="elh_tb_vaccine_modified_by" class="tb_vaccine_modified_by"><?= $Page->renderFieldHeader($Page->modified_by) ?></div></th>
<?php } ?>
<?php
// Render list options (header, right)
$Page->ListOptions->render("header", "right");
?>
    </tr>
</thead>
<tbody data-page="<?= $Page->getPageNumber() ?>">
<?php
$Page->setupGrid();
while ($Page->RecordCount < $Page->StopRecord || $Page->RowIndex === '$rowindex$') {
    $Page->RecordCount++;
    if ($Page->RecordCount >= $Page->StartRecord) {
        $Page->setupRow();
?>
    <tr <?= $Page->rowAttributes() ?>>
<?php
// Render list options (body, left)
$Page->ListOptions->render("body", "left", $Page->RowCount);
?>
    <?php if ($Page->id->Visible) { // id ?>
        <td data-name="id"<?= $Page->id->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_id" class="el_tb_vaccine_id">
<span<?= $Page->id->viewAttributes() ?>>
<?= $Page->id->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->vaccine_name->Visible) { // vaccine_name ?>
        <td data-name="vaccine_name"<?= $Page->vaccine_name->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_vaccine_name" class="el_tb_vaccine_vaccine_name">
<span<?= $Page->vaccine_name->viewAttributes() ?>>
<?= $Page->vaccine_name->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->vaccine_code->Visible) { // vaccine_code ?>
        <td data-name="vaccine_code"<?= $Page->vaccine_code->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_vaccine_code" class="el_tb_vaccine_vaccine_code">
<span<?= $Page->vaccine_code->viewAttributes() ?>>
<?= $Page->vaccine_code->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->dose_required->Visible) { // dose_required ?>
        <td data-name="dose_required"<?= $Page->dose_required->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_dose_required" class="el_tb_vaccine_dose_required">
<span<?= $Page->dose_required->viewAttributes() ?>>
<?= $Page->dose_required->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->dose_required_uom->Visible) { // dose_required_uom ?>
        <td data-name="dose_required_uom"<?= $Page->dose_required_uom->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_dose_required_uom" class="el_tb_vaccine_dose_required_uom">
<span<?= $Page->dose_required_uom->viewAttributes() ?>>
<?= $Page->dose_required_uom->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->admin_mode_id->Visible) { // admin_mode_id ?>
        <td data-name="admin_mode_id"<?= $Page->admin_mode_id->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_admin_mode_id" class="el_tb_vaccine_admin_mode_id">
<span<?= $Page->admin_mode_id->viewAttributes() ?>>
<?= $Page->admin_mode_id->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->admin_site_id->Visible) { // admin_site_id ?>
        <td data-name="admin_site_id"<?= $Page->admin_site_id->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_admin_site_id" class="el_tb_vaccine_admin_site_id">
<span<?= $Page->admin_site_id->viewAttributes() ?>>
<?= $Page->admin_site_id->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->vaccine_form_id->Visible) { // vaccine_form_id ?>
        <td data-name="vaccine_form_id"<?= $Page->vaccine_form_id->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_vaccine_form_id" class="el_tb_vaccine_vaccine_form_id">
<span<?= $Page->vaccine_form_id->viewAttributes() ?>>
<?= $Page->vaccine_form_id->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->expiry_date->Visible) { // expiry_date ?>
        <td data-name="expiry_date"<?= $Page->expiry_date->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_expiry_date" class="el_tb_vaccine_expiry_date">
<span<?= $Page->expiry_date->viewAttributes() ?>>
<?= $Page->expiry_date->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->target_group->Visible) { // target_group ?>
        <td data-name="target_group"<?= $Page->target_group->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_target_group" class="el_tb_vaccine_target_group">
<span<?= $Page->target_group->viewAttributes() ?>>
<?= $Page->target_group->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->storage_condition->Visible) { // storage_condition ?>
        <td data-name="storage_condition"<?= $Page->storage_condition->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_storage_condition" class="el_tb_vaccine_storage_condition">
<span<?= $Page->storage_condition->viewAttributes() ?>>
<?= $Page->storage_condition->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->entry_date->Visible) { // entry_date ?>
        <td data-name="entry_date"<?= $Page->entry_date->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_entry_date" class="el_tb_vaccine_entry_date">
<span<?= $Page->entry_date->viewAttributes() ?>>
<?= $Page->entry_date->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->last_modified->Visible) { // last_modified ?>
        <td data-name="last_modified"<?= $Page->last_modified->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_last_modified" class="el_tb_vaccine_last_modified">
<span<?= $Page->last_modified->viewAttributes() ?>>
<?= $Page->last_modified->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->entered_by->Visible) { // entered_by ?>
        <td data-name="entered_by"<?= $Page->entered_by->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_entered_by" class="el_tb_vaccine_entered_by">
<span<?= $Page->entered_by->viewAttributes() ?>>
<?= $Page->entered_by->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
    <?php if ($Page->modified_by->Visible) { // modified_by ?>
        <td data-name="modified_by"<?= $Page->modified_by->cellAttributes() ?>>
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_modified_by" class="el_tb_vaccine_modified_by">
<span<?= $Page->modified_by->viewAttributes() ?>>
<?= $Page->modified_by->getViewValue() ?></span>
</span>
</td>
    <?php } ?>
<?php
// Render list options (body, right)
$Page->ListOptions->render("body", "right", $Page->RowCount);
?>
    </tr>
<?php if ($Page->RowType == ROWTYPE_VIEW) { ?>
<?php
    // Render row
    $Page->RowType = ROWTYPE_PREVIEW_FIELD; // Preview field
    $Page->resetAttributes();
    $Page->renderRow();
    $Page->renderListOptions();
?>
    <tr <?= $Page->rowAttributes() ?>>
        <td data-name="description" colspan="<?= $Page->ListOptions->visibleCount() + $Page->visibleFieldCount() ?>"<?= $Page->description->cellAttributes() ?>><p class="ew-preview-field" style="display: none">
<span id="el<?= $Page->RowIndex == '$rowindex$' ? '$rowindex$' : $Page->RowCount ?>_tb_vaccine_description" class="el_tb_vaccine_description">
<span<?= $Page->description->viewAttributes() ?>>
<?= $Page->description->getViewValue() ?></span>
</span>
</p></td>
    </tr>
<?php } ?>
<?php
    }
    if (
        $Page->Recordset &&
        !$Page->Recordset->EOF &&
        $Page->RowIndex !== '$rowindex$' &&
        (!$Page->isGridAdd() || $Page->CurrentMode == "copy") &&
        (!(($Page->isCopy() || $Page->isAdd()) && $Page->RowIndex == 0))
    ) {
        $Page->Recordset->moveNext();
    }
    // Reset for template row
    if ($Page->RowIndex === '$rowindex$') {
        $Page->RowIndex = 0;
    }
    // Reset inline add/copy row
    if (($Page->isCopy() || $Page->isAdd()) && $Page->RowIndex == 0) {
        $Page->RowIndex = 1;
    }
}
?>
</tbody>
</table><!-- /.ew-table -->
<?php } ?>
</div><!-- /.ew-grid-middle-panel -->
<?php if (!$Page->CurrentAction && !$Page->UseAjaxActions) { ?>
<input type="hidden" name="action" id="action" value="">
<?php } ?>
</form><!-- /.ew-list-form -->
<?php
// Close recordset
if ($Page->Recordset) {
    $Page->Recordset->close();
}
?>
<?php if (!$Page->isExport()) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php if (!$Page->isGridAdd() && !($Page->isGridEdit() && $Page->ModalGridEdit) && !$Page->isMultiEdit()) { ?>
<?= $Page->Pager->render() ?>
<?php } ?>
<div class="ew-list-other-options">
<?php $Page->OtherOptions->render("body", "bottom") ?>
</div>
</div>
<?php } ?>
</div><!-- /.ew-grid -->
<?php } else { ?>
<div class="ew-list-other-options">
<?php $Page->OtherOptions->render("body") ?>
</div>
<?php } ?>
</div>
</main>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<?php if (!$Page->isExport()) { ?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_vaccine");
});
</script>
<script>
loadjs.ready("load", function () {
    // Startup script
    // Write your table-specific startup script here, no need to add script tags.
    <?php
    	$current_table = CurrentPage()->TableName;

        // Convert underscores to dashes
        $new_current_table = str_replace('_', '-', $current_table);

        /* pass to javascript */
    	echo "var current_table = \"".$current_table."\";"; 
    	echo "var new_current_table = \"".$new_current_table."\";"; 
    ?>

    //Set Width to cover full page
    $('[class="card ew-card ew-grid '+new_current_table+'"]').css("width", "100%");

    //For Aggregate Fields/Columns
    $('[class="ew-aggregate"]').css({"font-weight":"bold", "color":"rgb(23, 125, 78)"});
    $('[class="ew-aggregate-value"]').css({"font-weight":"bold", "color":"rgb(23, 125, 78)"});
    $('[class="ew-aggregate"]').addClass("d-block");
    $('[class="ew-aggregate-value"]').addClass("d-block");

    //Limit Field sizes to the smallest width
    $('[class="ew-list-option-header"]').css("width", "1%");
    $('[data-name="checkbox"]').css("width", "1%");
    $('[data-name="view"]').css("width", "1%");
    $('[data-name="edit"]').css("width", "1%");
    $('[data-name="copy"]').css("width", "1%");
    $('[data-name="id"]').css("width", "1%");
    $('[id="tbl_'+current_table+'list"]').css({"min-width":"100%", "border":"1px solid #cccccc"});
    $('[class="alert alert-warning alert-dismissible ew-warning"]').addClass("py-1 px-2");
    $('[class="alert alert-success alert-dismissible ew-success"]').addClass("py-1 px-2");

    // Optionally, ensure the text is "New Order" in case it's missing
    $('a.ew-add').append('&nbsp;Add&nbsp;New&nbsp;Record');

    // Find the anchor tag by its class and update the class to btn-success
    $('a.ew-add').removeClass('btn-default').addClass('btn-success');
    $('button.ew-multi-delete').removeClass('btn-default').addClass('btn-danger');
    $('button.ew-multi-delete').append('&nbsp;Delete&nbsp;Record(s)');
});
</script>
<?php } ?>
