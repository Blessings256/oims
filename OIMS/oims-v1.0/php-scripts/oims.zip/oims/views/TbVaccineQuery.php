<?php

namespace PHPMaker2023\OIMS;

// Page object
$TbVaccineSearch = &$Page;
?>
<script>
var currentTable = <?= JsonEncode($Page->toClientVar()) ?>;
ew.deepAssign(ew.vars, { tables: { tb_vaccine: currentTable } });
var currentPageID = ew.PAGE_ID = "search";
var currentForm;
var ftb_vaccinesearch, currentSearchForm, currentAdvancedSearchForm;
loadjs.ready(["wrapper", "head"], function () {
    let $ = jQuery,
        fields = currentTable.fields;

    // Form object for search
    let form = new ew.FormBuilder()
        .setId("ftb_vaccinesearch")
        .setPageId("search")
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
        .setSubmitWithFetch(true)
<?php } ?>

        // Add fields
        .addFields([
            ["id", [ew.Validators.integer], fields.id.isInvalid],
            ["y_id", [ew.Validators.between], false],
            ["vaccine_name", [], fields.vaccine_name.isInvalid],
            ["y_vaccine_name", [ew.Validators.between], false],
            ["vaccine_code", [], fields.vaccine_code.isInvalid],
            ["y_vaccine_code", [ew.Validators.between], false],
            ["dose_required", [ew.Validators.float], fields.dose_required.isInvalid],
            ["y_dose_required", [ew.Validators.between], false],
            ["dose_required_uom", [], fields.dose_required_uom.isInvalid],
            ["y_dose_required_uom", [ew.Validators.between], false],
            ["admin_mode_id", [], fields.admin_mode_id.isInvalid],
            ["y_admin_mode_id", [ew.Validators.between], false],
            ["admin_site_id", [], fields.admin_site_id.isInvalid],
            ["y_admin_site_id", [ew.Validators.between], false],
            ["vaccine_form_id", [], fields.vaccine_form_id.isInvalid],
            ["y_vaccine_form_id", [ew.Validators.between], false],
            ["expiry_date", [ew.Validators.datetime(fields.expiry_date.clientFormatPattern)], fields.expiry_date.isInvalid],
            ["y_expiry_date", [ew.Validators.between], false],
            ["target_group", [], fields.target_group.isInvalid],
            ["y_target_group", [ew.Validators.between], false],
            ["storage_condition", [], fields.storage_condition.isInvalid],
            ["y_storage_condition", [ew.Validators.between], false]
        ])
        // Validate form
        .setValidate(
            async function () {
                if (!this.validateRequired)
                    return true; // Ignore validation
                let fobj = this.getForm();

                // Validate fields
                if (!this.validateFields())
                    return false;

                // Call Form_CustomValidate event
                if (!(await this.customValidate?.(fobj) ?? true)) {
                    this.focus();
                    return false;
                }
                return true;
            }
        )

        // Form_CustomValidate
        .setCustomValidate(
            function (fobj) { // DO NOT CHANGE THIS LINE! (except for adding "async" keyword)!
                    // Your custom validation code here, return false if invalid.
                    return true;
                }
        )

        // Use JavaScript validation or not
        .setValidateRequired(ew.CLIENT_VALIDATE)

        // Dynamic selection lists
        .setQueryBuilderLists({
            "dose_required_uom": <?= $Page->dose_required_uom->toClientList($Page) ?>,
            "admin_mode_id": <?= $Page->admin_mode_id->toClientList($Page) ?>,
            "admin_site_id": <?= $Page->admin_site_id->toClientList($Page) ?>,
            "vaccine_form_id": <?= $Page->vaccine_form_id->toClientList($Page) ?>,
            "target_group": <?= $Page->target_group->toClientList($Page) ?>,
        })
        .build();
    window[form.id] = form;
<?php if ($Page->IsModal) { ?>
    currentAdvancedSearchForm = form;
<?php } else { ?>
    currentForm = form;
<?php } ?>
    loadjs.done(form.id);
});
</script>
<script>
loadjs.ready("head", function () {
    // Write your table-specific client script here, no need to add script tags.
});
</script>
<?php $Page->showPageHeader(); ?>
<?php
$Page->showMessage();
?>
<form name="ftb_vaccinesearch" id="ftb_vaccinesearch" class="<?= $Page->FormClassName ?>" action="<?= HtmlEncode(GetUrl("tbvaccinelist")) ?>" method="post" novalidate autocomplete="off">
<?php if (Config("CHECK_TOKEN")) { ?>
<input type="hidden" name="<?= $TokenNameKey ?>" value="<?= $TokenName ?>"><!-- CSRF token name -->
<input type="hidden" name="<?= $TokenValueKey ?>" value="<?= $TokenValue ?>"><!-- CSRF token value -->
<?php } ?>
<input type="hidden" name="t" value="tb_vaccine">
<input type="hidden" name="action" id="action" value="search">
<?php if ($Page->IsModal && $Page->UseAjaxActions) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<input type="hidden" name="rules" value="<?= HtmlEncode($Page->getSessionRules()) ?>">
<template id="tpx_tb_vaccine_id" class="tb_vaccinesearch"><span id="el_tb_vaccine_id" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->id->getInputTextType() ?>" name="x_id" id="x_id" data-table="tb_vaccine" data-field="x_id" value="<?= $Page->id->EditValue ?>" size="30" placeholder="<?= HtmlEncode($Page->id->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->id->formatPattern()) ?>"<?= $Page->id->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->id->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_vaccine_vaccine_name" class="tb_vaccinesearch"><span id="el_tb_vaccine_vaccine_name" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->vaccine_name->getInputTextType() ?>" name="x_vaccine_name" id="x_vaccine_name" data-table="tb_vaccine" data-field="x_vaccine_name" value="<?= $Page->vaccine_name->EditValue ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->vaccine_name->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_name->formatPattern()) ?>"<?= $Page->vaccine_name->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->vaccine_name->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_vaccine_vaccine_code" class="tb_vaccinesearch"><span id="el_tb_vaccine_vaccine_code" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->vaccine_code->getInputTextType() ?>" name="x_vaccine_code" id="x_vaccine_code" data-table="tb_vaccine" data-field="x_vaccine_code" value="<?= $Page->vaccine_code->EditValue ?>" maxlength="10" placeholder="<?= HtmlEncode($Page->vaccine_code->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->vaccine_code->formatPattern()) ?>"<?= $Page->vaccine_code->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->vaccine_code->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_vaccine_dose_required" class="tb_vaccinesearch"><span id="el_tb_vaccine_dose_required" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->dose_required->getInputTextType() ?>" name="x_dose_required" id="x_dose_required" data-table="tb_vaccine" data-field="x_dose_required" value="<?= $Page->dose_required->EditValue ?>" placeholder="<?= HtmlEncode($Page->dose_required->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->dose_required->formatPattern()) ?>"<?= $Page->dose_required->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->dose_required->getErrorMessage(false) ?></div>
</span></template>
<template id="tpx_tb_vaccine_dose_required_uom" class="tb_vaccinesearch"><span id="el_tb_vaccine_dose_required_uom" class="ew-search-field ew-search-field-single">
    <select
        id="x_dose_required_uom"
        name="x_dose_required_uom"
        class="form-select ew-select<?= $Page->dose_required_uom->isInvalidClass() ?>"
        <?php if (!$Page->dose_required_uom->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_dose_required_uom"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_dose_required_uom"
        data-value-separator="<?= $Page->dose_required_uom->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->dose_required_uom->getPlaceHolder()) ?>"
        <?= $Page->dose_required_uom->editAttributes() ?>>
        <?= $Page->dose_required_uom->selectOptionListHtml("x_dose_required_uom") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->dose_required_uom->getErrorMessage(false) ?></div>
<?= $Page->dose_required_uom->Lookup->getParamTag($Page, "p_x_dose_required_uom") ?>
<?php if (!$Page->dose_required_uom->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_dose_required_uom", selectId: "ftb_vaccinesearch_x_dose_required_uom" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.dose_required_uom?.lookupOptions.length) {
        options.data = { id: "x_dose_required_uom", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_dose_required_uom", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.dose_required_uom.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_vaccine_admin_mode_id" class="tb_vaccinesearch"><span id="el_tb_vaccine_admin_mode_id" class="ew-search-field ew-search-field-single">
    <select
        id="x_admin_mode_id"
        name="x_admin_mode_id"
        class="form-select ew-select<?= $Page->admin_mode_id->isInvalidClass() ?>"
        <?php if (!$Page->admin_mode_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_admin_mode_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_admin_mode_id"
        data-value-separator="<?= $Page->admin_mode_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->admin_mode_id->getPlaceHolder()) ?>"
        <?= $Page->admin_mode_id->editAttributes() ?>>
        <?= $Page->admin_mode_id->selectOptionListHtml("x_admin_mode_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->admin_mode_id->getErrorMessage(false) ?></div>
<?= $Page->admin_mode_id->Lookup->getParamTag($Page, "p_x_admin_mode_id") ?>
<?php if (!$Page->admin_mode_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_admin_mode_id", selectId: "ftb_vaccinesearch_x_admin_mode_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.admin_mode_id?.lookupOptions.length) {
        options.data = { id: "x_admin_mode_id", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_admin_mode_id", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.admin_mode_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_vaccine_admin_site_id" class="tb_vaccinesearch"><span id="el_tb_vaccine_admin_site_id" class="ew-search-field ew-search-field-single">
    <select
        id="x_admin_site_id"
        name="x_admin_site_id"
        class="form-select ew-select<?= $Page->admin_site_id->isInvalidClass() ?>"
        <?php if (!$Page->admin_site_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_admin_site_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_admin_site_id"
        data-value-separator="<?= $Page->admin_site_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->admin_site_id->getPlaceHolder()) ?>"
        <?= $Page->admin_site_id->editAttributes() ?>>
        <?= $Page->admin_site_id->selectOptionListHtml("x_admin_site_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->admin_site_id->getErrorMessage(false) ?></div>
<?= $Page->admin_site_id->Lookup->getParamTag($Page, "p_x_admin_site_id") ?>
<?php if (!$Page->admin_site_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_admin_site_id", selectId: "ftb_vaccinesearch_x_admin_site_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.admin_site_id?.lookupOptions.length) {
        options.data = { id: "x_admin_site_id", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_admin_site_id", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.admin_site_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_vaccine_vaccine_form_id" class="tb_vaccinesearch"><span id="el_tb_vaccine_vaccine_form_id" class="ew-search-field ew-search-field-single">
    <select
        id="x_vaccine_form_id"
        name="x_vaccine_form_id"
        class="form-select ew-select<?= $Page->vaccine_form_id->isInvalidClass() ?>"
        <?php if (!$Page->vaccine_form_id->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_vaccine_form_id"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_vaccine_form_id"
        data-value-separator="<?= $Page->vaccine_form_id->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->vaccine_form_id->getPlaceHolder()) ?>"
        <?= $Page->vaccine_form_id->editAttributes() ?>>
        <?= $Page->vaccine_form_id->selectOptionListHtml("x_vaccine_form_id") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->vaccine_form_id->getErrorMessage(false) ?></div>
<?= $Page->vaccine_form_id->Lookup->getParamTag($Page, "p_x_vaccine_form_id") ?>
<?php if (!$Page->vaccine_form_id->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_vaccine_form_id", selectId: "ftb_vaccinesearch_x_vaccine_form_id" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.vaccine_form_id?.lookupOptions.length) {
        options.data = { id: "x_vaccine_form_id", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_vaccine_form_id", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.vaccine_form_id.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_vaccine_expiry_date" class="tb_vaccinesearch"><span id="el_tb_vaccine_expiry_date" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->expiry_date->getInputTextType() ?>" name="x_expiry_date" id="x_expiry_date" data-table="tb_vaccine" data-field="x_expiry_date" value="<?= $Page->expiry_date->EditValue ?>" placeholder="<?= HtmlEncode($Page->expiry_date->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->expiry_date->formatPattern()) ?>"<?= $Page->expiry_date->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->expiry_date->getErrorMessage(false) ?></div>
<?php if (!$Page->expiry_date->ReadOnly && !$Page->expiry_date->Disabled && !isset($Page->expiry_date->EditAttrs["readonly"]) && !isset($Page->expiry_date->EditAttrs["disabled"])) { ?>
<script>
loadjs.ready(["ftb_vaccinesearch", "datetimepicker"], function () {
    let format = "<?= DateFormat(0) ?>",
        options = {
            localization: {
                locale: ew.LANGUAGE_ID + "-u-nu-" + ew.getNumberingSystem(),
                hourCycle: format.match(/H/) ? "h24" : "h12",
                format,
                ...ew.language.phrase("datetimepicker")
            },
            display: {
                icons: {
                    previous: ew.IS_RTL ? "fa-solid fa-chevron-right" : "fa-solid fa-chevron-left",
                    next: ew.IS_RTL ? "fa-solid fa-chevron-left" : "fa-solid fa-chevron-right"
                },
                components: {
                    hours: !!format.match(/h/i),
                    minutes: !!format.match(/m/),
                    seconds: !!format.match(/s/i)
                },
                theme: ew.isDark() ? "dark" : "auto"
            }
        };
    ew.createDateTimePicker("ftb_vaccinesearch", "x_expiry_date", ew.deepAssign({"useCurrent":false,"display":{"sideBySide":false},"inputGroup":false}, options));
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_vaccine_target_group" class="tb_vaccinesearch"><span id="el_tb_vaccine_target_group" class="ew-search-field ew-search-field-single">
    <select
        id="x_target_group"
        name="x_target_group"
        class="form-select ew-select<?= $Page->target_group->isInvalidClass() ?>"
        <?php if (!$Page->target_group->IsNativeSelect) { ?>
        data-select2-id="ftb_vaccinesearch_x_target_group"
        <?php } ?>
        data-table="tb_vaccine"
        data-field="x_target_group"
        data-value-separator="<?= $Page->target_group->displayValueSeparatorAttribute() ?>"
        data-placeholder="<?= HtmlEncode($Page->target_group->getPlaceHolder()) ?>"
        <?= $Page->target_group->editAttributes() ?>>
        <?= $Page->target_group->selectOptionListHtml("x_target_group") ?>
    </select>
    <div class="invalid-feedback"><?= $Page->target_group->getErrorMessage(false) ?></div>
<?php if (!$Page->target_group->IsNativeSelect) { ?>
<script>
loadjs.ready("ftb_vaccinesearch", function() {
    var options = { name: "x_target_group", selectId: "ftb_vaccinesearch_x_target_group" },
        el = document.querySelector("select[data-select2-id='" + options.selectId + "']");
    if (!el)
        return;
    options.closeOnSelect = !options.multiple;
    options.dropdownParent = el.closest("#ew-modal-dialog, #ew-add-opt-dialog");
    if (ftb_vaccinesearch.lists.target_group?.lookupOptions.length) {
        options.data = { id: "x_target_group", form: "ftb_vaccinesearch" };
    } else {
        options.ajax = { id: "x_target_group", form: "ftb_vaccinesearch", limit: ew.LOOKUP_PAGE_SIZE };
    }
    options.minimumResultsForSearch = Infinity;
    options = Object.assign({}, ew.selectOptions, options, ew.vars.tables.tb_vaccine.fields.target_group.selectOptions);
    ew.createSelect(options);
});
</script>
<?php } ?>
</span></template>
<template id="tpx_tb_vaccine_storage_condition" class="tb_vaccinesearch"><span id="el_tb_vaccine_storage_condition" class="ew-search-field ew-search-field-single">
<input type="<?= $Page->storage_condition->getInputTextType() ?>" name="x_storage_condition" id="x_storage_condition" data-table="tb_vaccine" data-field="x_storage_condition" value="<?= $Page->storage_condition->EditValue ?>" maxlength="255" placeholder="<?= HtmlEncode($Page->storage_condition->getPlaceHolder()) ?>" data-format-pattern="<?= HtmlEncode($Page->storage_condition->formatPattern()) ?>"<?= $Page->storage_condition->editAttributes() ?>>
<div class="invalid-feedback"><?= $Page->storage_condition->getErrorMessage(false) ?></div>
</span></template>
<div id="tb_vaccine_query_builder" class="query-builder mb-3"></div>
<div class="btn-group mb-3 query-btn-group"></div>
<button type="button" id="btn-view-rules" class="btn btn-primary d-none disabled" title="<?= HtmlEncode($Language->phrase("View", true)) ?>"><i class="fa-solid fa-eye ew-icon"></i></button>
<button type="button" id="btn-clear-rules" class="btn btn-primary d-none disabled" title="<?= HtmlEncode($Language->phrase("Clear", true)) ?>"><i class="fa-solid fa-xmark ew-icon"></i></button>
<script>
// Filter builder
loadjs.ready(["wrapper", "head"], () => {
    let filters = [
            {
                id: "id",
                type: "integer",
                label: currentTable.fields.id.caption,
                operators: currentTable.fields.id.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.id.validators),
                data: {
                    format: currentTable.fields.id.clientFormatPattern
                }
            },
            {
                id: "vaccine_name",
                type: "string",
                label: currentTable.fields.vaccine_name.caption,
                operators: currentTable.fields.vaccine_name.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.vaccine_name.validators),
                data: {
                    format: currentTable.fields.vaccine_name.clientFormatPattern
                }
            },
            {
                id: "vaccine_code",
                type: "string",
                label: currentTable.fields.vaccine_code.caption,
                operators: currentTable.fields.vaccine_code.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.vaccine_code.validators),
                data: {
                    format: currentTable.fields.vaccine_code.clientFormatPattern
                }
            },
            {
                id: "dose_required",
                type: "double",
                label: currentTable.fields.dose_required.caption,
                operators: currentTable.fields.dose_required.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.dose_required.validators),
                data: {
                    format: currentTable.fields.dose_required.clientFormatPattern
                }
            },
            {
                id: "dose_required_uom",
                type: "integer",
                label: currentTable.fields.dose_required_uom.caption,
                operators: currentTable.fields.dose_required_uom.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.dose_required_uom.validators),
                data: {
                    format: currentTable.fields.dose_required_uom.clientFormatPattern
                }
            },
            {
                id: "admin_mode_id",
                type: "integer",
                label: currentTable.fields.admin_mode_id.caption,
                operators: currentTable.fields.admin_mode_id.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.admin_mode_id.validators),
                data: {
                    format: currentTable.fields.admin_mode_id.clientFormatPattern
                }
            },
            {
                id: "admin_site_id",
                type: "integer",
                label: currentTable.fields.admin_site_id.caption,
                operators: currentTable.fields.admin_site_id.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.admin_site_id.validators),
                data: {
                    format: currentTable.fields.admin_site_id.clientFormatPattern
                }
            },
            {
                id: "vaccine_form_id",
                type: "integer",
                label: currentTable.fields.vaccine_form_id.caption,
                operators: currentTable.fields.vaccine_form_id.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.vaccine_form_id.validators),
                data: {
                    format: currentTable.fields.vaccine_form_id.clientFormatPattern
                }
            },
            {
                id: "expiry_date",
                type: "datetime",
                label: currentTable.fields.expiry_date.caption,
                operators: currentTable.fields.expiry_date.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.expiry_date.validators),
                data: {
                    format: currentTable.fields.expiry_date.clientFormatPattern
                }
            },
            {
                id: "target_group",
                type: "string",
                label: currentTable.fields.target_group.caption,
                operators: currentTable.fields.target_group.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                valueSetter: ew.getQueryBuilderValueSetter(),
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.target_group.validators),
                data: {
                    format: currentTable.fields.target_group.clientFormatPattern
                }
            },
            {
                id: "storage_condition",
                type: "string",
                label: currentTable.fields.storage_condition.caption,
                operators: currentTable.fields.storage_condition.clientSearchOperators,
                input: ew.getQueryBuilderFilterInput(),
                value_separator: ew.IN_OPERATOR_VALUE_SEPARATOR,
                validation: ew.getQueryBuilderFilterValidation(ftb_vaccinesearch.fields.storage_condition.validators),
                data: {
                    format: currentTable.fields.storage_condition.clientFormatPattern
                }
            },
        ],
        $ = jQuery,
        $qb = $("#tb_vaccine_query_builder"),
        args = {},
        rules = ew.parseJson($("#ftb_vaccinesearch input[name=rules]").val()),
        queryBuilderOptions = Object.assign({}, ew.queryBuilderOptions),
        allowViewRules = queryBuilderOptions.allowViewRules,
        allowClearRules = queryBuilderOptions.allowClearRules,
        hasRules = group => Array.isArray(group?.rules) && group.rules.length > 0,
        getRules = () => $qb.queryBuilder("getRules", { skip_empty: true }),
        getSql = () => $qb.queryBuilder("getSQL", false, false, rules)?.sql;
    delete queryBuilderOptions.allowViewRules;
    delete queryBuilderOptions.allowClearRules;
    args.options = ew.deepAssign({
        plugins: Object.assign({}, ew.queryBuilderPlugins),
        lang: ew.language.phrase("querybuilderjs"),
        select_placeholder: ew.language.phrase("PleaseSelect"),
        inputs_separator: `<div class="d-inline-flex ms-2 me-2">${ew.language.phrase("AND")}</div>`, // For "between"
        filters,
        rules
    }, queryBuilderOptions);
    $qb.trigger("querybuilder", [args]);
    $qb.queryBuilder(args.options).on("rulesChanged.queryBuilder", () => {
        let rules = getRules();
        !ew.DEBUG || console.log(rules, getSql());
        $("#btn-reset, #btn-action, #btn-clear-rules, #btn-view-rules").toggleClass("disabled", !rules);
    }).on("afterCreateRuleInput.queryBuilder", function(e, rule) {
        let select = rule.$el.find(".rule-value-container").find("selection-list, select")[0];
        if (select) { // Selection list
            let id = select.dataset.field.replace("^x_", ""),
                form = ew.forms.get(select);
            form.updateList(select, undefined, undefined, true); // Update immediately
        }
    });
    $("#ftb_vaccinesearch").on("beforesubmit", function () {
        this.rules.value = JSON.stringify(getRules());
    });
    $("#btn-reset").toggleClass("d-none", false).on("click", () => {
        hasRules(rules) ? $qb.queryBuilder("setRules", rules) : $qb.queryBuilder("reset");
        return false;
    });
    $("#btn-action").toggleClass("d-none", false);
    if (allowClearRules) {
        $("#btn-clear-rules").appendTo(".query-btn-group").removeClass("d-none").on("click", () => $qb.queryBuilder("reset"));
    }
    if (allowViewRules) {
        $("#btn-view-rules").appendTo(".query-btn-group").removeClass("d-none").on("click", () => {
            let rules = getRules();
            if (hasRules(rules)) {
                let sql = getSql();
                ew.alert(sql ? '<pre class="text-start fs-6">' + sql + '</pre>' : '', "dark");
                !ew.DEBUG || console.log(rules, sql);
            } else {
                ew.alert(ew.language.phrase("EmptyLabel"));
            }
        });
    }
    if (hasRules(rules)) { // Enable buttons if rules exist initially
        $("#btn-reset, #btn-action, #btn-clear-rules, #btn-view-rules").removeClass("disabled");
    }
});
</script>
<?= $Page->IsModal ? '<template class="ew-modal-buttons">' : '<div class="row ew-buttons">' ?><!-- buttons .row -->
    <div class="<?= $Page->OffsetColumnClass ?>"><!-- buttons offset -->
        <button class="btn btn-primary ew-btn d-none disabled" name="btn-action" id="btn-action" type="submit" form="ftb_vaccinesearch" formaction="<?= HtmlEncode(GetUrl("tbvaccinelist")) ?>" data-ajax="<?= $Page->UseAjaxActions ? "true" : "false" ?>"><?= $Language->phrase("Search") ?></button>
        <?php if ($Page->IsModal) { ?>
        <button class="btn btn-default ew-btn" name="btn-cancel" id="btn-cancel" type="button" form="ftb_vaccinesearch"><?= $Language->phrase("Cancel") ?></button>
        <?php } else { ?>
        <button class="btn btn-default ew-btn d-none disabled" name="btn-reset" id="btn-reset" type="button" form="ftb_vaccinesearch" data-ew-action="reload"><?= $Language->phrase("Reset") ?></button>
        <?php } ?>
    </div><!-- /buttons offset -->
<?= $Page->IsModal ? "</template>" : "</div>" ?><!-- /buttons .row -->
</form>
<?php
$Page->showPageFooter();
echo GetDebugMessage();
?>
<script>
// Field event handlers
loadjs.ready("head", function() {
    ew.addEventHandlers("tb_vaccine");
});
</script>
<script>
loadjs.ready("load", function () {
    // Write your table-specific startup script here, no need to add script tags.
});
</script>
