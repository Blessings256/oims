<?php

namespace PHPMaker2023\OIMS;

use Slim\App;
use Slim\Routing\RouteCollectorProxy;
use Slim\Exception\HttpNotFoundException;

// Handle Routes
return function (App $app) {
    // tb_user_role
    $app->map(["GET","POST","OPTIONS"], '/tbuserrolelist[/{id}]', TbUserRoleController::class . ':list')->add(PermissionMiddleware::class)->setName('tbuserrolelist-tb_user_role-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbuserroleadd[/{id}]', TbUserRoleController::class . ':add')->add(PermissionMiddleware::class)->setName('tbuserroleadd-tb_user_role-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbuserroleview[/{id}]', TbUserRoleController::class . ':view')->add(PermissionMiddleware::class)->setName('tbuserroleview-tb_user_role-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbuserroleedit[/{id}]', TbUserRoleController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbuserroleedit-tb_user_role-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbuserroledelete[/{id}]', TbUserRoleController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbuserroledelete-tb_user_role-delete'); // delete
    $app->group(
        '/tb_user_role',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbUserRoleController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_user_role/list-tb_user_role-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbUserRoleController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_user_role/add-tb_user_role-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbUserRoleController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_user_role/view-tb_user_role-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbUserRoleController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_user_role/edit-tb_user_role-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbUserRoleController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_user_role/delete-tb_user_role-delete-2'); // delete
        }
    );

    // tb_user_role_permission
    $app->map(["GET","POST","OPTIONS"], '/tbuserrolepermissionlist[/{keys:.*}]', TbUserRolePermissionController::class . ':list')->add(PermissionMiddleware::class)->setName('tbuserrolepermissionlist-tb_user_role_permission-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbuserrolepermissionadd[/{keys:.*}]', TbUserRolePermissionController::class . ':add')->add(PermissionMiddleware::class)->setName('tbuserrolepermissionadd-tb_user_role_permission-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbuserrolepermissionview[/{keys:.*}]', TbUserRolePermissionController::class . ':view')->add(PermissionMiddleware::class)->setName('tbuserrolepermissionview-tb_user_role_permission-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbuserrolepermissionedit[/{keys:.*}]', TbUserRolePermissionController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbuserrolepermissionedit-tb_user_role_permission-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbuserrolepermissiondelete[/{keys:.*}]', TbUserRolePermissionController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbuserrolepermissiondelete-tb_user_role_permission-delete'); // delete
    $app->group(
        '/tb_user_role_permission',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{keys:.*}]', TbUserRolePermissionController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_user_role_permission/list-tb_user_role_permission-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{keys:.*}]', TbUserRolePermissionController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_user_role_permission/add-tb_user_role_permission-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{keys:.*}]', TbUserRolePermissionController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_user_role_permission/view-tb_user_role_permission-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{keys:.*}]', TbUserRolePermissionController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_user_role_permission/edit-tb_user_role_permission-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{keys:.*}]', TbUserRolePermissionController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_user_role_permission/delete-tb_user_role_permission-delete-2'); // delete
        }
    );

    // tb_child
    $app->map(["GET","POST","OPTIONS"], '/tbchildlist[/{id}]', TbChildController::class . ':list')->add(PermissionMiddleware::class)->setName('tbchildlist-tb_child-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbchildadd[/{id}]', TbChildController::class . ':add')->add(PermissionMiddleware::class)->setName('tbchildadd-tb_child-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbchildview[/{id}]', TbChildController::class . ':view')->add(PermissionMiddleware::class)->setName('tbchildview-tb_child-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbchildedit[/{id}]', TbChildController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbchildedit-tb_child-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbchilddelete[/{id}]', TbChildController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbchilddelete-tb_child-delete'); // delete
    $app->group(
        '/tb_child',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbChildController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_child/list-tb_child-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbChildController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_child/add-tb_child-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbChildController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_child/view-tb_child-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbChildController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_child/edit-tb_child-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbChildController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_child/delete-tb_child-delete-2'); // delete
        }
    );

    // tb_system_user
    $app->map(["GET","POST","OPTIONS"], '/tbsystemuserlist[/{id}]', TbSystemUserController::class . ':list')->add(PermissionMiddleware::class)->setName('tbsystemuserlist-tb_system_user-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbsystemuseradd[/{id}]', TbSystemUserController::class . ':add')->add(PermissionMiddleware::class)->setName('tbsystemuseradd-tb_system_user-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbsystemuserview[/{id}]', TbSystemUserController::class . ':view')->add(PermissionMiddleware::class)->setName('tbsystemuserview-tb_system_user-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbsystemuseredit[/{id}]', TbSystemUserController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbsystemuseredit-tb_system_user-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbsystemuserdelete[/{id}]', TbSystemUserController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbsystemuserdelete-tb_system_user-delete'); // delete
    $app->map(["GET","POST","OPTIONS"], '/tbsystemusersearch', TbSystemUserController::class . ':search')->add(PermissionMiddleware::class)->setName('tbsystemusersearch-tb_system_user-search'); // search
    $app->group(
        '/tb_system_user',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbSystemUserController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_system_user/list-tb_system_user-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbSystemUserController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_system_user/add-tb_system_user-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbSystemUserController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_system_user/view-tb_system_user-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbSystemUserController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_system_user/edit-tb_system_user-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbSystemUserController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_system_user/delete-tb_system_user-delete-2'); // delete
            $group->map(["GET","POST","OPTIONS"], '/' . Config('SEARCH_ACTION') . '', TbSystemUserController::class . ':search')->add(PermissionMiddleware::class)->setName('tb_system_user/search-tb_system_user-search-2'); // search
        }
    );

    // tb_administration_site
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationsitelist[/{id}]', TbAdministrationSiteController::class . ':list')->add(PermissionMiddleware::class)->setName('tbadministrationsitelist-tb_administration_site-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationsiteadd[/{id}]', TbAdministrationSiteController::class . ':add')->add(PermissionMiddleware::class)->setName('tbadministrationsiteadd-tb_administration_site-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationsiteview[/{id}]', TbAdministrationSiteController::class . ':view')->add(PermissionMiddleware::class)->setName('tbadministrationsiteview-tb_administration_site-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationsiteedit[/{id}]', TbAdministrationSiteController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbadministrationsiteedit-tb_administration_site-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationsitedelete[/{id}]', TbAdministrationSiteController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbadministrationsitedelete-tb_administration_site-delete'); // delete
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationsitesearch', TbAdministrationSiteController::class . ':search')->add(PermissionMiddleware::class)->setName('tbadministrationsitesearch-tb_administration_site-search'); // search
    $app->group(
        '/tb_administration_site',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbAdministrationSiteController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_administration_site/list-tb_administration_site-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbAdministrationSiteController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_administration_site/add-tb_administration_site-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbAdministrationSiteController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_administration_site/view-tb_administration_site-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbAdministrationSiteController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_administration_site/edit-tb_administration_site-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbAdministrationSiteController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_administration_site/delete-tb_administration_site-delete-2'); // delete
            $group->map(["GET","POST","OPTIONS"], '/' . Config('SEARCH_ACTION') . '', TbAdministrationSiteController::class . ':search')->add(PermissionMiddleware::class)->setName('tb_administration_site/search-tb_administration_site-search-2'); // search
        }
    );

    // tb_administration_mode
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationmodelist[/{id}]', TbAdministrationModeController::class . ':list')->add(PermissionMiddleware::class)->setName('tbadministrationmodelist-tb_administration_mode-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationmodeadd[/{id}]', TbAdministrationModeController::class . ':add')->add(PermissionMiddleware::class)->setName('tbadministrationmodeadd-tb_administration_mode-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationmodeview[/{id}]', TbAdministrationModeController::class . ':view')->add(PermissionMiddleware::class)->setName('tbadministrationmodeview-tb_administration_mode-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationmodeedit[/{id}]', TbAdministrationModeController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbadministrationmodeedit-tb_administration_mode-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationmodedelete[/{id}]', TbAdministrationModeController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbadministrationmodedelete-tb_administration_mode-delete'); // delete
    $app->map(["GET","POST","OPTIONS"], '/tbadministrationmodesearch', TbAdministrationModeController::class . ':search')->add(PermissionMiddleware::class)->setName('tbadministrationmodesearch-tb_administration_mode-search'); // search
    $app->group(
        '/tb_administration_mode',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbAdministrationModeController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_administration_mode/list-tb_administration_mode-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbAdministrationModeController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_administration_mode/add-tb_administration_mode-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbAdministrationModeController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_administration_mode/view-tb_administration_mode-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbAdministrationModeController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_administration_mode/edit-tb_administration_mode-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbAdministrationModeController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_administration_mode/delete-tb_administration_mode-delete-2'); // delete
            $group->map(["GET","POST","OPTIONS"], '/' . Config('SEARCH_ACTION') . '', TbAdministrationModeController::class . ':search')->add(PermissionMiddleware::class)->setName('tb_administration_mode/search-tb_administration_mode-search-2'); // search
        }
    );

    // tb_unit_of_measure
    $app->map(["GET","POST","OPTIONS"], '/tbunitofmeasurelist[/{id}]', TbUnitOfMeasureController::class . ':list')->add(PermissionMiddleware::class)->setName('tbunitofmeasurelist-tb_unit_of_measure-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbunitofmeasureadd[/{id}]', TbUnitOfMeasureController::class . ':add')->add(PermissionMiddleware::class)->setName('tbunitofmeasureadd-tb_unit_of_measure-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbunitofmeasureview[/{id}]', TbUnitOfMeasureController::class . ':view')->add(PermissionMiddleware::class)->setName('tbunitofmeasureview-tb_unit_of_measure-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbunitofmeasureedit[/{id}]', TbUnitOfMeasureController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbunitofmeasureedit-tb_unit_of_measure-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbunitofmeasuredelete[/{id}]', TbUnitOfMeasureController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbunitofmeasuredelete-tb_unit_of_measure-delete'); // delete
    $app->map(["GET","POST","OPTIONS"], '/tbunitofmeasuresearch', TbUnitOfMeasureController::class . ':search')->add(PermissionMiddleware::class)->setName('tbunitofmeasuresearch-tb_unit_of_measure-search'); // search
    $app->group(
        '/tb_unit_of_measure',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbUnitOfMeasureController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_unit_of_measure/list-tb_unit_of_measure-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbUnitOfMeasureController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_unit_of_measure/add-tb_unit_of_measure-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbUnitOfMeasureController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_unit_of_measure/view-tb_unit_of_measure-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbUnitOfMeasureController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_unit_of_measure/edit-tb_unit_of_measure-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbUnitOfMeasureController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_unit_of_measure/delete-tb_unit_of_measure-delete-2'); // delete
            $group->map(["GET","POST","OPTIONS"], '/' . Config('SEARCH_ACTION') . '', TbUnitOfMeasureController::class . ':search')->add(PermissionMiddleware::class)->setName('tb_unit_of_measure/search-tb_unit_of_measure-search-2'); // search
        }
    );

    // tb_vaccine_form
    $app->map(["GET","POST","OPTIONS"], '/tbvaccineformlist[/{id}]', TbVaccineFormController::class . ':list')->add(PermissionMiddleware::class)->setName('tbvaccineformlist-tb_vaccine_form-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbvaccineformadd[/{id}]', TbVaccineFormController::class . ':add')->add(PermissionMiddleware::class)->setName('tbvaccineformadd-tb_vaccine_form-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbvaccineformview[/{id}]', TbVaccineFormController::class . ':view')->add(PermissionMiddleware::class)->setName('tbvaccineformview-tb_vaccine_form-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbvaccineformedit[/{id}]', TbVaccineFormController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbvaccineformedit-tb_vaccine_form-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbvaccineformdelete[/{id}]', TbVaccineFormController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbvaccineformdelete-tb_vaccine_form-delete'); // delete
    $app->map(["GET","POST","OPTIONS"], '/tbvaccineformsearch', TbVaccineFormController::class . ':search')->add(PermissionMiddleware::class)->setName('tbvaccineformsearch-tb_vaccine_form-search'); // search
    $app->group(
        '/tb_vaccine_form',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbVaccineFormController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_vaccine_form/list-tb_vaccine_form-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbVaccineFormController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_vaccine_form/add-tb_vaccine_form-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbVaccineFormController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_vaccine_form/view-tb_vaccine_form-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbVaccineFormController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_vaccine_form/edit-tb_vaccine_form-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbVaccineFormController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_vaccine_form/delete-tb_vaccine_form-delete-2'); // delete
            $group->map(["GET","POST","OPTIONS"], '/' . Config('SEARCH_ACTION') . '', TbVaccineFormController::class . ':search')->add(PermissionMiddleware::class)->setName('tb_vaccine_form/search-tb_vaccine_form-search-2'); // search
        }
    );

    // tb_vaccine
    $app->map(["GET","POST","OPTIONS"], '/tbvaccinelist[/{id}]', TbVaccineController::class . ':list')->add(PermissionMiddleware::class)->setName('tbvaccinelist-tb_vaccine-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbvaccineadd[/{id}]', TbVaccineController::class . ':add')->add(PermissionMiddleware::class)->setName('tbvaccineadd-tb_vaccine-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbvaccineview[/{id}]', TbVaccineController::class . ':view')->add(PermissionMiddleware::class)->setName('tbvaccineview-tb_vaccine-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbvaccineedit[/{id}]', TbVaccineController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbvaccineedit-tb_vaccine-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbvaccinedelete[/{id}]', TbVaccineController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbvaccinedelete-tb_vaccine-delete'); // delete
    $app->map(["GET","POST","OPTIONS"], '/tbvaccinesearch', TbVaccineController::class . ':search')->add(PermissionMiddleware::class)->setName('tbvaccinesearch-tb_vaccine-search'); // search
    $app->map(["GET","POST","OPTIONS"], '/tbvaccinequery', TbVaccineController::class . ':query')->add(PermissionMiddleware::class)->setName('tbvaccinequery-tb_vaccine-query'); // query
    $app->group(
        '/tb_vaccine',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbVaccineController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_vaccine/list-tb_vaccine-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbVaccineController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_vaccine/add-tb_vaccine-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbVaccineController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_vaccine/view-tb_vaccine-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbVaccineController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_vaccine/edit-tb_vaccine-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbVaccineController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_vaccine/delete-tb_vaccine-delete-2'); // delete
            $group->map(["GET","POST","OPTIONS"], '/' . Config('SEARCH_ACTION') . '', TbVaccineController::class . ':search')->add(PermissionMiddleware::class)->setName('tb_vaccine/search-tb_vaccine-search-2'); // search
            $group->map(["GET","POST","OPTIONS"], '/' . Config('QUERY_ACTION') . '', TbVaccineController::class . ':query')->add(PermissionMiddleware::class)->setName('tb_vaccine/query-tb_vaccine-query-2'); // query
        }
    );

    // tb_employee
    $app->map(["GET","POST","OPTIONS"], '/tbemployeelist[/{id}]', TbEmployeeController::class . ':list')->add(PermissionMiddleware::class)->setName('tbemployeelist-tb_employee-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbemployeeadd[/{id}]', TbEmployeeController::class . ':add')->add(PermissionMiddleware::class)->setName('tbemployeeadd-tb_employee-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbemployeeview[/{id}]', TbEmployeeController::class . ':view')->add(PermissionMiddleware::class)->setName('tbemployeeview-tb_employee-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbemployeeedit[/{id}]', TbEmployeeController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbemployeeedit-tb_employee-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbemployeedelete[/{id}]', TbEmployeeController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbemployeedelete-tb_employee-delete'); // delete
    $app->map(["GET","POST","OPTIONS"], '/tbemployeesearch', TbEmployeeController::class . ':search')->add(PermissionMiddleware::class)->setName('tbemployeesearch-tb_employee-search'); // search
    $app->map(["GET","POST","OPTIONS"], '/tbemployeequery', TbEmployeeController::class . ':query')->add(PermissionMiddleware::class)->setName('tbemployeequery-tb_employee-query'); // query
    $app->group(
        '/tb_employee',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbEmployeeController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_employee/list-tb_employee-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbEmployeeController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_employee/add-tb_employee-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbEmployeeController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_employee/view-tb_employee-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbEmployeeController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_employee/edit-tb_employee-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbEmployeeController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_employee/delete-tb_employee-delete-2'); // delete
            $group->map(["GET","POST","OPTIONS"], '/' . Config('SEARCH_ACTION') . '', TbEmployeeController::class . ':search')->add(PermissionMiddleware::class)->setName('tb_employee/search-tb_employee-search-2'); // search
            $group->map(["GET","POST","OPTIONS"], '/' . Config('QUERY_ACTION') . '', TbEmployeeController::class . ':query')->add(PermissionMiddleware::class)->setName('tb_employee/query-tb_employee-query-2'); // query
        }
    );

    // tb_immunisation
    $app->map(["GET","POST","OPTIONS"], '/tbimmunisationlist[/{id}]', TbImmunisationController::class . ':list')->add(PermissionMiddleware::class)->setName('tbimmunisationlist-tb_immunisation-list'); // list
    $app->map(["GET","POST","OPTIONS"], '/tbimmunisationadd[/{id}]', TbImmunisationController::class . ':add')->add(PermissionMiddleware::class)->setName('tbimmunisationadd-tb_immunisation-add'); // add
    $app->map(["GET","POST","OPTIONS"], '/tbimmunisationview[/{id}]', TbImmunisationController::class . ':view')->add(PermissionMiddleware::class)->setName('tbimmunisationview-tb_immunisation-view'); // view
    $app->map(["GET","POST","OPTIONS"], '/tbimmunisationedit[/{id}]', TbImmunisationController::class . ':edit')->add(PermissionMiddleware::class)->setName('tbimmunisationedit-tb_immunisation-edit'); // edit
    $app->map(["GET","POST","OPTIONS"], '/tbimmunisationdelete[/{id}]', TbImmunisationController::class . ':delete')->add(PermissionMiddleware::class)->setName('tbimmunisationdelete-tb_immunisation-delete'); // delete
    $app->map(["GET","POST","OPTIONS"], '/tbimmunisationsearch', TbImmunisationController::class . ':search')->add(PermissionMiddleware::class)->setName('tbimmunisationsearch-tb_immunisation-search'); // search
    $app->map(["GET","POST","OPTIONS"], '/tbimmunisationquery', TbImmunisationController::class . ':query')->add(PermissionMiddleware::class)->setName('tbimmunisationquery-tb_immunisation-query'); // query
    $app->group(
        '/tb_immunisation',
        function (RouteCollectorProxy $group) {
            $group->map(["GET","POST","OPTIONS"], '/' . Config('LIST_ACTION') . '[/{id}]', TbImmunisationController::class . ':list')->add(PermissionMiddleware::class)->setName('tb_immunisation/list-tb_immunisation-list-2'); // list
            $group->map(["GET","POST","OPTIONS"], '/' . Config('ADD_ACTION') . '[/{id}]', TbImmunisationController::class . ':add')->add(PermissionMiddleware::class)->setName('tb_immunisation/add-tb_immunisation-add-2'); // add
            $group->map(["GET","POST","OPTIONS"], '/' . Config('VIEW_ACTION') . '[/{id}]', TbImmunisationController::class . ':view')->add(PermissionMiddleware::class)->setName('tb_immunisation/view-tb_immunisation-view-2'); // view
            $group->map(["GET","POST","OPTIONS"], '/' . Config('EDIT_ACTION') . '[/{id}]', TbImmunisationController::class . ':edit')->add(PermissionMiddleware::class)->setName('tb_immunisation/edit-tb_immunisation-edit-2'); // edit
            $group->map(["GET","POST","OPTIONS"], '/' . Config('DELETE_ACTION') . '[/{id}]', TbImmunisationController::class . ':delete')->add(PermissionMiddleware::class)->setName('tb_immunisation/delete-tb_immunisation-delete-2'); // delete
            $group->map(["GET","POST","OPTIONS"], '/' . Config('SEARCH_ACTION') . '', TbImmunisationController::class . ':search')->add(PermissionMiddleware::class)->setName('tb_immunisation/search-tb_immunisation-search-2'); // search
            $group->map(["GET","POST","OPTIONS"], '/' . Config('QUERY_ACTION') . '', TbImmunisationController::class . ':query')->add(PermissionMiddleware::class)->setName('tb_immunisation/query-tb_immunisation-query-2'); // query
        }
    );

    // personal_data
    $app->map(["GET","POST","OPTIONS"], '/personaldata', OthersController::class . ':personaldata')->add(PermissionMiddleware::class)->setName('personaldata');

    // login
    $app->map(["GET","POST","OPTIONS"], '/login[/{provider}]', OthersController::class . ':login')->add(PermissionMiddleware::class)->setName('login');

    // change_password
    $app->map(["GET","POST","OPTIONS"], '/changepassword', OthersController::class . ':changepassword')->add(PermissionMiddleware::class)->setName('changepassword');

    // userpriv
    $app->map(["GET","POST","OPTIONS"], '/userpriv', OthersController::class . ':userpriv')->add(PermissionMiddleware::class)->setName('userpriv');

    // logout
    $app->map(["GET","POST","OPTIONS"], '/logout', OthersController::class . ':logout')->add(PermissionMiddleware::class)->setName('logout');

    // Swagger
    $app->get('/' . Config("SWAGGER_ACTION"), OthersController::class . ':swagger')->setName(Config("SWAGGER_ACTION")); // Swagger

    // Index
    $app->get('/[index]', OthersController::class . ':index')->add(PermissionMiddleware::class)->setName('index');

    // Route Action event
    if (function_exists(PROJECT_NAMESPACE . "Route_Action")) {
        if (Route_Action($app) === false) {
            return;
        }
    }

    /**
     * Catch-all route to serve a 404 Not Found page if none of the routes match
     * NOTE: Make sure this route is defined last.
     */
    $app->map(
        ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
        '/{routes:.+}',
        function ($request, $response, $params) {
            throw new HttpNotFoundException($request, str_replace("%p", $params["routes"], Container("language")->phrase("PageNotFound")));
        }
    );
};
