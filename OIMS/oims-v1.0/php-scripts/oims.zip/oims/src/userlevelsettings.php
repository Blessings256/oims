<?php
/**
 * PHPMaker 2023 user level settings
 */
namespace PHPMaker2023\OIMS;

// User level info
$USER_LEVELS = [["-2","Anonymous"],
    ["0","Default"]];
// User level priv info
$USER_LEVEL_PRIVS = [["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_user_role","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_user_role","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_user_role_permission","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_user_role_permission","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_child","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_child","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_system_user","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_system_user","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_administration_site","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_administration_site","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_administration_mode","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_administration_mode","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_unit_of_measure","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_unit_of_measure","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_vaccine_form","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_vaccine_form","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_vaccine","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_vaccine","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_employee","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_employee","0","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_immunisation","-2","0"],
    ["{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}tb_immunisation","0","0"]];
// User level table info
$USER_LEVEL_TABLES = [["tb_user_role","tb_user_role","User Roles",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbuserrolelist"],
    ["tb_user_role_permission","tb_user_role_permission","User Role Permissions",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbuserrolepermissionlist"],
    ["tb_child","tb_child","Children",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbchildlist"],
    ["tb_system_user","tb_system_user","System Users",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbsystemuserlist"],
    ["tb_administration_site","tb_administration_site","Site of Administration",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbadministrationsitelist"],
    ["tb_administration_mode","tb_administration_mode","Mode of Administration",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbadministrationmodelist"],
    ["tb_unit_of_measure","tb_unit_of_measure","Units of Measure",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbunitofmeasurelist"],
    ["tb_vaccine_form","tb_vaccine_form","Vaccine Forms",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbvaccineformlist"],
    ["tb_vaccine","tb_vaccine","Vaccines",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbvaccinelist"],
    ["tb_employee","tb_employee","Employees",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbemployeelist"],
    ["tb_immunisation","tb_immunisation","Immunisations",true,"{E3E59D36-9427-4D87-8FA6-E770E7AD1B74}","tbimmunisationlist"]];
